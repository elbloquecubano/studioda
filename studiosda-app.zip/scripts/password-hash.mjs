import { randomBytes, scrypt } from "node:crypto";
import { promisify } from "node:util";

const scryptAsync = promisify(scrypt);

/**
 * Hash de contraseñas para scripts de línea de comandos.
 *
 * Duplica a propósito el formato de `src/lib/password.ts`: los scripts son
 * .mjs y no pueden importar TypeScript sin un paso de compilación. Si se
 * cambian los parámetros en un sitio, hay que cambiarlos en el otro; el
 * formato guarda N, r y p precisamente para que los hashes antiguos sigan
 * validando si eso ocurre.
 */

const N = 16384;
const R = 8;
const P = 1;
const KEY_LENGTH = 32;
const MAX_MEM = 64 * 1024 * 1024;

export async function hashPassword(plain) {
  const salt = randomBytes(16);
  const derived = await scryptAsync(plain, salt, KEY_LENGTH, {
    N,
    r: R,
    p: P,
    maxmem: MAX_MEM,
  });

  return ["scrypt", N, R, P, salt.toString("base64"), derived.toString("base64")].join("$");
}

export function validatePassword(plain) {
  if (typeof plain !== "string" || plain.length < 8) {
    return "La contraseña debe tener al menos 8 caracteres";
  }
  if (/^\d+$/.test(plain)) {
    return "La contraseña no puede ser sólo números";
  }
  return null;
}

export function normalizeUsername(raw) {
  return typeof raw === "string" ? raw.trim().toLowerCase() : "";
}

export function validateUsername(normalized) {
  if (!/^[a-z0-9._-]{3,20}$/.test(normalized)) {
    return "El usuario debe tener entre 3 y 20 caracteres: letras, números, punto, guion o guion bajo";
  }
  return null;
}
