import { spawn } from "node:child_process";
import { createRequire } from "node:module";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { ensureSchema, setupEnv } from "./env-setup.mjs";

const require = createRequire(import.meta.url);
// fileURLToPath decodifica los acentos de la ruta; new URL().pathname los
// dejaba como %C3%A1 y auto-import.mjs nunca llegaba a ejecutarse.
const __dirname = path.dirname(fileURLToPath(import.meta.url));

const nextBin = require.resolve("next/dist/bin/next");

// El compilador WASM sólo hace falta en Windows, que es donde el binario nativo
// de SWC no arranca. En Linux (el hosting) el nativo sí está y compila mucho
// más rápido, así que allí no se toca. NEXT_USE_WASM=1 lo fuerza si algún
// servidor tuviera una glibc con la que el nativo tampoco funciona.
if (process.platform === "win32" || process.env.NEXT_USE_WASM === "1") {
  process.env.NEXT_TEST_WASM_DIR = path.dirname(
    require.resolve("@next/swc-wasm-nodejs/wasm.js")
  );
}

// Resolver DATABASE_URL y AUTH_SECRET antes de arrancar Next.
// Todos los arranques (dev, dev:network, build, start) pasan por aquí, así que
// es el único sitio donde hace falta hacerlo.
const { appData } = setupEnv();

const cmd = process.argv[2];
if (cmd === "dev" || cmd === "start") {
  ensureSchema(appData);

  // Auto-importar backup si la DB está vacía
  runScript("auto-import.mjs");

  // Crear el administrador si todavía no existe. Sin esto, al quitar las
  // credenciales fijas del código no habría forma de entrar al panel.
  runScript("crear-admin.mjs", ["--auto"]);
}

/**
 * execFileSync y no execSync: la ruta del proyecto lleva acentos y espacios,
 * que sin comillas rompen la línea de comandos.
 */
function runScript(name, args = []) {
  try {
    execFileSync(process.execPath, [path.join(__dirname, name), ...args], {
      env: process.env,
      stdio: "inherit",
    });
  } catch {
    // No bloquear el arranque si falla
  }
}

const child = spawn(process.execPath, [nextBin, ...process.argv.slice(2)], {
  env: process.env,
  stdio: "inherit",
});

child.on("exit", (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal);
    return;
  }

  process.exit(code ?? 0);
});
