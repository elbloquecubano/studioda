#!/usr/bin/env node

/**
 * Script de migración de base de datos
 * Copia la DB de una versión vieja a la nueva ubicación externa
 */

import { execSync } from 'child_process';
import { existsSync, mkdirSync, copyFileSync, readdirSync, statSync } from 'fs';
import { join, resolve } from 'path';
import { homedir } from 'os';

// Ruta de la DB externa
const APP_DATA = join(process.env.APPDATA || join(homedir(), 'AppData', 'Roaming'), 'StudiosDA');
const DB_PATH = join(APP_DATA, 'dev.db');

console.log('===========================================');
console.log('  Migrador de Base de Datos - Studios D-A');
console.log('===========================================');
console.log('');
console.log(`Ubicación de la DB: ${DB_PATH}`);
console.log('');

// Crear carpeta si no existe
if (!existsSync(APP_DATA)) {
    mkdirSync(APP_DATA, { recursive: true });
    console.log('✓ Carpeta de datos creada');
}

// Buscar DB vieja en argumentos o en ubicaciones comunes
const args = process.argv.slice(2);
let oldDbPath = args[0];

if (!oldDbPath) {
    // Buscar en ubicaciones comunes
    const commonPaths = [
        join(process.cwd(), 'prisma', 'dev.db'),
        join(process.cwd(), 'dev.db'),
        'C:\\StudiosDA\\prisma\\dev.db',
        'D:\\StudiosDA\\prisma\\dev.db',
    ];

    console.log('Buscando base de datos anterior...');
    
    for (const path of commonPaths) {
        if (existsSync(path) && path !== DB_PATH) {
            console.log(`  Encontrada: ${path}`);
            oldDbPath = path;
            break;
        }
    }
}

if (!oldDbPath) {
    console.log('No se encontró una base de datos anterior.');
    console.log('');
    console.log('Uso: npm run db:migrate [ruta/a/dev.db]');
    console.log('');
    console.log('Si es tu primera vez, se creará una DB vacía.');
    process.exit(0);
}

if (!existsSync(oldDbPath)) {
    console.error(`ERROR: No se encontró la base de datos en: ${oldDbPath}`);
    process.exit(1);
}

// Verificar si ya hay una DB en la nueva ubicación
if (existsSync(DB_PATH)) {
    console.log('');
    console.log('Ya existe una base de datos en la nueva ubicación.');
    console.log('');
    console.log('Opciones:');
    console.log('  1. Conservar la DB actual (recomendado)');
    console.log('  2. Reemplazar con la DB vieja');
    console.log('  3. Fusionar (mantener ambos contenidos)');
    console.log('');
    
    const readline = await import('readline');
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    
    const answer = await new Promise(resolve => {
        rl.question('Selecciona (1/2/3): ', resolve);
    });
    rl.close();
    
    if (answer === '2') {
        console.log('');
        console.log('Reemplazando base de datos...');
        copyFileSync(oldDbPath, DB_PATH);
        console.log('✓ Base de datos reemplazada');
    } else if (answer === '3') {
        console.log('');
        console.log('Fusionando bases de datos...');
        fusionarBases(oldDbPath, DB_PATH);
    } else {
        console.log('');
        console.log('Conservando base de datos actual.');
    }
} else {
    console.log('');
    console.log('Copiando base de datos...');
    copyFileSync(oldDbPath, DB_PATH);
    console.log('✓ Base de datos copiada');
}

console.log('');
console.log('Listo. La base de datos está en:');
console.log(`  ${DB_PATH}`);
console.log('');

function fusionarBases(origen, destino) {
    // Usar SQLite para fusionar
    try {
        // Exportar datos de la DB origen
        const tempFile = join(process.env.TEMP || '/tmp', 'old_export.sql');
        execSync(`sqlite3 "${origen}" ".dump" > "${tempFile}"`, { stdio: 'pipe' });
        
        // Importar en el destino (ignorar duplicados)
        execSync(`sqlite3 "${destino}" < "${tempFile}"`, { stdio: 'pipe' });
        
        // Limpiar
        const fs = await import('fs');
        fs.unlinkSync(tempFile);
        
        console.log('✓ Fusión completada');
    } catch (error) {
        console.log('');
        console.log('No se pudo fusionar automáticamente.');
        console.log('Puedes usar SQLite manualmente:');
        console.log(`  sqlite3 "${destino}" < "${origen}_dump.sql"`);
        console.log('');
        
        // Exportar manualmente
        try {
            execSync(`sqlite3 "${origen}" ".dump" > "${origen}_dump.sql"`, { stdio: 'pipe' });
            console.log(`Exportado: ${origen}_dump.sql`);
        } catch (e) {
            console.error('Error al exportar:', e.message);
        }
    }
}