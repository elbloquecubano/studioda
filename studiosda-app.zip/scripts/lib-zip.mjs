/**
 * Generador de archivos .zip en formato estándar.
 *
 * Existe porque en Windows no había ninguna forma fiable de crear un zip que
 * se descomprima bien en un servidor Linux:
 *
 *   - `Compress-Archive` (PowerShell 5.1) escribe las rutas con la barra
 *     invertida de Windows, que el formato ZIP no admite: al extraer en Linux
 *     salen archivos llamados "src\app\page.tsx" en la raíz, sin carpetas.
 *   - `tar -a -c -f x.zip` (el bsdtar de Windows) sí usa la barra correcta,
 *     pero escribe en modo streaming: pone el tamaño y el CRC en un
 *     «descriptor de datos» detrás de cada archivo, en vez de en su cabecera.
 *     Es legal según la norma, pero muchos descompresores —el del File Manager
 *     de cPanel, entre ellos— fallan al leerlos.
 *
 * Aquí se calculan el CRC y los tamaños ANTES de escribir cada cabecera, que
 * es la forma que entiende todo el mundo, y los nombres van siempre con barra
 * normal y en UTF-8.
 *
 * Sin dependencias externas a propósito: sólo `zlib`, que ya viene con Node.
 */

import { closeSync, openSync, readFileSync, writeSync } from "node:fs";
import { deflateRawSync } from "node:zlib";

// --- CRC32 ------------------------------------------------------------------

const TABLA_CRC = (() => {
  const tabla = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    tabla[i] = c >>> 0;
  }
  return tabla;
})();

function crc32(buffer) {
  let c = 0xffffffff;
  for (let i = 0; i < buffer.length; i++) {
    c = TABLA_CRC[(c ^ buffer[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

// --- Fecha en formato DOS ---------------------------------------------------

function fechaDos(date) {
  const year = Math.max(1980, date.getFullYear());
  return {
    hora: (date.getHours() << 11) | (date.getMinutes() << 5) | (date.getSeconds() >> 1),
    fecha: ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate(),
  };
}

// --- Compresión -------------------------------------------------------------

/**
 * Formatos que ya vienen comprimidos. Volver a comprimirlos no baja el tamaño
 * y cuesta minutos cuando son cientos de megas de fotos, así que se guardan
 * tal cual (método «store»).
 */
const YA_COMPRIMIDO = new Set([
  ".jpg", ".jpeg", ".png", ".gif", ".webp", ".avif", ".ico",
  ".mp4", ".webm", ".mov", ".mp3", ".ogg",
  ".zip", ".gz", ".xz", ".7z", ".rar",
  ".woff", ".woff2",
]);

function comprimir(contenido, nombre) {
  const punto = nombre.lastIndexOf(".");
  const ext = punto === -1 ? "" : nombre.slice(punto).toLowerCase();

  if (YA_COMPRIMIDO.has(ext) || contenido.length === 0) {
    return { metodo: 0, datos: contenido };
  }

  const datos = deflateRawSync(contenido, { level: 6 });
  // Si comprimir no ayuda (pasa con archivos diminutos), se guarda sin tocar.
  return datos.length < contenido.length ? { metodo: 8, datos } : { metodo: 0, datos: contenido };
}

// --- Escritura --------------------------------------------------------------

/**
 * Crea un zip en `destino` con las entradas indicadas.
 *
 * @param {string} destino Ruta del .zip a crear.
 * @param {{origen?: string, nombre: string, esDirectorio?: boolean}[]} entradas
 *   `nombre` es la ruta dentro del zip, siempre con «/». Los directorios no
 *   llevan `origen`.
 * @returns {{archivos: number, bytes: number}}
 */
export function crearZip(destino, entradas) {
  const fd = openSync(destino, "w");
  let offset = 0;
  const central = [];

  const escribir = (buffer) => {
    writeSync(fd, buffer);
    offset += buffer.length;
  };

  try {
    for (const entrada of entradas) {
      const esDir = Boolean(entrada.esDirectorio);
      const nombre = esDir && !entrada.nombre.endsWith("/") ? `${entrada.nombre}/` : entrada.nombre;
      const nombreBuf = Buffer.from(nombre, "utf8");

      const contenido = esDir ? Buffer.alloc(0) : readFileSync(entrada.origen);
      const { metodo, datos } = esDir
        ? { metodo: 0, datos: contenido }
        : comprimir(contenido, nombre);

      const { hora, fecha } = fechaDos(entrada.fechaMod ?? new Date());
      const crc = esDir ? 0 : crc32(contenido);
      const offsetLocal = offset;

      // Cabecera local. El CRC y los tamaños van aquí, ya calculados: es lo
      // que evita el «descriptor de datos» que rompe a algunos descompresores.
      const local = Buffer.alloc(30);
      local.writeUInt32LE(0x04034b50, 0); // firma
      local.writeUInt16LE(20, 4); // versión necesaria: 2.0
      local.writeUInt16LE(0x0800, 6); // bit 11: el nombre va en UTF-8
      local.writeUInt16LE(metodo, 8);
      local.writeUInt16LE(hora, 10);
      local.writeUInt16LE(fecha, 12);
      local.writeUInt32LE(crc, 14);
      local.writeUInt32LE(datos.length, 18);
      local.writeUInt32LE(contenido.length, 22);
      local.writeUInt16LE(nombreBuf.length, 26);
      local.writeUInt16LE(0, 28); // sin campo extra

      escribir(local);
      escribir(nombreBuf);
      if (datos.length > 0) escribir(datos);

      central.push({ nombreBuf, metodo, hora, fecha, crc, comprimido: datos.length, original: contenido.length, offsetLocal, esDir });
    }

    // Directorio central: el índice por el que el descompresor localiza todo.
    const inicioCentral = offset;

    for (const e of central) {
      const cabecera = Buffer.alloc(46);
      cabecera.writeUInt32LE(0x02014b50, 0); // firma
      // Versión «creado por»: 3 = Unix, para que los permisos de abajo cuenten.
      cabecera.writeUInt16LE((3 << 8) | 20, 4);
      cabecera.writeUInt16LE(20, 6);
      cabecera.writeUInt16LE(0x0800, 8);
      cabecera.writeUInt16LE(e.metodo, 10);
      cabecera.writeUInt16LE(e.hora, 12);
      cabecera.writeUInt16LE(e.fecha, 14);
      cabecera.writeUInt32LE(e.crc, 16);
      cabecera.writeUInt32LE(e.comprimido, 20);
      cabecera.writeUInt32LE(e.original, 24);
      cabecera.writeUInt16LE(e.nombreBuf.length, 28);
      cabecera.writeUInt16LE(0, 30); // extra
      cabecera.writeUInt16LE(0, 32); // comentario
      cabecera.writeUInt16LE(0, 34); // disco
      cabecera.writeUInt16LE(0, 36); // atributos internos
      // Permisos de Unix: 755 en carpetas y 644 en archivos. Sin esto, según
      // el servidor, los archivos pueden salir sin permiso de lectura.
      const modo = e.esDir ? 0o40755 : 0o100644;
      cabecera.writeUInt32LE((modo << 16) >>> 0, 38);
      cabecera.writeUInt32LE(e.offsetLocal, 42);

      escribir(cabecera);
      escribir(e.nombreBuf);
    }

    const finCentral = Buffer.alloc(22);
    finCentral.writeUInt32LE(0x06054b50, 0); // firma
    finCentral.writeUInt16LE(0, 4); // número de disco
    finCentral.writeUInt16LE(0, 6); // disco donde empieza el central
    finCentral.writeUInt16LE(central.length, 8);
    finCentral.writeUInt16LE(central.length, 10);
    finCentral.writeUInt32LE(offset - inicioCentral, 12);
    finCentral.writeUInt32LE(inicioCentral, 16);
    finCentral.writeUInt16LE(0, 20); // sin comentario
    escribir(finCentral);
  } finally {
    closeSync(fd);
  }

  return {
    archivos: central.filter((e) => !e.esDir).length,
    bytes: offset,
  };
}
