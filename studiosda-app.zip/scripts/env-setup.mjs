import { createHash, randomBytes } from "node:crypto";
import { execFileSync } from "node:child_process";
import {
  copyFileSync,
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { homedir } from "node:os";
import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";

// fileURLToPath y no new URL().pathname: la ruta del proyecto lleva acentos y
// pathname los devuelve codificados (Cat%C3%A1logos), que no existe en disco.
const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

/**
 * Carpeta de datos externa (la misma que usa iniciar.bat).
 * Vive fuera del proyecto para que no se pierda al actualizar.
 *
 * En un hosting hay que decir dónde va con STUDIOSDA_DATA_DIR: sin eso, en
 * Linux acabaría en ~/AppData/Roaming/StudiosDA, y sobre todo conviene que la
 * base de datos quede fuera de cualquier carpeta que el servidor web sirva
 * como estática, para que nadie pueda descargársela por URL.
 */
function getAppDataDir() {
  if (process.env.STUDIOSDA_DATA_DIR) {
    return path.resolve(process.env.STUDIOSDA_DATA_DIR);
  }

  const base = process.env.APPDATA || path.join(homedir(), "AppData", "Roaming");
  return path.join(base, "StudiosDA");
}

/**
 * Resuelve DATABASE_URL y AUTH_SECRET si no vienen ya del entorno.
 *
 * Se llama desde scripts/next-with-wasm.mjs, que es el único punto por el que
 * pasan todos los arranques (dev, dev:network, build, start), y desde
 * scripts/crear-admin.mjs. Así la app y las herramientas de línea de comandos
 * siempre apuntan a la misma base de datos.
 */
export function setupEnv() {
  const appData = getAppDataDir();

  if (!existsSync(appData)) {
    mkdirSync(appData, { recursive: true });
  }

  if (!process.env.DATABASE_URL) {
    const dbPath = path.join(appData, "dev.db");
    seedExternalDb(dbPath);
    process.env.DATABASE_URL = `file:${dbPath.replace(/\\/g, "/")}`;
  }

  if (!process.env.AUTH_SECRET) {
    process.env.AUTH_SECRET = loadOrCreateSecret(path.join(appData, "auth-secret"));
  }

  return { appData, databaseUrl: process.env.DATABASE_URL };
}

/**
 * Aplica el schema a la base externa cuando `prisma/schema.prisma` ha cambiado.
 *
 * Hace falta porque el instalador de Inno (setup.iss) nunca ejecuta
 * instalar.bat: sin esto, una instalación ya desplegada se actualizaría con
 * código nuevo sobre una base sin las tablas nuevas, y el login fallaría con
 * "no such column". El hash evita pagar el coste del push en cada arranque.
 *
 * Se llama aparte de setupEnv() porque sólo tiene sentido al arrancar la app,
 * no en herramientas de línea de comandos.
 */
export function ensureSchema(appData) {
  const schemaPath = path.join(projectRoot, "prisma", "schema.prisma");
  if (!existsSync(schemaPath)) return;

  const hash = createHash("sha256").update(readFileSync(schemaPath)).digest("hex");
  const markerPath = path.join(appData, "schema-hash");

  if (existsSync(markerPath) && readFileSync(markerPath, "utf8").trim() === hash) {
    return;
  }

  backupDb(appData);

  try {
    console.log("Aplicando cambios del schema a la base de datos...");
    // Se invoca el CLI de Prisma con Node en vez de "npx": desde Node 20,
    // Windows rechaza ejecutar npx.cmd sin shell (EINVAL), y usar shell
    // obligaría a escapar una ruta con acentos y espacios.
    const prismaCli = createRequire(import.meta.url).resolve("prisma/build/index.js");
    execFileSync(process.execPath, [prismaCli, "db", "push", "--skip-generate"], {
      cwd: projectRoot,
      env: process.env,
      stdio: "inherit",
    });
    writeFileSync(markerPath, hash, "utf8");
  } catch (error) {
    // No se escribe el marcador: se reintentará en el siguiente arranque.
    // Arrancar igualmente permite al menos servir el catálogo público.
    console.error("No se pudo aplicar el schema:", error?.message ?? error);
    console.error("La aplicación puede fallar al iniciar sesión.");
  }
}

/**
 * Copia de seguridad antes de tocar el schema, conservando las 5 últimas.
 * `db push` puede recrear tablas para aplicar ciertos cambios en SQLite.
 */
function backupDb(appData) {
  const dbPath = path.join(appData, "dev.db");
  if (!existsSync(dbPath)) return;

  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  copyFileSync(dbPath, path.join(appData, `dev.db.bak-${stamp}`));

  const backups = readdirSync(appData)
    .filter((name) => name.startsWith("dev.db.bak-"))
    .sort();

  for (const old of backups.slice(0, -5)) {
    rmSync(path.join(appData, old), { force: true });
  }
}

/**
 * En la primera ejecución copia la base incluida en el proyecto a la ubicación
 * externa, igual que hace iniciar.bat. Sin esto se arrancaría con un catálogo
 * vacío en vez de con el contenido ya cargado.
 */
function seedExternalDb(dbPath) {
  if (existsSync(dbPath)) return;

  const bundled = path.join(projectRoot, "prisma", "dev.db");
  if (existsSync(bundled)) {
    copyFileSync(bundled, dbPath);
  }
}

/**
 * Lee el secreto de firma de sesiones, generándolo la primera vez.
 *
 * Se guarda junto a la base de datos (no en el repo) para que sobreviva a las
 * actualizaciones: si cambiara en cada despliegue, todas las sesiones abiertas
 * se invalidarían y habría que volver a iniciar sesión.
 */
function loadOrCreateSecret(secretPath) {
  if (existsSync(secretPath)) {
    const existing = readFileSync(secretPath, "utf8").trim();
    if (existing.length >= 32) {
      return existing;
    }
    // Archivo corrupto o truncado: se regenera en vez de arrancar con un
    // secreto débil.
  }

  const secret = randomBytes(32).toString("base64url");
  writeFileSync(secretPath, secret, { encoding: "utf8", mode: 0o600 });
  return secret;
}
