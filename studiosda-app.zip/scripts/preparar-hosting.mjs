#!/usr/bin/env node

/**
 * Prepara en `dist-hosting/` exactamente lo que hay que subir al hosting.
 *
 * Se separa en tres paquetes porque cada uno se sube por un sitio distinto y
 * con una frecuencia distinta:
 *
 *   1. studiosda-app.zip  — el código. Se vuelve a subir en cada actualización.
 *   2. datos/dev.db       — la base de datos. Se sube UNA vez; si se
 *                           sobrescribe después, se pierden los pedidos y las
 *                           cuentas que se hayan creado en el servidor.
 *   3. imagenes-parte-N   — las imágenes (medio giga), troceadas: un zip de
 *                           medio giga se pasa del límite de subida del File
 *                           Manager de casi cualquier hosting compartido.
 *
 * Uso:
 *   node scripts/preparar-hosting.mjs
 *   node scripts/preparar-hosting.mjs --con-imagenes   (además, zips de uploads)
 */

import {
  cpSync,
  existsSync,
  mkdirSync,
  readdirSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { crearZip } from "./lib-zip.mjs";

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const outDir = path.join(projectRoot, "dist-hosting");
const stageDir = path.join(outDir, "_app");
const conImagenes = process.argv.includes("--con-imagenes");

/** Tamaño máximo por trozo de imágenes. Por debajo del límite habitual. */
const MAX_PARTE = 180 * 1024 * 1024;

/**
 * Lo que NO viaja al servidor.
 *
 * node_modules y .next se quedan fuera a propósito: llevan binarios compilados
 * para Windows (Prisma, SWC, sharp) que en Linux no arrancan. Allí se instalan
 * y se compila de nuevo, que es justo lo que hace el guión de despliegue.
 */
const EXCLUIR = new Set([
  "node_modules",
  ".next",
  ".git",
  ".github",
  ".agents",
  ".claude",
  ".vscode",
  "dist-hosting",
  "public/uploads", // van aparte, por FTP
  ".env", // el hosting usa sus propias variables
  "tsconfig.tsbuildinfo",
  // Utilidades del instalador de Windows: en el servidor no pintan nada.
  "Launcher.cs",
  "StudiosDA.exe",
  "setup.iss",
  "compile.bat",
  "iniciar.bat",
  "instalar.bat",
  "migrar-db.bat",
  "prepara-distribucion.bat",
  "promo-10s",
  "promo-10s.mp4",
]);

function excluido(rel) {
  const normal = rel.split(path.sep).join("/");
  if (EXCLUIR.has(normal)) return true;
  // Ninguna base de datos ni copia suya viaja dentro del código: la única
  // buena es la que se sube a la carpeta de datos.
  if (/\.db(-journal|-wal|-shm)?$/.test(normal)) return true;
  if (/\.db\.bak-/.test(normal)) return true;
  if (/^studiosda-backup-.*\.json$/.test(normal)) return true;
  return false;
}

/**
 * Recorre una carpeta y devuelve sus entradas listas para meter en un zip,
 * con las rutas ya en formato ZIP (siempre con «/»).
 */
function listar(raiz, base = "", acumulado = []) {
  for (const nombre of readdirSync(path.join(raiz, base))) {
    const rel = base ? `${base}/${nombre}` : nombre;
    const absoluto = path.join(raiz, rel);
    const info = statSync(absoluto);

    if (info.isDirectory()) {
      acumulado.push({ nombre: rel, esDirectorio: true, tamaño: 0, fechaMod: info.mtime });
      listar(raiz, rel, acumulado);
    } else {
      acumulado.push({ origen: absoluto, nombre: rel, tamaño: info.size, fechaMod: info.mtime });
    }
  }

  return acumulado;
}

/**
 * Reparte las entradas en grupos que no pasen de `maximo` bytes, para que cada
 * zip quepa en el límite de subida del panel. Un archivo más grande que el
 * límite se queda solo en su grupo: partirlo por dentro daría zips que hay que
 * recomponer, y eso ya no lo hace el File Manager.
 */
function trocear(entradas, maximo) {
  const grupos = [];
  let actual = [];
  let tamaño = 0;

  for (const entrada of entradas) {
    if (actual.length > 0 && tamaño + entrada.tamaño > maximo) {
      grupos.push(actual);
      actual = [];
      tamaño = 0;
    }
    actual.push(entrada);
    tamaño += entrada.tamaño;
  }

  if (actual.length > 0) grupos.push(actual);
  return grupos;
}

function mb(file) {
  return (statSync(file).size / (1024 * 1024)).toFixed(1);
}

// ---------------------------------------------------------------------------

console.log("Preparando el paquete para el hosting...\n");

rmSync(outDir, { recursive: true, force: true });
mkdirSync(stageDir, { recursive: true });

// 1. Código.
// Se copia entrada por entrada y no la raíz entera: `cpSync` se niega a copiar
// una carpeta dentro de sí misma, y el destino (dist-hosting) cuelga del
// proyecto.
for (const entrada of readdirSync(projectRoot)) {
  if (excluido(entrada)) continue;

  cpSync(path.join(projectRoot, entrada), path.join(stageDir, entrada), {
    recursive: true,
    filter: (src) => {
      const rel = path.relative(projectRoot, src);
      return !rel || !excluido(rel);
    },
  });
}

// La carpeta de imágenes tiene que existir en el servidor aunque se suba
// después: sin ella, la primera subida desde el panel falla.
mkdirSync(path.join(stageDir, "public", "uploads"), { recursive: true });
writeFileSync(
  path.join(stageDir, "public", "uploads", ".gitkeep"),
  "",
  "utf8"
);

const appZip = path.join(outDir, "studiosda-app.zip");
const resumenApp = crearZip(appZip, listar(stageDir));
rmSync(stageDir, { recursive: true, force: true });
console.log(
  `✓ Código:  dist-hosting/studiosda-app.zip (${mb(appZip)} MB, ${resumenApp.archivos} archivos)`
);

// 2. Base de datos
const dataDir = process.env.STUDIOSDA_DATA_DIR
  ? path.resolve(process.env.STUDIOSDA_DATA_DIR)
  : path.join(process.env.APPDATA || "", "StudiosDA");
const dbOrigen = path.join(dataDir, "dev.db");

if (existsSync(dbOrigen)) {
  const destino = path.join(outDir, "datos");
  mkdirSync(destino, { recursive: true });
  cpSync(dbOrigen, path.join(destino, "dev.db"));
  console.log(`✓ Base de datos:  dist-hosting/datos/dev.db (${mb(dbOrigen)} MB)`);

  // Si la app está abierta, el WAL puede tener escrituras que aún no están en
  // el .db. Copiarlo entero sin avisar dejaría fuera los últimos pedidos.
  if (existsSync(`${dbOrigen}-wal`)) {
    console.log(
      "  ⚠ Hay un archivo -wal: cierra la aplicación y vuelve a ejecutar esto,\n" +
        "    o los últimos cambios podrían no estar en la copia."
    );
  }
} else {
  console.log(`✗ No se encontró la base de datos en ${dbOrigen}`);
}

// 3. Imágenes (opcional), troceadas para que quepan en el límite de subida.
if (conImagenes) {
  const uploads = path.join(projectRoot, "public", "uploads");

  if (existsSync(uploads)) {
    console.log("\nEmpaquetando las imágenes (son cientos de megas, tarda un poco)...");

    const grupos = trocear(listar(uploads), MAX_PARTE);

    grupos.forEach((grupo, i) => {
      const nombre = `imagenes-parte-${i + 1}-de-${grupos.length}.zip`;
      const destino = path.join(outDir, nombre);
      const resumen = crearZip(destino, grupo);
      console.log(`✓ Imágenes:  dist-hosting/${nombre} (${mb(destino)} MB, ${resumen.archivos} archivos)`);
    });
  }
}

console.log(`
Siguiente paso: DESPLIEGUE.md, apartado «Subir los archivos».

  Código      → studiosda-app.zip, se extrae en la carpeta de la aplicación.
  Imágenes    → ${conImagenes ? "cada imagenes-parte-N, se extraen las dos en public/uploads" : "usa --con-imagenes para generarlas"}.
  Base datos  → datos/dev.db, a la carpeta privada de datos. Sólo la primera vez.
`);
