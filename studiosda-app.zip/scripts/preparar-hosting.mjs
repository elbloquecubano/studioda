#!/usr/bin/env node

/**
 * Prepara en `dist-hosting/` exactamente lo que hay que subir al hosting.
 *
 * Se separa en tres paquetes porque cada uno se sube por un sitio distinto y
 * con una frecuencia distinta:
 *
 *   1. studiosda-app.zip  — el código. Se vuelve a subir en cada actualización.
 *   2. datos/dev.db       — la base de datos. Se sube UNA vez; si se
 *                           sobrescribe después, se pierden los pedidos y las
 *                           cuentas que se hayan creado en el servidor.
 *   3. public/uploads     — las imágenes (medio giga). Van por FTP, que
 *                           reanuda si se corta; un zip de ese tamaño suele
 *                           pasarse del límite de subida del File Manager.
 *
 * Uso:
 *   node scripts/preparar-hosting.mjs
 *   node scripts/preparar-hosting.mjs --con-imagenes   (además, zip de uploads)
 */

import { execFileSync } from "node:child_process";
import {
  cpSync,
  existsSync,
  mkdirSync,
  readdirSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const outDir = path.join(projectRoot, "dist-hosting");
const stageDir = path.join(outDir, "_app");
const conImagenes = process.argv.includes("--con-imagenes");

/**
 * Lo que NO viaja al servidor.
 *
 * node_modules y .next se quedan fuera a propósito: llevan binarios compilados
 * para Windows (Prisma, SWC, sharp) que en Linux no arrancan. Allí se instalan
 * y se compila de nuevo, que es justo lo que hace el guión de despliegue.
 */
const EXCLUIR = new Set([
  "node_modules",
  ".next",
  ".git",
  ".github",
  ".agents",
  ".claude",
  ".vscode",
  "dist-hosting",
  "public/uploads", // van aparte, por FTP
  ".env", // el hosting usa sus propias variables
  "tsconfig.tsbuildinfo",
  // Utilidades del instalador de Windows: en el servidor no pintan nada.
  "Launcher.cs",
  "StudiosDA.exe",
  "setup.iss",
  "compile.bat",
  "iniciar.bat",
  "instalar.bat",
  "migrar-db.bat",
  "prepara-distribucion.bat",
  "promo-10s",
  "promo-10s.mp4",
]);

function excluido(rel) {
  const normal = rel.split(path.sep).join("/");
  if (EXCLUIR.has(normal)) return true;
  // Ninguna base de datos ni copia suya viaja dentro del código: la única
  // buena es la que se sube a la carpeta de datos.
  if (/\.db(-journal|-wal|-shm)?$/.test(normal)) return true;
  if (/\.db\.bak-/.test(normal)) return true;
  if (/^studiosda-backup-.*\.json$/.test(normal)) return true;
  return false;
}

/**
 * Comprime en .zip, que es lo que el File Manager de cPanel extrae sin pedir
 * nada.
 *
 * Con `tar.exe` (el bsdtar que trae Windows) y no con Compress-Archive: éste
 * escribe las rutas con la barra invertida de Windows, que el ZIP no admite, y
 * al extraer en Linux salen archivos llamados "src\app\page.tsx" en la raíz en
 * vez de las carpetas. bsdtar las escribe con la barra normal.
 */
function zip(origen, destino) {
  execFileSync("tar.exe", ["-a", "-c", "-f", destino, "-C", origen, "."], {
    stdio: "inherit",
  });
}

function mb(file) {
  return (statSync(file).size / (1024 * 1024)).toFixed(1);
}

// ---------------------------------------------------------------------------

console.log("Preparando el paquete para el hosting...\n");

rmSync(outDir, { recursive: true, force: true });
mkdirSync(stageDir, { recursive: true });

// 1. Código.
// Se copia entrada por entrada y no la raíz entera: `cpSync` se niega a copiar
// una carpeta dentro de sí misma, y el destino (dist-hosting) cuelga del
// proyecto.
for (const entrada of readdirSync(projectRoot)) {
  if (excluido(entrada)) continue;

  cpSync(path.join(projectRoot, entrada), path.join(stageDir, entrada), {
    recursive: true,
    filter: (src) => {
      const rel = path.relative(projectRoot, src);
      return !rel || !excluido(rel);
    },
  });
}

// La carpeta de imágenes tiene que existir en el servidor aunque se suba
// después: sin ella, la primera subida desde el panel falla.
mkdirSync(path.join(stageDir, "public", "uploads"), { recursive: true });
writeFileSync(
  path.join(stageDir, "public", "uploads", ".gitkeep"),
  "",
  "utf8"
);

const appZip = path.join(outDir, "studiosda-app.zip");
zip(stageDir, appZip);
rmSync(stageDir, { recursive: true, force: true });
console.log(`\n✓ Código:  dist-hosting/studiosda-app.zip (${mb(appZip)} MB)`);

// 2. Base de datos
const dataDir = process.env.STUDIOSDA_DATA_DIR
  ? path.resolve(process.env.STUDIOSDA_DATA_DIR)
  : path.join(process.env.APPDATA || "", "StudiosDA");
const dbOrigen = path.join(dataDir, "dev.db");

if (existsSync(dbOrigen)) {
  const destino = path.join(outDir, "datos");
  mkdirSync(destino, { recursive: true });
  cpSync(dbOrigen, path.join(destino, "dev.db"));
  console.log(`✓ Base de datos:  dist-hosting/datos/dev.db (${mb(dbOrigen)} MB)`);

  // Si la app está abierta, el WAL puede tener escrituras que aún no están en
  // el .db. Copiarlo entero sin avisar dejaría fuera los últimos pedidos.
  if (existsSync(`${dbOrigen}-wal`)) {
    console.log(
      "  ⚠ Hay un archivo -wal: cierra la aplicación y vuelve a ejecutar esto,\n" +
        "    o los últimos cambios podrían no estar en la copia."
    );
  }
} else {
  console.log(`✗ No se encontró la base de datos en ${dbOrigen}`);
}

// 3. Imágenes (opcional)
if (conImagenes) {
  const uploads = path.join(projectRoot, "public", "uploads");
  if (existsSync(uploads)) {
    console.log("\nComprimiendo las imágenes (tarda: son cientos de megas)...");
    const zipUploads = path.join(outDir, "studiosda-uploads.zip");
    zip(uploads, zipUploads);
    console.log(`✓ Imágenes:  dist-hosting/studiosda-uploads.zip (${mb(zipUploads)} MB)`);
  }
}

console.log(`
Siguiente paso: DESPLIEGUE.md, apartado «Subir los archivos».

  Código      → studiosda-app.zip, se extrae en la carpeta de la aplicación.
  Imágenes    → public/uploads por FTP (${conImagenes ? "o el zip que se acaba de crear" : "usa --con-imagenes para un zip"}).
  Base datos  → datos/dev.db, a la carpeta privada de datos. Sólo la primera vez.
`);
