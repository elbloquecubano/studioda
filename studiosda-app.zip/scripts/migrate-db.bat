@echo off
chcp 65001 >nul
title Migrar Base de Datos - Studios D-A

:: ============================================
::  Migrador de Base de Datos
::  Copia la DB de una versión vieja a la nueva
:: ============================================

set "APP_DATA=%APPDATA%\StudiosDA"
set "OLD_DB=%~1"
set "NEW_DB=%APP_DATA%\dev.db"

if "%OLD_DB%"=="" (
    echo Uso: migrate-db.bat "ruta\a\la\db\vieja\dev.db"
    echo.
    echo O ejecuta sin argumentos para buscar automaticamente:
    echo   migrate-db.bat
    echo.
    pause
    exit /b 1
)

:: Crear carpeta de datos si no existe
if not exist "%APP_DATA%" mkdir "%APP_DATA%"

:: Verificar si la DB vieja existe
if not exist "%OLD_DB%" (
    echo ERROR: No se encontro la base de datos en:
    echo   %OLD_DB%
    pause
    exit /b 1
)

:: Verificar si ya hay una DB en la nueva ubicación
if exist "%NEW_DB%" (
    echo Ya existe una base de datos en la nueva ubicacion.
    echo.
    echo Opciones:
    echo   1. Conservar la DB actual (no hacer nada)
    echo   2. Reemplazar con la DB vieja
    echo   3. Fusionar (mantener ambos contenidos)
    echo.
    set /p opcion="Selecciona (1/2/3): "
    
    if "%opcion%"=="2" (
        echo Copiando DB vieja...
        copy /Y "%OLD_DB%" "%NEW_DB%"
    ) else if "%opcion%"=="3" (
        echo Fusionando bases de datos...
        call :fusionar "%OLD_DB%" "%NEW_DB%"
    ) else (
        echo Conservando DB actual.
    )
) else (
    echo Copiando base de datos...
    copy "%OLD_DB%" "%NEW_DB%"
)

echo.
echo Listo. La base de datos esta en:
echo   %NEW_DB%
echo.
pause
exit /b 0

:fusionar
set "VIEJA=%~1"
set "NUEVA=%~2"

:: Crear temporal
set "TEMP_DB=%TEMP%\fusion_temp.db"
copy "%NUEVA%" "%TEMP_DB%" >nul

:: Exportar datos de la DB vieja
echo Exportando datos de la version anterior...
"C:\Program Files\SQLite\sqlite3.exe" "%VIEJA%" ".dump" > "%TEMP%\old_dump.sql" 2>nul
if %errorlevel% neq 0 (
    :: Intentar con sqlite3 del PATH
    sqlite3 "%VIEJA%" ".dump" > "%TEMP%\old_dump.sql" 2>nul
)

:: Importar en la nueva (ignorar duplicados)
echo Importando datos...
"C:\Program Files\SQLite\sqlite3.exe" "%NUEVA%" < "%TEMP%\old_dump.sql" 2>nul
if %errorlevel% neq 0 (
    sqlite3 "%NUEVA%" < "%TEMP%\old_dump.sql" 2>nul
)

:: Limpiar
del "%TEMP%\old_dump.sql" >nul 2>&1
del "%TEMP_DB%" >nul 2>&1

echo Fusion completada.
goto :eof