#!/usr/bin/env node
/**
 * Auto-import: si la DB está vacía, importa el backup más reciente
 */
import { PrismaClient } from '@prisma/client';
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { join, resolve } from 'node:path';

const ROOT = resolve(import.meta.url, '..', '..');
const prisma = new PrismaClient();

async function main() {
  const mediaCount = await prisma.media.count();
  if (mediaCount > 0) {
    console.log(`[auto-import] DB tiene ${mediaCount} registros, nada que hacer.`);
    return;
  }

  // Buscar el backup más reciente en la raíz del proyecto
  const backups = readdirSync(ROOT)
    .filter(f => f.startsWith('studiosda-backup') && f.endsWith('.json'))
    .sort()
    .reverse();

  if (backups.length === 0) {
    console.log('[auto-import] No se encontraron backups. DB vacía.');
    return;
  }

  const latest = backups[0];
  const filePath = join(ROOT, latest);
  console.log(`[auto-import] DB vacía. Importando backup: ${latest}`);

  const raw = JSON.parse(readFileSync(filePath, 'utf-8'));

  await prisma.$transaction(async (tx) => {
    if (raw.genres?.length) {
      for (const g of raw.genres) {
        await tx.genre.create({
          data: {
            id: g.id,
            name: g.name,
            slug: g.slug,
            createdAt: g.createdAt ? new Date(g.createdAt) : new Date(),
            updatedAt: g.updatedAt ? new Date(g.updatedAt) : new Date(),
          },
        }).catch(() => {});
      }
    }

    if (raw.media?.length) {
      const batchSize = 100;
      for (let i = 0; i < raw.media.length; i += batchSize) {
        const batch = raw.media.slice(i, i + batchSize);
        await tx.media.createMany({
          data: batch.map((m) => ({
            id: m.id,
            title: m.title,
            type: m.type,
            year: m.year,
            genre: m.genre,
            rating: m.rating,
            synopsis: m.synopsis,
            review: m.review || '',
            posterPath: m.posterPath,
            backdropPath: m.backdropPath,
            isFeatured: m.isFeatured ?? false,
            isAiring: m.isAiring ?? false,
            likes: m.likes ?? 0,
            dislikes: m.dislikes ?? 0,
            createdAt: m.createdAt ? new Date(m.createdAt) : new Date(),
            updatedAt: m.updatedAt ? new Date(m.updatedAt) : new Date(),
            fileSize: m.fileSize ?? null,
          })),
          skipDuplicates: true,
        });
      }
    }
  });

  const finalCount = await prisma.media.count();
  console.log(`[auto-import] Importados ${finalCount} registros.`);
}

main()
  .catch((e) => {
    console.error('[auto-import] Error:', e.message);
    process.exit(0);
  })
  .finally(() => prisma.$disconnect());
