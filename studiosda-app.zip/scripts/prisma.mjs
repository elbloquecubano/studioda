import { spawn } from "node:child_process";
import { createRequire } from "node:module";
import { setupEnv } from "./env-setup.mjs";

/**
 * Ejecuta la CLI de Prisma contra la misma base de datos que usa la aplicación.
 *
 * Sin esto, "npx prisma ..." leería DATABASE_URL del .env y podría aplicar el
 * schema a un archivo distinto del que la app abre al arrancar.
 *
 * Uso: node scripts/prisma.mjs db push
 */
const { databaseUrl } = setupEnv();
console.log(`Prisma -> ${databaseUrl}`);

// Se llama al CLI de Prisma con Node en vez de a npx: Windows rechaza
// ejecutar npx.cmd sin shell desde Node 20 (EINVAL), y shell:true concatenaría
// los argumentos sin escaparlos (DEP0190) sobre una ruta con acentos.
const prismaCli = createRequire(import.meta.url).resolve("prisma/build/index.js");

const child = spawn(process.execPath, [prismaCli, ...process.argv.slice(2)], {
  env: process.env,
  stdio: "inherit",
});

child.on("exit", (code) => process.exit(code ?? 0));
