import { createInterface } from "node:readline/promises";
import { randomBytes } from "node:crypto";
import { writeFileSync } from "node:fs";
import path from "node:path";
import { stdin, stdout } from "node:process";
import { setupEnv } from "./env-setup.mjs";
import {
  hashPassword,
  normalizeUsername,
  validatePassword,
  validateUsername,
} from "./password-hash.mjs";

/**
 * Crea o restablece la cuenta de administrador.
 *
 * Ya no existen credenciales fijas en el código, así que este script es la
 * única vía para entrar al panel la primera vez, y también la de recuperación
 * si se olvida la contraseña.
 *
 *   node scripts/crear-admin.mjs          → interactivo
 *   node scripts/crear-admin.mjs --auto   → sólo si no hay ningún admin;
 *                                           genera una contraseña aleatoria
 */

const { appData } = setupEnv();
const { PrismaClient } = await import("@prisma/client");
const prisma = new PrismaClient();

const auto = process.argv.includes("--auto");

try {
  if (auto) {
    await bootstrapAdmin();
  } else {
    await interactive();
  }
} finally {
  await prisma.$disconnect();
}

/**
 * Arranque desatendido: si no hay ningún administrador, crea uno con
 * contraseña aleatoria y la deja en un archivo. Se apoya en
 * `mustChangePassword` para forzar el cambio en el primer inicio de sesión.
 */
async function bootstrapAdmin() {
  const admins = await prisma.user.count({ where: { role: "ADMIN" } });
  if (admins > 0) return;

  const password = randomBytes(9).toString("base64url");
  const credentialsPath = path.join(appData, "admin-inicial.txt");

  await prisma.user.create({
    data: {
      username: "admin",
      password: await hashPassword(password),
      role: "ADMIN",
      displayName: "Administrador",
      mustChangePassword: true,
    },
  });

  const message =
    `Cuenta de administrador creada\n\n` +
    `  Usuario:     admin\n` +
    `  Contrasena:  ${password}\n\n` +
    `Se te pedira cambiarla al entrar. Borra este archivo despues.\n`;

  // Se escribe en un archivo porque el .exe arranca con la consola oculta y
  // nadie llegaria a leer esto por pantalla.
  writeFileSync(credentialsPath, message, "utf8");

  console.log(`\n${message}\nGuardado en: ${credentialsPath}\n`);
}

async function interactive() {
  const rl = createInterface({ input: stdin, output: stdout });

  try {
    console.log("\n=== Crear o restablecer administrador ===\n");

    const username = normalizeUsername(await rl.question("Usuario: "));
    const usernameProblem = validateUsername(username);
    if (usernameProblem) {
      console.error(`\nError: ${usernameProblem}\n`);
      process.exitCode = 1;
      return;
    }

    const password = await rl.question("Contrasena: ");
    const passwordProblem = validatePassword(password);
    if (passwordProblem) {
      console.error(`\nError: ${passwordProblem}\n`);
      process.exitCode = 1;
      return;
    }

    const confirm = await rl.question("Repite la contrasena: ");
    if (password !== confirm) {
      console.error("\nError: las contrasenas no coinciden\n");
      process.exitCode = 1;
      return;
    }

    const hashed = await hashPassword(password);

    // upsert para que el script sirva igual para crear la cuenta y para
    // restablecer una contrasena olvidada.
    await prisma.user.upsert({
      where: { username },
      create: {
        username,
        password: hashed,
        role: "ADMIN",
        displayName: "Administrador",
      },
      update: {
        password: hashed,
        role: "ADMIN",
        isActive: true,
        mustChangePassword: false,
        failedAttempts: 0,
        lockedUntil: null,
        // Cierra las sesiones abiertas: si la contrasena se restablece porque
        // alguien la comprometio, esas sesiones deben dejar de valer.
        tokenVersion: { increment: 1 },
      },
    });

    console.log(`\nListo. Ya puedes entrar en /admin/login como "${username}".\n`);
  } finally {
    rl.close();
  }
}
