"use client"

import Link from "next/link"
import { Search, Film, LayoutDashboard, ChevronDown, Tags } from "lucide-react"
import { useState, useEffect } from "react"
import SessionButton from "@/components/cuenta/SessionButton"
import { NAV_SECTIONS, useGenresByType } from "@/lib/nav"

/**
 * Barra superior.
 *
 * En móvil se queda sólo con la marca y los accesos directos: la navegación por
 * categorías vive en `MobileNav`, la barra inferior. Antes esta misma barra
 * llevaba también un cajón desplegable con las once categorías repetidas, lo
 * que sumaba unas 600 líneas duplicadas respecto a los menús de escritorio.
 */
export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const genresByType = useGenresByType()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const runSearch = () => {
    const term = searchQuery.trim()
    if (term) window.location.href = `/?search=${encodeURIComponent(term)}`
  }

  return (
    <nav
      className={
        "fixed top-0 left-0 right-0 z-50 transition-all duration-500 px-4 sm:px-6 py-3 sm:py-4 md:px-12 " +
        (isScrolled ? "glass py-3" : "bg-gradient-to-b from-black/80 to-transparent")
      }
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        <Link href="/" className="flex items-center gap-2 group flex-shrink-0 lg:mr-16">
          <div className="w-9 h-9 sm:w-10 sm:h-10 bg-accent rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(229,9,20,0.3)]">
            <Film className="text-black w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <span className="text-xl sm:text-2xl font-bold tracking-tighter text-gradient group-hover:opacity-80 transition-opacity">
            Studios<span className="text-foreground"> D-A</span>
          </span>
        </Link>

        {/* Navegación de escritorio */}
        <div className="hidden lg:flex items-center gap-5">
          <Link href="/" className="text-sm font-medium hover:text-accent transition-colors whitespace-nowrap">
            Inicio
          </Link>

          {NAV_SECTIONS.map((section) => {
            const Icon = section.icon
            const genres = section.genreHref ? genresByType[section.key] ?? [] : []

            return (
              <div key={section.key} className="relative group/nav py-2">
                <button className="text-sm font-medium text-foreground/70 hover:text-foreground transition-colors flex items-center gap-1 cursor-pointer whitespace-nowrap">
                  {section.label}
                  <ChevronDown className="w-3.5 h-3.5 group-hover/nav:rotate-180 transition-transform duration-300" />
                </button>

                <div className="absolute top-full left-0 mt-1 w-48 glass rounded-xl border border-white/10 opacity-0 invisible group-hover/nav:opacity-100 group-hover/nav:visible transition-all duration-300 py-2 shadow-2xl flex flex-col z-50 max-h-64 overflow-y-auto admin-scroll-area">
                  <Link
                    href={section.allHref}
                    className="px-4 py-2 text-xs font-semibold text-accent hover:bg-white/5 transition-colors flex items-center gap-2"
                  >
                    <Icon className="w-3.5 h-3.5" /> {section.allLabel}
                  </Link>

                  <div className="border-t border-white/5 my-1" />

                  {section.staticItems
                    ?.filter((item) => item.href !== section.allHref)
                    .map((item) => (
                      <Link
                        key={item.href}
                        href={item.href}
                        className="px-4 py-2 text-xs font-semibold text-foreground/70 hover:text-accent hover:bg-white/5 transition-colors flex items-center gap-2"
                      >
                        <Icon className="w-3.5 h-3.5" /> {item.label}
                      </Link>
                    ))}

                  {genres.map((genre) => (
                    <Link
                      key={genre}
                      href={section.genreHref!(genre)}
                      className="px-4 py-2 text-xs font-semibold text-foreground/70 hover:text-accent hover:bg-white/5 transition-colors flex items-center gap-2"
                    >
                      <Tags className="w-3.5 h-3.5" /> {genre}
                    </Link>
                  ))}
                </div>
              </div>
            )
          })}
        </div>

        <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
          <div className="relative group hidden lg:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted group-focus-within:text-accent transition-colors" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") runSearch() }}
              placeholder="Buscar..."
              className="bg-white/5 border border-white/10 rounded-full py-1.5 pl-10 pr-4 text-sm w-36 xl:w-56 focus:outline-none focus:ring-1 focus:ring-accent/50 focus:bg-white/10 transition-all"
            />
          </div>

          <div className="hidden lg:block">
            <SessionButton />
          </div>

          <Link
            href="/admin"
            className="p-2 rounded-full hover:bg-white/10 active:bg-white/20 transition-colors"
            title="Administración"
            aria-label="Administración"
          >
            <LayoutDashboard className="w-5 h-5 text-accent" />
          </Link>
        </div>
      </div>
    </nav>
  )
}
