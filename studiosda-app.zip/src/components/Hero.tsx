"use client"

import Image from "next/image"
import Link from "next/link"
import { Play, Info } from "lucide-react"
import { motion } from "framer-motion"
import { useState } from "react"
import type { Media } from "@/lib/types"

interface HeroProps {
  movie: Pick<Media, "id" | "title" | "backdropPath" | "year" | "genre" | "synopsis">
}

export default function Hero({ movie }: HeroProps) {
  const backdropSrc = movie.backdropPath.trim()
  const [imgError, setImgError] = useState(false)

  return (
    <section className="relative w-full overflow-hidden" aria-label={`Destacado: ${movie.title}`}>
      {/* Background Image with Gradients */}
      <div className="absolute inset-0" aria-hidden="true">
        {backdropSrc && !imgError ? (
          <Image
            src={backdropSrc}
            alt=""
            fill
            unoptimized
            sizes="100vw"
            className="object-cover"
            priority
            placeholder="blur"
            blurDataURL="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjExMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjExMiIgZmlsbD0iIzJhMmEyYSIvPjwvc3ZnPg=="
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="absolute inset-0 bg-zinc-800" />
        )}
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>

      {/*
        Content

        La altura es `min-h` y no `h`: con `h` fija el bloque se recortaba por
        el `overflow-hidden` en cuanto el título ocupaba tres líneas, y al estar
        centrado verticalmente se desbordaba también hacia arriba, metiéndose
        bajo la barra fija. En el catálogo 196 de 444 títulos pasan de 20
        caracteres (el más largo tiene 68), así que era el caso normal, no el
        raro.

        `svh` en vez de `vh` porque en móvil `vh` cuenta la barra del navegador
        aunque esté visible, y el hero quedaba más alto que la pantalla real.
      */}
      <div className="relative flex flex-col justify-center min-h-[70svh] sm:min-h-[75vh] lg:min-h-[85vh] px-5 sm:px-6 md:px-12 max-w-4xl pt-28 pb-12 sm:pt-24 sm:pb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center gap-3 mb-3 sm:mb-4">
            <span className="bg-accent/20 text-accent border border-accent/30 px-3 py-1 rounded-full text-[10px] sm:text-xs font-bold tracking-widest uppercase">
              Destacado
            </span>
          </div>

          {/* A 48px un título medio ocupaba tres líneas en 327px de ancho. */}
          <h1 className="text-3xl sm:text-5xl md:text-7xl font-black mb-4 sm:mb-6 tracking-tighter leading-[1.1] line-clamp-3">
            {movie.title}
          </h1>

          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-muted text-xs sm:text-sm md:text-base mb-4 sm:mb-6 font-medium">
            <span>{movie.year}</span>
            <span className="w-1 h-1 rounded-full bg-muted/50" aria-hidden="true" />
            <span className="line-clamp-1">{movie.genre}</span>
          </div>

          <p className="text-foreground/80 text-sm sm:text-lg md:text-xl mb-6 sm:mb-8 line-clamp-2 sm:line-clamp-3 max-w-2xl leading-relaxed">
            {movie.synopsis}
          </p>

          <div className="flex flex-wrap gap-3 sm:gap-4">
            <Link
              href={`/movie/${movie.id}`}
              className="bg-accent text-black font-bold px-5 sm:px-8 py-3 rounded-xl flex items-center gap-2 text-sm sm:text-base active:scale-[0.98] sm:hover:scale-105 transition-transform shadow-[0_0_20px_rgba(229,9,20,0.4)]"
              aria-label={`Ver detalles de ${movie.title}`}
            >
              <Play className="w-4 h-4 sm:w-5 sm:h-5 fill-current" aria-hidden="true" />
              Ver Detalles
            </Link>
            <Link
              href={`/movie/${movie.id}`}
              className="glass font-bold px-5 sm:px-8 py-3 rounded-xl flex items-center gap-2 text-sm sm:text-base hover:bg-white/10 transition-colors"
              aria-label={`Más información sobre ${movie.title}`}
            >
              <Info className="w-4 h-4 sm:w-5 sm:h-5" aria-hidden="true" />
              Más Información
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
