import Image from "next/image"
import Link from "next/link"
import { Calendar, Film, Play } from "lucide-react"
import { getMediaTypeLabel } from "@/lib/types"

interface CategoryHeroProps {
  movie: {
    id: string
    title: string
    type: string
    year: number
    genre: string
    synopsis: string
    posterPath: string
    backdropPath: string
  }
}

export default function CategoryHero({ movie }: CategoryHeroProps) {
  const backdropSrc = movie.backdropPath.trim()
  const posterSrc = movie.posterPath.trim()

  return (
    <section className="relative w-full overflow-hidden" aria-label={`Destacado del catálogo: ${movie.title}`}>
      {/* Backdrop */}
      <div className="absolute inset-0">
        {backdropSrc ? (
          <Image
            src={backdropSrc}
            alt=""
            fill
            sizes="100vw"
            unoptimized
            className="object-cover"
            priority
          />
        ) : (
          <div className="absolute inset-0 bg-zinc-800" />
        )}
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>

      {/*
        Content

        Antes el contenido iba en un `absolute inset-0` sobre un fondo de altura
        fija: al no caber en móvil se desbordaba hacia arriba (por el
        `items-end`) y se metía bajo la barra de navegación, que además no tenía
        ningún hueco reservado. Ahora el contenido define la altura y el fondo
        es quien se estira.
      */}
      <div className="relative flex items-end min-h-[52svh] sm:min-h-[60vh] lg:min-h-[70vh] pt-28 pb-10 sm:pb-16 px-4 sm:px-6 md:px-12">
        <div className="max-w-7xl mx-auto w-full flex flex-row items-end gap-6 sm:gap-8">
          {/* Poster: en móvil sobra, el propio fondo ya es la portada y robaba
              unos 190px de alto a un bloque que no cabía. */}
          <div className="relative hidden sm:block w-36 md:w-44 aspect-[2/3] rounded-xl overflow-hidden shadow-2xl border border-white/10 flex-shrink-0">
            {posterSrc ? (
              <Image
                src={posterSrc}
                alt={movie.title}
                fill
                sizes="(min-width: 768px) 176px, 112px"
                unoptimized
                className="object-cover"
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center bg-zinc-800 p-3 text-center text-xs font-bold uppercase tracking-widest text-muted">
                Sin poster
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex flex-col gap-2.5 sm:gap-3 max-w-2xl min-w-0">
            <div className="flex items-center gap-3">
              <span className="bg-accent/20 text-accent border border-accent/30 px-3 py-1 rounded-full text-[10px] sm:text-xs font-bold uppercase tracking-widest">
                {getMediaTypeLabel(movie.type)}
              </span>
            </div>

            <h1 className="text-2xl sm:text-4xl md:text-5xl font-black tracking-tighter uppercase leading-tight line-clamp-3">
              {movie.title}
            </h1>

            {/* `flex-wrap` y `min-w-0`: los géneros llegan como lista separada
                por comas y desbordaban la fila en pantallas estrechas. */}
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-muted text-xs sm:text-sm font-medium">
              <div className="flex items-center gap-1.5 shrink-0">
                <Calendar className="w-3.5 h-3.5" />
                <span>{movie.year}</span>
              </div>
              <div className="flex items-center gap-1.5 min-w-0">
                <Film className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{movie.genre}</span>
              </div>
            </div>

            <p className="text-foreground/70 text-sm sm:text-base line-clamp-2 sm:line-clamp-3 leading-relaxed">
              {movie.synopsis}
            </p>

            <Link
              href={`/movie/${movie.id}`}
              className="inline-flex items-center gap-2 bg-accent text-black font-bold px-5 sm:px-6 py-2.5 rounded-xl active:scale-[0.98] sm:hover:scale-105 transition-transform shadow-[0_0_20px_rgba(229,9,20,0.4)] w-fit mt-1 text-sm"
            >
              <Play className="w-4 h-4 fill-current" />
              Ver Detalles
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
