"use client"

import { useRef, useState, useEffect, useCallback } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface CarouselProps {
  children: React.ReactNode
  cardWidth?: number
  speed?: number
}

export default function Carousel({ children, cardWidth = 200, speed = 0.8 }: CarouselProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [canScrollLeft, setCanScrollLeft] = useState(false)
  const [canScrollRight, setCanScrollRight] = useState(true)
  const rafRef = useRef<number | null>(null)
  const pausedRef = useRef(false)
  const halfWRef = useRef(0)

  const childrenArray = Array.isArray(children) ? children : [children]
  const doubled = [...childrenArray, ...childrenArray]

  const updateArrows = useCallback(() => {
    const el = containerRef.current
    if (!el) return
    setCanScrollLeft(el.scrollLeft > 8)
    setCanScrollRight(el.scrollLeft + el.clientWidth < el.scrollWidth - 8)
  }, [])

  useEffect(() => {
    const el = containerRef.current
    if (!el) return
    const ro = new ResizeObserver(() => {
      halfWRef.current = el.scrollWidth / 2
      updateArrows()
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [updateArrows])

  useEffect(() => {
    const el = containerRef.current
    if (!el) return
    halfWRef.current = el.scrollWidth / 2

    const animate = () => {
      if (!pausedRef.current) {
        let pos = el.scrollLeft + speed
        const halfW = el.scrollWidth / 2
        if (pos >= halfW) pos = 0
        el.scrollLeft = pos
        updateArrows()
      }
      rafRef.current = requestAnimationFrame(animate)
    }
    rafRef.current = requestAnimationFrame(animate)

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [speed, updateArrows])

  const pause = () => { pausedRef.current = true }
  const resume = () => { pausedRef.current = false }

  useEffect(() => {
    const el = containerRef.current
    if (!el) return
    el.addEventListener("mouseenter", pause)
    el.addEventListener("mouseleave", resume)
    return () => {
      el.removeEventListener("mouseenter", pause)
      el.removeEventListener("mouseleave", resume)
    }
  }, [])

  const scroll = useCallback((dir: "left" | "right") => {
    const el = containerRef.current
    if (!el) return
    const amount = dir === "left" ? -cardWidth * 4 : cardWidth * 4
    pausedRef.current = true
    el.style.scrollBehavior = "smooth"
    el.scrollBy({ left: amount })
    const onEnd = () => {
      el.style.scrollBehavior = ""
      updateArrows()
      pausedRef.current = false
      el.removeEventListener("scrollend", onEnd)
    }
    el.addEventListener("scrollend", onEnd, { once: true })
  }, [cardWidth, updateArrows])

  return (
    <div className="relative group/carousel w-screen -ml-[50vw] left-1/2">
      <div
        ref={containerRef}
        className="flex gap-4 sm:gap-6 overflow-x-auto pb-2 px-4 sm:px-6 md:px-12"
        style={{ scrollbarWidth: "none", overflowY: "hidden" }}
      >
        {doubled.map((child, i) => (
          <div key={i} className="flex-shrink-0 w-[45vw] sm:w-[200px]">
            {child}
          </div>
        ))}
      </div>

      {canScrollLeft && (
        <button
          onClick={() => scroll("left")}
          type="button"
          className="absolute left-2 top-0 bottom-0 z-10 w-12 bg-gradient-to-r from-background via-background/80 to-transparent flex items-center justify-start pl-2 opacity-0 group-hover/carousel:opacity-100 transition-opacity"
        >
          <ChevronLeft className="w-6 h-6 text-white drop-shadow-lg" />
        </button>
      )}
      {canScrollRight && (
        <button
          onClick={() => scroll("right")}
          type="button"
          className="absolute right-2 top-0 bottom-0 z-10 w-12 bg-gradient-to-l from-background via-background/80 to-transparent flex items-center justify-end pr-2 opacity-0 group-hover/carousel:opacity-100 transition-opacity"
        >
          <ChevronRight className="w-6 h-6 text-white drop-shadow-lg" />
        </button>
      )}
    </div>
  )
}
