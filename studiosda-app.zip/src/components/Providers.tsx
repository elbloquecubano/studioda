"use client"

import { ToastProvider } from "@/components/ui/Toast"
import { ConfirmProvider } from "@/components/ui/ConfirmDialog"

export default function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ToastProvider>
      <ConfirmProvider>
        {children}
      </ConfirmProvider>
    </ToastProvider>
  )
}
