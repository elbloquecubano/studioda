"use client"

import { useEffect, useMemo, useState } from "react"
import Link from "next/link"
import { mutate } from "swr"
import {
  AlertCircle,
  Check,
  Eye,
  EyeOff,
  Loader2,
  MapPin,
  Phone,
  ShoppingBag,
  Trash2,
  User,
} from "lucide-react"
import { PENDING_ORDERS_KEY } from "@/components/admin/AdminSidebar"
import { useToast } from "@/components/ui/Toast"
import { useConfirm } from "@/components/ui/ConfirmDialog"
import { formatPrice } from "@/lib/pricing"
import { cn } from "@/lib/utils"

interface OrderUser {
  id: string
  username: string
  displayName: string | null
  phone: string | null
  address: string | null
}

interface Order {
  id: string
  mediaId: string | null
  titleSnapshot: string
  priceSnapshot: number | null
  /** Falso mientras el cliente sigue viendo «Esperando monto» en vez de la cifra. */
  priceConfirmed: boolean
  status: string
  notes: string | null
  createdAt: string
  user: OrderUser
}

interface ClientGroup {
  user: OrderUser
  orders: Order[]
  total: number
  /** Pedidos sin precio guardado: el total no los incluye y hay que avisarlo. */
  missingPrice: number
  latest: number
}

const STATUSES = ["PENDIENTE", "LISTO", "ENTREGADO", "CANCELADO"] as const

const STATUS_META: Record<string, { label: string; tone: string }> = {
  PENDIENTE: { label: "En proceso", tone: "bg-accent-blue/20 text-accent-blue border-accent-blue/30" },
  LISTO: { label: "Listo", tone: "bg-green-500/20 text-green-500 border-green-500/30" },
  ENTREGADO: { label: "Entregado", tone: "bg-white/10 text-muted border-white/10" },
  CANCELADO: { label: "Cancelado", tone: "bg-red-500/20 text-red-500 border-red-500/30" },
}

async function readApiError(response: Response, fallback: string) {
  try {
    const data = (await response.json()) as { error?: string }
    return data.error || fallback
  } catch {
    return fallback
  }
}

/**
 * Campo del monto de un pedido.
 *
 * Guarda al salir del campo o al pulsar Enter, no en cada tecla: escribir «15»
 * pasa por «1», y un guardado por pulsación dejaría montos a medias en la base
 * y avisos de guardado en cadena. Mantiene su propio texto mientras se edita y
 * sólo vuelve a mirar el pedido cuando el importe guardado cambia.
 */
function AmountField({
  order,
  disabled,
  onSave,
}: {
  order: Order
  disabled: boolean
  onSave: (raw: string) => Promise<boolean>
}) {
  const stored = order.priceSnapshot === null ? "" : String(order.priceSnapshot)
  const [value, setValue] = useState(stored)
  const [lastStored, setLastStored] = useState(stored)

  // Resincronizar durante el render y no en un efecto: así el campo ya sale
  // pintado con el monto nuevo, sin un fotograma mostrando el viejo.
  if (stored !== lastStored) {
    setLastStored(stored)
    setValue(stored)
  }

  const commit = async () => {
    if (value.trim() === stored) return
    const ok = await onSave(value)
    // Si el servidor lo rechaza, el campo vuelve a lo que sí está guardado:
    // dejar el número inválido a la vista haría creer que se aplicó.
    if (!ok) setValue(stored)
  }

  return (
    <input
      type="text"
      inputMode="decimal"
      value={value}
      disabled={disabled}
      onChange={(e) => setValue(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === "Enter") e.currentTarget.blur()
        if (e.key === "Escape") setValue(stored)
      }}
      placeholder="Sin monto"
      aria-label={`Monto del pedido de ${order.titleSnapshot}`}
      className={cn(
        "w-24 bg-white/5 border rounded-lg px-2.5 py-1 text-sm font-bold text-foreground",
        "focus:outline-none focus:border-accent/50 disabled:opacity-50",
        "placeholder:text-amber-500/70 placeholder:font-normal",
        order.priceConfirmed ? "border-white/10" : "border-amber-500/30"
      )}
    />
  )
}

export default function AdminOrders() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<string>("PENDIENTE")
  const [busyId, setBusyId] = useState<string | null>(null)
  const [busyUserId, setBusyUserId] = useState<string | null>(null)
  const { toast } = useToast()
  const { confirm } = useConfirm()

  useEffect(() => {
    let isActive = true

    fetch("/api/admin/orders")
      .then((res) => res.json())
      .then((data: Order[]) => {
        if (isActive) setOrders(Array.isArray(data) ? data : [])
      })
      .catch(() => {
        toast("Error al cargar los pedidos.", "error")
      })
      .finally(() => {
        if (isActive) setLoading(false)
      })

    return () => {
      isActive = false
    }
  }, [])

  const counts = useMemo(() => {
    const result: Record<string, number> = {}
    for (const order of orders) {
      result[order.status] = (result[order.status] ?? 0) + 1
    }
    return result
  }, [orders])

  /**
   * Agrupa por cliente los pedidos que pasan el filtro y suma lo que debe cada
   * uno. Los cancelados nunca entran en el total aunque se estén mostrando: no
   * se cobran, y sumarlos daría una cifra que no se corresponde con nada.
   */
  const groups = useMemo<ClientGroup[]>(() => {
    const visible = filter === "TODOS" ? orders : orders.filter((o) => o.status === filter)
    const byUser = new Map<string, ClientGroup>()

    for (const order of visible) {
      let group = byUser.get(order.user.id)
      if (!group) {
        group = { user: order.user, orders: [], total: 0, missingPrice: 0, latest: 0 }
        byUser.set(order.user.id, group)
      }

      group.orders.push(order)

      if (order.status !== "CANCELADO") {
        if (order.priceSnapshot === null) {
          group.missingPrice += 1
        } else {
          group.total += order.priceSnapshot
        }
      }

      group.latest = Math.max(group.latest, new Date(order.createdAt).getTime())
    }

    // El cliente que pidió algo más recientemente, primero.
    return Array.from(byUser.values()).sort((a, b) => b.latest - a.latest)
  }, [orders, filter])

  /**
   * Montos listos para confirmar de cada cliente. Se cuenta sobre todos sus
   * pedidos y no sólo sobre los que pasan el filtro, porque el botón confirma
   * la cuenta entera: enseñar aquí la cifra de la vista filtrada prometería
   * menos de lo que el botón hace.
   */
  const pendingByUser = useMemo(() => {
    const result = new Map<string, number>()
    for (const order of orders) {
      if (order.status === "CANCELADO" || order.priceConfirmed || order.priceSnapshot === null) {
        continue
      }
      result.set(order.user.id, (result.get(order.user.id) ?? 0) + 1)
    }
    return result
  }, [orders])

  const grandTotal = useMemo(() => groups.reduce((sum, g) => sum + g.total, 0), [groups])
  const visibleCount = useMemo(() => groups.reduce((n, g) => n + g.orders.length, 0), [groups])

  const changeStatus = async (id: string, status: string) => {
    const previous = orders
    // Optimista: el select ya muestra el estado nuevo, y si el servidor falla
    // se restaura la lista anterior.
    setOrders((current) => current.map((o) => (o.id === id ? { ...o, status } : o)))
    setBusyId(id)

    try {
      const res = await fetch("/api/admin/orders", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status }),
      })

      if (!res.ok) {
        setOrders(previous)
        toast(await readApiError(res, "No se pudo cambiar el estado."), "error")
        return
      }

      toast(`Pedido marcado como «${STATUS_META[status]?.label ?? status}».`, "success")
      // Despachar un pedido apaga su aviso en el menú lateral; sin esto habría
      // que esperar hasta 30 s al siguiente sondeo.
      mutate(PENDING_ORDERS_KEY)
    } catch {
      setOrders(previous)
      toast("Error de conexión.", "error")
    } finally {
      setBusyId(null)
    }
  }

  /** Aplica sobre la lista los campos que devuelve el servidor tras un PATCH. */
  const applyPatch = (id: string, patch: Partial<Order>) => {
    setOrders((current) => current.map((o) => (o.id === id ? { ...o, ...patch } : o)))
  }

  /**
   * Guarda el monto que ha escrito el admin. Devuelve si se pudo guardar, para
   * que el campo pueda volver al valor anterior cuando no.
   */
  const saveAmount = async (order: Order, raw: string): Promise<boolean> => {
    const trimmed = raw.trim().replace(",", ".")
    const amount = trimmed === "" ? null : Number(trimmed)

    if (amount !== null && (!Number.isFinite(amount) || amount < 0)) {
      toast("El monto tiene que ser un número de cero para arriba.", "error")
      return false
    }

    const rounded = amount === null ? null : Math.round(amount * 100) / 100
    if (rounded === order.priceSnapshot) return true

    setBusyId(order.id)

    try {
      const res = await fetch("/api/admin/orders", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: order.id, amount: rounded }),
      })

      if (!res.ok) {
        toast(await readApiError(res, "No se pudo guardar el monto."), "error")
        return false
      }

      const updated = (await res.json()) as Pick<Order, "priceSnapshot" | "priceConfirmed">
      applyPatch(order.id, {
        priceSnapshot: updated.priceSnapshot,
        priceConfirmed: updated.priceConfirmed,
      })

      toast(
        rounded === null
          ? "Monto borrado. El cliente vuelve a ver «Esperando monto»."
          : `Monto guardado: ${formatPrice(rounded)}.`,
        "success"
      )
      return true
    } catch {
      toast("Error de conexión.", "error")
      return false
    } finally {
      setBusyId(null)
    }
  }

  /** Publica u oculta el monto de un pedido para su cliente. */
  const toggleConfirm = async (order: Order) => {
    if (!order.priceConfirmed && order.priceSnapshot === null) {
      toast("Escribe el monto antes de confirmarlo.", "error")
      return
    }

    const confirmed = !order.priceConfirmed
    setBusyId(order.id)

    try {
      const res = await fetch("/api/admin/orders", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: order.id, confirmed }),
      })

      if (!res.ok) {
        toast(await readApiError(res, "No se pudo cambiar el monto."), "error")
        return
      }

      applyPatch(order.id, { priceConfirmed: confirmed })
      toast(
        confirmed
          ? "Monto confirmado: el cliente ya lo ve."
          : "Monto oculto: el cliente vuelve a ver «Esperando monto».",
        "success"
      )
    } catch {
      toast("Error de conexión.", "error")
    } finally {
      setBusyId(null)
    }
  }

  /** Confirma de golpe toda la cuenta de un cliente. */
  const confirmGroup = async (group: ClientGroup) => {
    setBusyUserId(group.user.id)

    try {
      const res = await fetch("/api/admin/orders/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: group.user.id }),
      })

      if (!res.ok) {
        toast(await readApiError(res, "No se pudieron confirmar los montos."), "error")
        return
      }

      const { confirmed, skipped } = (await res.json()) as { confirmed: string[]; skipped: number }
      const done = new Set(confirmed)
      setOrders((current) =>
        current.map((o) => (done.has(o.id) ? { ...o, priceConfirmed: true } : o))
      )

      if (confirmed.length === 0 && skipped === 0) {
        toast("No había montos pendientes de confirmar.", "info")
      } else {
        toast(
          skipped > 0
            ? `${confirmed.length} montos confirmados. ${skipped} siguen sin precio.`
            : `Montos confirmados: el cliente ya ve su total.`,
          skipped > 0 ? "info" : "success"
        )
      }
    } catch {
      toast("Error de conexión.", "error")
    } finally {
      setBusyUserId(null)
    }
  }

  const remove = async (order: Order) => {
    const ok = await confirm({
      title: "Eliminar pedido",
      message: `Se eliminará el pedido de «${order.titleSnapshot}». Esta acción no se puede deshacer.`,
      confirmLabel: "Eliminar",
      danger: true,
    })
    if (!ok) return

    const previous = orders
    setOrders((current) => current.filter((o) => o.id !== order.id))

    try {
      const res = await fetch("/api/admin/orders", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: order.id }),
      })

      if (!res.ok) {
        setOrders(previous)
        toast(await readApiError(res, "No se pudo eliminar el pedido."), "error")
        return
      }

      toast("Pedido eliminado.", "success")
      mutate(PENDING_ORDERS_KEY)
    } catch {
      setOrders(previous)
      toast("Error de conexión.", "error")
    }
  }

  if (loading) {
    return (
      <div className="flex items-center gap-3 text-muted">
        <Loader2 className="w-5 h-5 animate-spin" />
        Cargando pedidos…
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-black tracking-tighter border-l-4 border-accent pl-4">
          Pedidos
        </h1>
        <p className="text-muted mt-2 pl-5">
          Agrupados por cliente, con lo que debe cada uno. El monto es editable y el cliente ve
          «Esperando monto» hasta que lo confirmas.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {["TODOS", ...STATUSES].map((value) => {
          const label = value === "TODOS" ? "Todos" : STATUS_META[value].label
          const count = value === "TODOS" ? orders.length : counts[value] ?? 0
          return (
            <button
              key={value}
              type="button"
              onClick={() => setFilter(value)}
              className={cn(
                "px-4 py-2 rounded-xl text-sm font-bold transition-all border",
                filter === value
                  ? "bg-accent text-black border-accent"
                  : "bg-white/5 text-muted border-white/10 hover:bg-white/10 hover:text-foreground"
              )}
            >
              {label} <span className="opacity-60">({count})</span>
            </button>
          )
        })}
      </div>

      {groups.length === 0 ? (
        <div className="glass rounded-3xl p-12 border border-white/5 text-center">
          <ShoppingBag className="w-12 h-12 text-muted mx-auto mb-4" />
          <p className="font-bold text-lg">No hay pedidos aquí</p>
          <p className="text-muted text-sm mt-2">
            {filter === "TODOS"
              ? "Todavía nadie ha apartado nada del catálogo."
              : "Prueba con otro estado."}
          </p>
        </div>
      ) : (
        <>
          <div className="glass rounded-2xl p-5 border border-accent/20 flex flex-wrap items-center justify-between gap-3">
            <span className="text-sm text-muted font-medium">
              {groups.length} {groups.length === 1 ? "cliente" : "clientes"} · {visibleCount}{" "}
              {visibleCount === 1 ? "pedido" : "pedidos"}
            </span>
            <span className="text-sm font-bold">
              Total general:{" "}
              <span className="text-accent text-xl font-black">{formatPrice(grandTotal)}</span>
            </span>
          </div>

          <div className="space-y-5">
            {groups.map((group) => {
              const pending = pendingByUser.get(group.user.id) ?? 0

              return (
                <div
                  key={group.user.id}
                  className="glass rounded-3xl border border-white/5 overflow-hidden"
                >
                {/* Cabecera del cliente: los datos que hacen falta para el reparto */}
                <div className="p-5 border-b border-white/5 bg-white/[0.02] flex flex-col lg:flex-row lg:items-start gap-4 justify-between">
                  <div className="min-w-0 space-y-2">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-accent shrink-0" />
                      <span className="font-bold text-lg truncate">
                        {group.user.displayName || group.user.username}
                      </span>
                      <span className="text-xs text-muted shrink-0">@{group.user.username}</span>
                    </div>

                    {group.user.phone && (
                      <a
                        href={`tel:${group.user.phone}`}
                        className="flex items-center gap-2 text-sm text-muted hover:text-accent transition-colors w-fit"
                      >
                        <Phone className="w-3.5 h-3.5 shrink-0" />
                        {group.user.phone}
                      </a>
                    )}

                    {group.user.address ? (
                      <p className="flex items-start gap-2 text-sm text-muted">
                        <MapPin className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                        <span className="whitespace-pre-wrap">{group.user.address}</span>
                      </p>
                    ) : (
                      <p className="flex items-center gap-2 text-sm text-amber-500/80">
                        <MapPin className="w-3.5 h-3.5 shrink-0" />
                        Sin dirección registrada
                      </p>
                    )}
                  </div>

                  <div className="shrink-0 text-right">
                    <p className="text-xs uppercase tracking-widest text-muted font-bold">
                      Total a cobrar
                    </p>
                    <p className="text-3xl font-black text-accent">{formatPrice(group.total)}</p>
                    <p className="text-xs text-muted mt-1">
                      {group.orders.length} {group.orders.length === 1 ? "título" : "títulos"}
                    </p>
                    {group.missingPrice > 0 && (
                      <p className="flex items-center gap-1.5 text-xs text-amber-500 mt-2 justify-end">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        {group.missingPrice} sin monto
                      </p>
                    )}

                    {/* El cliente no ve nada de esto hasta que se confirma. */}
                    {pending > 0 ? (
                      <button
                        type="button"
                        onClick={() => confirmGroup(group)}
                        disabled={busyUserId === group.user.id}
                        className="mt-3 inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-accent text-black text-sm font-bold hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:hover:scale-100 transition-all"
                      >
                        {busyUserId === group.user.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Check className="w-4 h-4" />
                        )}
                        Confirmar {pending} {pending === 1 ? "monto" : "montos"}
                      </button>
                    ) : (
                      group.total > 0 && (
                        <p className="flex items-center gap-1.5 text-xs text-green-500 mt-3 justify-end">
                          <Eye className="w-3.5 h-3.5 shrink-0" />
                          El cliente ve su total
                        </p>
                      )
                    )}
                  </div>
                </div>

                <div className="divide-y divide-white/5">
                  {group.orders.map((order) => {
                    const meta = STATUS_META[order.status] ?? {
                      label: order.status,
                      tone: "bg-white/10 text-muted border-white/10",
                    }

                    return (
                      <div
                        key={order.id}
                        className="p-4 flex flex-col sm:flex-row sm:items-center gap-3 justify-between"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-3 flex-wrap">
                            {order.mediaId ? (
                              <Link
                                href={`/movie/${order.mediaId}`}
                                className="font-bold truncate hover:text-accent transition-colors"
                              >
                                {order.titleSnapshot}
                              </Link>
                            ) : (
                              <span className="font-bold truncate">{order.titleSnapshot}</span>
                            )}
                            <span
                              className={cn(
                                "shrink-0 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-widest border",
                                meta.tone
                              )}
                            >
                              {meta.label}
                            </span>
                          </div>

                          <div className="flex items-center gap-3 flex-wrap text-xs text-muted mt-1.5">
                            <AmountField
                              order={order}
                              disabled={busyId === order.id}
                              onSave={(raw) => saveAmount(order, raw)}
                            />
                            <span>
                              {new Date(order.createdAt).toLocaleDateString("es", {
                                day: "numeric",
                                month: "long",
                                year: "numeric",
                              })}
                            </span>
                          </div>

                          {order.notes && (
                            <p className="text-sm text-muted mt-1.5 italic">«{order.notes}»</p>
                          )}
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => toggleConfirm(order)}
                            disabled={busyId === order.id}
                            title={
                              order.priceConfirmed
                                ? "Ocultar el monto al cliente"
                                : "Mostrar el monto al cliente"
                            }
                            aria-label={
                              order.priceConfirmed
                                ? `Ocultar el monto del pedido de ${order.titleSnapshot}`
                                : `Confirmar el monto del pedido de ${order.titleSnapshot}`
                            }
                            className={cn(
                              "flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition-all disabled:opacity-50",
                              order.priceConfirmed
                                ? "bg-green-500/15 text-green-500 border-green-500/30 hover:bg-green-500/25"
                                : "bg-amber-500/15 text-amber-500 border-amber-500/30 hover:bg-amber-500/25"
                            )}
                          >
                            {order.priceConfirmed ? (
                              <Eye className="w-3.5 h-3.5" />
                            ) : (
                              <EyeOff className="w-3.5 h-3.5" />
                            )}
                            {order.priceConfirmed ? "Visible" : "Confirmar"}
                          </button>

                          <select
                            value={order.status}
                            disabled={busyId === order.id}
                            onChange={(e) => changeStatus(order.id, e.target.value)}
                            aria-label={`Estado del pedido de ${order.titleSnapshot}`}
                            className="bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm font-semibold focus:outline-none focus:border-accent/50 disabled:opacity-50"
                          >
                            {STATUSES.map((value) => (
                              <option key={value} value={value} className="bg-card">
                                {STATUS_META[value].label}
                              </option>
                            ))}
                          </select>

                          <button
                            type="button"
                            onClick={() => remove(order)}
                            aria-label={`Eliminar el pedido de ${order.titleSnapshot}`}
                            className="p-2.5 rounded-xl text-red-500/70 hover:bg-red-500/10 hover:text-red-500 transition-all"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    )
                  })}
                  </div>
                </div>
              )
            })}
          </div>
        </>
      )}
    </div>
  )
}
