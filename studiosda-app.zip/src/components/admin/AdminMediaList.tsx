"use client"

import { useState, useEffect, useRef, useMemo, useCallback, memo } from "react"
import { Film, Tv, Gamepad2, Star, Trash2, Edit, ExternalLink, Loader2, Search, Filter, Monitor, ChevronDown, Radio, ChevronLeft, ChevronRight } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import SocialCardGenerator from "./SocialCardGenerator"
import { getMediaTypeLabel } from "@/lib/types"
import { useToast } from "@/components/ui/Toast"
import { useConfirm } from "@/components/ui/ConfirmDialog"

interface Media {
  id: string
  title: string
  type: string
  year: number
  genre: string
  posterPath: string
  backdropPath: string | null
  synopsis: string
  isFeatured: boolean
  isAiring: boolean
}

const PAGE_SIZE = 50

const filterGroups = [
  {
    label: "Audiovisual",
    icon: Monitor,
    items: [
      { value: "All", label: "Todos" },
      { value: "Movie", label: "Películas" },
      { value: "Series", label: "Series" },
      { value: "Dorama", label: "Doramas" },
      { value: "Novela", label: "Novelas (General)" },
      { value: "Novela_Brasil", label: "Novelas Brasileñas" },
      { value: "Novela_Colombia", label: "Novelas Colombianas" },
      { value: "Novela_Turca", label: "Novelas Turcas" },
      { value: "Novela_Mexicana", label: "Novelas Mexicanas" },
      { value: "Novela_Cristiana", label: "Novelas Cristianas" },
      { value: "Novela_Otros", label: "Otras Novelas" },
      { value: "Reality", label: "Realitys" },
      { value: "Anime", label: "Animes" },
      { value: "Dongchua", label: "Dongchua" },
      { value: "Animated_Series", label: "Animados (Serie)" },
      { value: "Animated_Movie", label: "Animados (Filme)" },
      { value: "Deportes", label: "Deportes" },
    ],
  },
  {
    label: "Videojuegos",
    icon: Gamepad2,
    items: [
      { value: "Game_PC", label: "PC" },
      { value: "Game_Mobile", label: "Móvil" },
      { value: "Game_PS1", label: "PlayStation 1" },
      { value: "Game_PS2", label: "PlayStation 2" },
      { value: "Game_PS3", label: "PlayStation 3" },
      { value: "Game_PS4", label: "PlayStation 4" },
      { value: "Game_Xbox_360", label: "Xbox 360" },
      { value: "Game_Switch", label: "Nintendo Switch" },
      { value: "Game_PSP", label: "PSP" },
      { value: "Game_3DS", label: "Nintendo 3DS" },
      { value: "Game_Wii", label: "Wii" },
    ],
  },
]

const AdminMediaItem = memo(function AdminMediaItem({
  item,
  onToggleFeatured,
  onDelete,
}: {
  item: Media
  onToggleFeatured: (id: string, current: boolean) => void
  onDelete: (id: string) => void
}) {
  const backdropSrc = item.backdropPath?.trim() || ""
  const posterSrc = item.posterPath?.trim() || ""

  return (
    <div className="relative rounded-2xl overflow-hidden border border-white/10 group">
      <div className="absolute inset-0">
        {backdropSrc ? (
          <Image src={backdropSrc} alt={item.title} fill className="object-cover opacity-20" loading="lazy" sizes="100vw" />
        ) : posterSrc ? (
          <Image src={posterSrc} alt={item.title} fill className="object-cover opacity-10 blur-sm" loading="lazy" sizes="100vw" />
        ) : (
          <div className="absolute inset-0 bg-white/5" />
        )}
        <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/90 to-[#050505]/60" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-[#050505]/40" />
      </div>

      <div className="relative z-10 flex flex-col md:flex-row items-stretch gap-6 md:gap-10 p-6 md:p-8">
        <div className="flex items-center gap-6 md:gap-10 flex-grow min-w-0">
          <div className="relative w-[120px] h-[180px] md:w-[140px] md:h-[210px] rounded-xl overflow-hidden shadow-2xl border border-white/10 flex-shrink-0">
            {posterSrc ? (
              <Image src={posterSrc} alt={item.title} fill className="object-cover" loading="lazy" sizes="140px" />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-white/5">
                <Film className="w-8 h-8 text-muted" />
              </div>
            )}
          </div>

          <div className="flex flex-col justify-center min-w-0">
            <div className="flex items-center gap-3 mb-3 flex-wrap">
              <span className="bg-accent/20 text-accent border border-accent/30 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                {getMediaTypeLabel(item.type)}
              </span>
              {item.isAiring && (
                <span className="bg-green-500/20 text-green-400 border border-green-500/30 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1">
                  <Radio className="w-2.5 h-2.5" />
                  En Transmisión
                </span>
              )}
            </div>

            <h3 className="text-2xl md:text-4xl font-black tracking-tighter uppercase mb-3 text-white">
              {item.title}
            </h3>

            <div className="flex items-center gap-4 text-sm text-muted mb-4 font-medium">
              <span>{item.year}</span>
              <span className="text-white/20">|</span>
              <span className="truncate">{item.genre}</span>
            </div>

            <p className="text-sm text-foreground/60 leading-relaxed line-clamp-2 max-w-2xl hidden md:block">
              {item.synopsis}
            </p>
          </div>
        </div>

        <div className="flex md:flex-col items-center gap-2 md:opacity-0 md:group-hover:opacity-100 transition-opacity flex-shrink-0 justify-end">
          <button
            onClick={() => onToggleFeatured(item.id, item.isFeatured)}
            className={`p-2.5 rounded-xl transition-all ${item.isFeatured ? 'bg-accent/20 text-accent' : 'hover:bg-white/10 text-muted'}`}
            title={item.isFeatured ? "Quitar de destacados" : "Marcar como destacado"}
          >
            <Star className={`w-4 h-4 ${item.isFeatured ? 'fill-accent' : ''}`} />
          </button>
          <SocialCardGenerator
            title={item.title}
            posterPath={item.posterPath}
            backdropPath={item.backdropPath}
            synopsis={item.synopsis}
            genre={item.genre}
            year={item.year}
            type={item.type}
          />
          <Link
            href={`/admin/edit/${item.id}`}
            className="p-2.5 rounded-xl hover:bg-white/10 text-muted hover:text-accent transition-all"
            title="Editar"
          >
            <Edit className="w-4 h-4" />
          </Link>
          <button
            onClick={() => onDelete(item.id)}
            className="p-2.5 rounded-xl hover:bg-red-500/10 text-red-500/50 hover:text-red-500 transition-all"
            title="Eliminar"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <a
            href={`/movie/${item.id}`}
            target="_blank"
            className="p-2.5 rounded-xl hover:bg-white/10 text-muted hover:text-foreground transition-all"
            title="Ver en el sitio"
          >
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>
    </div>
  )
})

export default function AdminMediaList() {
  const [catalog, setCatalog] = useState<Media[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("All")
  const [filterOpen, setFilterOpen] = useState(false)
  const [filterSearch, setFilterSearch] = useState("")
  const [page, setPage] = useState(1)
  const filterRef = useRef<HTMLDivElement>(null)
  const listRef = useRef<HTMLDivElement>(null)
  const { toast } = useToast()
  const { confirm } = useConfirm()

  useEffect(() => { setPage(1) }, [searchTerm, filterType])

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (filterRef.current && !filterRef.current.contains(e.target as Node)) {
        setFilterOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const getFilterLabel = (value: string) => {
    if (value === "All") return "Todos"
    for (const group of filterGroups) {
      const item = group.items.find(i => i.value === value)
      if (item) return item.label
    }
    return value
  }

  const filteredFilterOptions = useMemo(() =>
    filterGroups.map(group => ({
      ...group,
      items: group.items.filter(i =>
        i.label.toLowerCase().includes(filterSearch.toLowerCase())
      ),
    })).filter(group => group.items.length > 0),
    [filterSearch]
  )

  const fetchCatalog = async () => {
    try {
      const res = await fetch("/api/media")
      const data = await res.json()
      setCatalog(data)
    } catch (err) {
      console.error("Error fetching catalog:", err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchCatalog()
  }, [])

  const handleDelete = useCallback(async (id: string) => {
    const ok = await confirm({
      message: "¿Estás seguro de que deseas eliminar este contenido? Esta acción no se puede deshacer.",
      confirmLabel: "Eliminar",
      danger: true,
    })
    if (!ok) return

    try {
      const res = await fetch(`/api/media/${id}`, { method: "DELETE" })
      if (res.ok) {
        setCatalog(prev => prev.filter(item => item.id !== id))
      } else {
        toast("Error al eliminar", "error")
      }
    } catch (err) {
      toast("Error de conexión", "error")
    }
  }, [confirm, toast])

  const toggleFeatured = useCallback(async (id: string, currentStatus: boolean) => {
    try {
      const res = await fetch(`/api/media/${id}`, {
        method: "PATCH",
        body: JSON.stringify({ isFeatured: !currentStatus }),
        headers: { "Content-Type": "application/json" }
      })
      if (res.ok) {
        setCatalog(prev => prev.map(item => item.id === id ? { ...item, isFeatured: !currentStatus } : item))
      }
    } catch (err) {
      console.error("Error updating featured status:", err)
    }
  }, [])

  const filteredCatalog = useMemo(() => {
    const search = searchTerm.toLowerCase()
    return catalog.filter(item => {
      const matchesSearch = !search ||
        item.title.toLowerCase().includes(search) ||
        item.genre.toLowerCase().includes(search)
      const matchesType = filterType === "All" || item.type === filterType
      return matchesSearch && matchesType
    })
  }, [catalog, searchTerm, filterType])

  const totalPages = Math.ceil(filteredCatalog.length / PAGE_SIZE)
  const pageItems = useMemo(() => {
    const start = (page - 1) * PAGE_SIZE
    return filteredCatalog.slice(start, start + PAGE_SIZE)
  }, [filteredCatalog, page])

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <Loader2 className="w-12 h-12 text-accent animate-spin" />
        <p className="text-muted font-bold tracking-widest uppercase text-xs">Cargando Catálogo...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 md:gap-6 items-end justify-between">
        <div>
          <h2 className="text-2xl font-black tracking-tighter mb-1">GESTIONAR <span className="text-accent">CATÁLOGO</span></h2>
          <p className="text-muted text-sm">
            {catalog.length} títulos
            {filteredCatalog.length !== catalog.length && ` · Mostrando ${filteredCatalog.length}`}
          </p>
        </div>

        <div className="flex gap-3 w-full md:w-auto">
          <div className="relative flex-grow md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
            <input
              type="text"
              placeholder="Buscar..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-2.5 pl-10 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50"
            />
          </div>
          <div className="relative w-full md:w-48" ref={filterRef}>
            <div
              onClick={() => setFilterOpen(!filterOpen)}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-2.5 px-3 flex items-center gap-2 cursor-pointer hover:bg-white/10 transition-all text-sm"
            >
              {filterType === "All" ? (
                <Filter className="w-4 h-4 text-accent flex-shrink-0" />
              ) : filterType.startsWith("Game_") ? (
                <Gamepad2 className="w-4 h-4 text-accent flex-shrink-0" />
              ) : (
                <Monitor className="w-4 h-4 text-accent flex-shrink-0" />
              )}
              <span className="flex-grow truncate">{getFilterLabel(filterType)}</span>
              <ChevronDown className={`w-4 h-4 text-muted transition-transform flex-shrink-0 ${filterOpen ? 'rotate-180' : ''}`} />
            </div>
            {filterOpen && (
              <div className="absolute z-20 w-full mt-1.5 bg-[#1a1a1a] border border-white/10 rounded-xl shadow-2xl max-h-64 overflow-y-auto admin-scroll-area">
                <div className="p-2 border-b border-white/5">
                  <input
                    value={filterSearch}
                    onChange={(e) => setFilterSearch(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50"
                    placeholder="Buscar tipo..."
                    autoFocus
                  />
                </div>
                {filteredFilterOptions.map((group) => (
                  <div key={group.label}>
                    <div className="px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-muted flex items-center gap-2">
                      <group.icon className="w-3 h-3" />
                      {group.label}
                    </div>
                    {group.items.map((item) => (
                      <div
                        key={item.value}
                        className={`px-4 py-2.5 cursor-pointer text-sm flex items-center gap-2 transition-colors ${
                          filterType === item.value
                            ? 'bg-accent/10 text-accent font-bold'
                            : 'hover:bg-white/5'
                        }`}
                        onClick={() => {
                          setFilterType(item.value)
                          setFilterOpen(false)
                          setFilterSearch("")
                        }}
                      >
                        {filterType === item.value && (
                          <div className="w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
                        )}
                        <span className={filterType === item.value ? '' : 'ml-[14px]'}>{item.label}</span>
                      </div>
                    ))}
                  </div>
                ))}
                {filteredFilterOptions.every(g => g.items.length === 0) && (
                  <div className="p-4 text-muted text-sm text-center">Sin resultados</div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <span className="text-muted text-sm">
            Página {page} de {totalPages}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let pageNum: number
              if (totalPages <= 5) {
                pageNum = i + 1
              } else if (page <= 3) {
                pageNum = i + 1
              } else if (page >= totalPages - 2) {
                pageNum = totalPages - 4 + i
              } else {
                pageNum = page - 2 + i
              }
              return (
                <button
                  key={pageNum}
                  onClick={() => setPage(pageNum)}
                  className={`w-8 h-8 rounded-lg text-sm font-bold transition-all ${
                    page === pageNum
                      ? 'bg-accent text-black'
                      : 'bg-white/5 hover:bg-white/10 text-muted'
                  }`}
                >
                  {pageNum}
                </button>
              )
            })}
            <button
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      <div ref={listRef} className="space-y-5">
        {pageItems.length === 0 ? (
          <div className="glass p-20 rounded-3xl border-dashed border-white/10 flex flex-col items-center justify-center text-center">
            <Search className="w-12 h-12 text-muted mb-4" />
            <p className="text-muted">No se encontraron resultados</p>
          </div>
        ) : (
          pageItems.map((item) => (
            <AdminMediaItem
              key={item.id}
              item={item}
              onToggleFeatured={toggleFeatured}
              onDelete={handleDelete}
            />
          ))
        )}
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 pt-4">
          <button
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={page === 1}
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
            let pageNum: number
            if (totalPages <= 5) {
              pageNum = i + 1
            } else if (page <= 3) {
              pageNum = i + 1
            } else if (page >= totalPages - 2) {
              pageNum = totalPages - 4 + i
            } else {
              pageNum = page - 2 + i
            }
            return (
              <button
                key={pageNum}
                onClick={() => setPage(pageNum)}
                className={`w-8 h-8 rounded-lg text-sm font-bold transition-all ${
                  page === pageNum
                    ? 'bg-accent text-black'
                    : 'bg-white/5 hover:bg-white/10 text-muted'
                }`}
              >
                {pageNum}
              </button>
            )
          })}
          <button
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  )
}
