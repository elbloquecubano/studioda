"use client"

import { useEffect, useState } from "react"
import { Loader2, Save, Monitor, Gamepad2, DollarSign, Plus, Trash2, GripVertical } from "lucide-react"
import { MEDIA_TYPES } from "@/lib/types"

interface ContentPrice {
  id: string
  type: string
  price: number
  airingPrice: number | null
}

interface GameTier {
  id: string
  label: string
  minSize: number | null
  maxSize: number | null
  price: number
  sortOrder: number
}

const typeGroups = [
  {
    label: "Audiovisual",
    icon: Monitor,
    types: ["Movie", "Series", "Dorama", "Novela", "Novela_Brasil", "Novela_Colombia", "Novela_Turca", "Novela_Mexicana", "Novela_Cristiana", "Novela_Otros", "Reality", "Anime", "Dongchua", "Animated_Series", "Animated_Movie", "Deportes"],
  },
  {
    label: "Videojuegos",
    icon: Gamepad2,
    types: ["Game_PC", "Game_Mobile", "Game_PS1", "Game_PS2", "Game_PS3", "Game_PS4", "Game_Xbox_360", "Game_Switch", "Game_PSP", "Game_3DS", "Game_Wii"],
  },
]

export default function AdminPrices() {
  const [prices, setPrices] = useState<Record<string, { price: number; airingPrice: number | null }>>({})
  const [tiers, setTiers] = useState<GameTier[]>([])
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [pricesRes, tiersRes] = await Promise.all([
          fetch("/api/admin/prices"),
          fetch("/api/admin/game-price-tiers"),
        ])
        if (pricesRes.ok) {
          const data: ContentPrice[] = await pricesRes.json()
          const map: Record<string, { price: number; airingPrice: number | null }> = {}
          for (const item of data) map[item.type] = { price: item.price, airingPrice: item.airingPrice }
          setPrices(map)
        }
        if (tiersRes.ok) {
          const data: GameTier[] = await tiersRes.json()
          setTiers(data)
        }
      } catch (err) {
        console.error("Error fetching data:", err)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  const setPrice = (type: string, price: number) => {
    setPrices(prev => ({ ...prev, [type]: { ...prev[type], price } }))
  }

  const setAiringPrice = (type: string, airingPrice: number | null) => {
    setPrices(prev => ({ ...prev, [type]: { ...prev[type], airingPrice } }))
  }

  const updateTier = (id: string, field: keyof GameTier, value: any) => {
    setTiers(prev => prev.map(t => t.id === id ? { ...t, [field]: value } : t))
  }

  const addTier = async () => {
    const res = await fetch("/api/admin/game-price-tiers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ label: "Nuevo rango", minSize: null, maxSize: null, price: 0 }),
    })
    if (res.ok) {
      const created: GameTier = await res.json()
      setTiers(prev => [...prev, created])
    }
  }

  const removeTier = async (id: string) => {
    const res = await fetch(`/api/admin/game-price-tiers?id=${id}`, { method: "DELETE" })
    if (res.ok) setTiers(prev => prev.filter(t => t.id !== id))
  }

  const moveTier = (index: number, dir: -1 | 1) => {
    const newIndex = index + dir
    if (newIndex < 0 || newIndex >= tiers.length) return
    const arr = [...tiers]
    ;[arr[index], arr[newIndex]] = [arr[newIndex], arr[index]]
    arr.forEach((t, i) => { t.sortOrder = i + 1 })
    setTiers(arr)
  }

  const save = async () => {
    setSaving(true)
    setSaved(false)
    try {
      const pricePromises = Object.entries(prices).map(([type, { price, airingPrice }]) =>
        fetch("/api/admin/prices", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ type, price, airingPrice }),
        })
      )
      const tierPromises = tiers.map(tier =>
        fetch("/api/admin/game-price-tiers", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(tier),
        })
      )
      await Promise.all([...pricePromises, ...tierPromises])
      setSaved(true)
      setTimeout(() => setSaved(false), 3000)
    } catch (err) {
      console.error("Error saving:", err)
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <Loader2 className="w-12 h-12 text-accent animate-spin" />
        <p className="text-muted font-bold tracking-widest uppercase text-xs">Cargando Precios...</p>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black tracking-tighter mb-1">GESTIONAR <span className="text-accent">PRECIOS</span></h2>
          <p className="text-muted text-sm">Establece el precio de cada tipo de contenido</p>
        </div>
        <button
          onClick={save}
          disabled={saving}
          className="bg-accent text-black font-black py-3 px-6 rounded-xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(229,9,20,0.4)] disabled:opacity-50 flex items-center gap-2 text-sm"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          {saved ? "¡GUARDADO!" : "GUARDAR TODO"}
        </button>
      </div>

      {typeGroups.map((group) => (
        <div key={group.label} className="glass rounded-3xl p-6 border border-white/5">
          <div className="flex items-center gap-3 mb-6">
            <group.icon className="w-5 h-5 text-accent" />
            <h3 className="font-bold text-lg">{group.label}</h3>
          </div>

          {group.label === "Videojuegos" ? (
            <div className="space-y-3">
              <p className="text-muted text-xs mb-2">Precio por rango de tamaño (GB):</p>
              {tiers.map((tier, i) => (
                <div key={tier.id} className="flex items-center gap-3 bg-white/5 rounded-xl p-3 border border-white/5">
                  <div className="flex flex-col gap-0.5">
                    <button onClick={() => moveTier(i, -1)} className="text-muted hover:text-foreground disabled:opacity-30 p-0.5" disabled={i === 0}><svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" /></svg></button>
                    <button onClick={() => moveTier(i, 1)} className="text-muted hover:text-foreground disabled:opacity-30 p-0.5" disabled={i === tiers.length - 1}><svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg></button>
                  </div>
                  <input
                    value={tier.label}
                    onChange={e => updateTier(tier.id, "label", e.target.value)}
                    className="w-36 bg-black/40 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50"
                  />
                  <div className="flex items-center gap-1 text-xs text-muted whitespace-nowrap">
                    <span>Desde</span>
                    <input
                      type="number" min="0"
                      value={tier.minSize ?? ""}
                      onChange={e => updateTier(tier.id, "minSize", e.target.value ? parseInt(e.target.value) : null)}
                      className="w-16 bg-black/40 border border-white/10 rounded-lg py-2 px-2 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      placeholder="—"
                    />
                    <span>GB</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted whitespace-nowrap">
                    <span>Hasta</span>
                    <input
                      type="number" min="0"
                      value={tier.maxSize ?? ""}
                      onChange={e => updateTier(tier.id, "maxSize", e.target.value ? parseInt(e.target.value) : null)}
                      className="w-16 bg-black/40 border border-white/10 rounded-lg py-2 px-2 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      placeholder="—"
                    />
                    <span>GB</span>
                  </div>
                  <div className="relative flex-shrink-0">
                    <DollarSign className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted" />
                    <input
                      type="number" step="0.01" min="0"
                      value={tier.price}
                      onChange={e => updateTier(tier.id, "price", parseFloat(e.target.value) || 0)}
                      className="w-24 bg-black/40 border border-white/10 rounded-lg py-2 pl-8 pr-3 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                    />
                  </div>
                  <button onClick={() => removeTier(tier.id)} className="p-2 text-red-500/50 hover:text-red-500 transition-colors flex-shrink-0">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
              <button onClick={addTier} className="flex items-center gap-2 text-accent text-sm font-bold hover:underline mt-2">
                <Plus className="w-4 h-4" /> Añadir rango
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {group.types.map((type) => (
                <div
                  key={type}
                  className="bg-white/5 rounded-xl p-4 border border-white/5 hover:border-white/10 transition-all"
                >
                  <label className="text-xs font-bold uppercase tracking-widest text-muted block mb-2">
                    {MEDIA_TYPES[type as keyof typeof MEDIA_TYPES]?.label || type}
                  </label>
                  <div className="relative mb-2">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={prices[type]?.price ?? ""}
                      onChange={(e) => setPrice(type, parseFloat(e.target.value) || 0)}
                      className="w-full bg-black/40 border border-white/10 rounded-lg py-2.5 pl-10 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      placeholder="Precio normal"
                    />
                  </div>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-accent/60" />
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={prices[type]?.airingPrice ?? ""}
                      onChange={(e) => setAiringPrice(type, e.target.value ? parseFloat(e.target.value) : null)}
                      className="w-full bg-black/40 border border-accent/20 rounded-lg py-2.5 pl-10 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      placeholder="Precio en transmisión"
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  )
}
