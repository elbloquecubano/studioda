"use client"

import { useEffect, useState } from "react"
import { ChevronDown, ChevronRight, FolderOpen, Loader2, Plus, Trash2, Tags, Search } from "lucide-react"
import { useToast } from "@/components/ui/Toast"
import { useConfirm } from "@/components/ui/ConfirmDialog"

interface ContentType {
  key: string
  label: string
  plural: string
  genres: string[]
  count: number
}

export default function AdminContentTypes() {
  const [types, setTypes] = useState<ContentType[]>([])
  const [loading, setLoading] = useState(true)
  const [expanded, setExpanded] = useState<Record<string, boolean>>({})
  const [newGenre, setNewGenre] = useState<Record<string, string>>({})
  const [adding, setAdding] = useState<string | null>(null)
  const [search, setSearch] = useState("")
  const { toast } = useToast()
  const { confirm } = useConfirm()

  useEffect(() => {
    fetchTypes()
  }, [])

  const fetchTypes = async () => {
    try {
      const res = await fetch("/api/admin/content-types")
      const data = await res.json()
      if (Array.isArray(data)) setTypes(data)
    } catch {
      toast("Error al cargar tipos de contenido", "error")
    } finally {
      setLoading(false)
    }
  }

  const toggleExpand = (key: string) => {
    setExpanded(prev => ({ ...prev, [key]: !prev[key] }))
  }

  const expandAll = () => {
    const all: Record<string, boolean> = {}
    for (const t of filteredTypes) all[t.key] = true
    setExpanded(all)
  }

  const collapseAll = () => setExpanded({})

  const handleAddGenre = async (typeKey: string) => {
    const name = newGenre[typeKey]?.trim()
    if (!name) return

    setAdding(typeKey)
    try {
      const res = await fetch("/api/admin/content-types", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: typeKey, name }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast(data.error || "Error al agregar género", "error")
        return
      }
      setTypes(prev => prev.map(t =>
        t.key === typeKey
          ? { ...t, genres: [...t.genres, name].sort((a, b) => a.localeCompare(b)) }
          : t
      ))
      setNewGenre(prev => ({ ...prev, [typeKey]: "" }))
      toast(`Género "${name}" agregado`, "success")
    } catch {
      toast("Error de conexión", "error")
    } finally {
      setAdding(null)
    }
  }

  const handleDeleteGenre = async (typeKey: string, genreName: string) => {
    const ok = await confirm({
      message: `¿Eliminar el género "${genreName}" de ${typeKey}?`,
      confirmLabel: "Eliminar",
      danger: true,
    })
    if (!ok) return

    try {
      const res = await fetch("/api/admin/content-types", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ genreName, type: typeKey }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast(data.error || "Error al eliminar", "error")
        return
      }
      setTypes(prev => prev.map(t =>
        t.key === typeKey
          ? { ...t, genres: t.genres.filter(g => g !== genreName) }
          : t
      ))
      toast(`Género "${genreName}" eliminado`, "success")
    } catch {
      toast("Error de conexión", "error")
    }
  }

  const filteredTypes = types.filter(t => {
    const q = search.toLowerCase()
    if (!q) return true
    return (
      t.label.toLowerCase().includes(q) ||
      t.plural.toLowerCase().includes(q) ||
      t.genres.some(g => g.toLowerCase().includes(q))
    )
  })

  return (
    <div className="glass rounded-2xl border border-white/10 p-6 space-y-6">
      <div className="flex items-center gap-3">
        <FolderOpen className="w-6 h-6 text-accent" />
        <h2 className="font-bold text-lg">Tipos de Contenido y Géneros</h2>
      </div>
      <p className="text-muted text-sm">
        Gestiona los tipos de contenido y los géneros asociados a cada uno.
      </p>

      {loading ? (
        <div className="flex items-center gap-2 text-muted text-sm py-8 justify-center">
          <Loader2 className="w-4 h-4 animate-spin" /> Cargando...
        </div>
      ) : (
        <>
          <div className="flex gap-3 items-center">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
              <input
                type="text"
                placeholder="Buscar tipo o género..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 pl-10 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50"
              />
            </div>
            <button onClick={expandAll} className="text-xs text-muted hover:text-accent transition-all px-3 py-2">
              Expandir todo
            </button>
            <button onClick={collapseAll} className="text-xs text-muted hover:text-accent transition-all px-3 py-2">
              Colapsar todo
            </button>
          </div>

          <div className="space-y-2 max-h-[600px] overflow-y-auto admin-scroll-area">
            {filteredTypes.map(type => {
              const isOpen = expanded[type.key]
              return (
                <div key={type.key} className="bg-white/5 rounded-xl border border-white/5 overflow-hidden">
                  <button
                    onClick={() => toggleExpand(type.key)}
                    className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-all text-left"
                  >
                    {isOpen
                      ? <ChevronDown className="w-4 h-4 text-accent shrink-0" />
                      : <ChevronRight className="w-4 h-4 text-muted shrink-0" />
                    }
                    <Tags className="w-4 h-4 text-accent shrink-0" />
                    <span className="font-bold text-sm flex-grow">{type.label}</span>
                    <span className="text-xs text-muted bg-white/5 px-2 py-0.5 rounded-full">
                      {type.genres.length} géneros
                    </span>
                    <span className="text-xs text-muted bg-white/5 px-2 py-0.5 rounded-full">
                      {type.count} items
                    </span>
                  </button>

                  {isOpen && (
                    <div className="px-4 pb-4 border-t border-white/5 pt-3">
                      <div className="flex gap-2 mb-3">
                        <input
                          value={newGenre[type.key] || ""}
                          onChange={e => setNewGenre(prev => ({ ...prev, [type.key]: e.target.value }))}
                          onKeyDown={e => e.key === "Enter" && handleAddGenre(type.key)}
                          placeholder={`Nuevo género para ${type.label}...`}
                          className="flex-grow bg-black/40 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50"
                        />
                        <button
                          onClick={() => handleAddGenre(type.key)}
                          disabled={adding === type.key || !newGenre[type.key]?.trim()}
                          className="bg-accent text-black font-bold py-2 px-3 rounded-lg text-sm hover:scale-[1.02] transition-all disabled:opacity-50 flex items-center gap-1"
                        >
                          {adding === type.key
                            ? <Loader2 className="w-3 h-3 animate-spin" />
                            : <Plus className="w-3 h-3" />
                          }
                          Agregar
                        </button>
                      </div>

                      {type.genres.length === 0 ? (
                        <p className="text-xs text-muted py-4 text-center">
                          Sin géneros. Agrega uno arriba.
                        </p>
                      ) : (
                        <div className="flex flex-wrap gap-1.5">
                          {type.genres.map(genre => (
                            <span
                              key={genre}
                              className="group flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-lg px-2.5 py-1 text-xs"
                            >
                              <span>{genre}</span>
                              <button
                                onClick={() => handleDeleteGenre(type.key, genre)}
                                className="text-red-500/0 group-hover:text-red-500/70 hover:!text-red-500 transition-all p-0.5"
                                title={`Eliminar ${genre}`}
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </>
      )}
    </div>
  )
}
