"use client"

import useSWR from "swr"
import { Loader2, Film, Tv, Gamepad2, Tags, Radio, Heart, BarChart3, TrendingUp } from "lucide-react"

const fetcher = (url: string) => fetch(url).then(r => r.json())

interface Stats {
  totalMedia: number
  totalGenres: number
  byType: { type: string; count: number }[]
  topGenres: { name: string; count: number }[]
  yearDistribution: { year: number; count: number }[]
  airingCount: number
  featuredCount: number
  recentAdded: { title: string; type: string; createdAt: string }[]
}

const TYPE_COLORS: Record<string, string> = {
  Movie: "bg-red-500",
  Series: "bg-blue-500",
  Anime: "bg-pink-500",
  Dorama: "bg-purple-500",
  Novela: "bg-orange-500",
  Novela_Brasil: "bg-orange-400",
  Novela_Colombia: "bg-yellow-500",
  Novela_Turca: "bg-red-400",
  Novela_Mexicana: "bg-green-500",
  Reality: "bg-cyan-500",
  Dongchua: "bg-teal-500",
  Animated_Series: "bg-indigo-500",
  Animated_Movie: "bg-violet-500",
  Game_PC: "bg-emerald-500",
  Game_Mobile: "bg-lime-500",
  Deportes: "bg-amber-500",
}

const TYPE_ICONS: Record<string, string> = {
  Movie: "🎬",
  Series: "📺",
  Anime: "🌸",
  Dorama: "🎭",
  Novela: "📖",
  Reality: "🌟",
  Dongchua: "🐉",
  Animated_Series: "✨",
  Animated_Movie: "🎨",
  Game_PC: "🎮",
  Game_Mobile: "📱",
  Deportes: "⚽",
}

function formatType(t: string) {
  return t.replace(/_/g, " ").replace("Game_", "")
}

export default function AdminDashboard() {
  const { data: stats, isLoading } = useSWR<Stats>("/api/admin/stats", fetcher, {
    refreshInterval: 30000,
  })

  if (isLoading || !stats) {
    return (
      <div className="flex items-center justify-center py-32">
        <Loader2 className="w-8 h-8 text-accent animate-spin" />
      </div>
    )
  }

  const maxTypeCount = Math.max(...stats.byType.map(t => t.count), 1)
  const maxGenreCount = Math.max(...stats.topGenres.map(g => g.count), 1)
  const maxYearCount = Math.max(...stats.yearDistribution.map(y => y.count), 1)

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-black tracking-tight">
        Dashboard <span className="text-accent">Métricas</span>
      </h1>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-accent/20 rounded-xl flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-accent" />
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-muted">Total</span>
          </div>
          <p className="text-3xl font-black">{stats.totalMedia}</p>
          <p className="text-xs text-muted mt-1">Contenidos</p>
        </div>

        <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
              <Tags className="w-5 h-5 text-blue-400" />
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-muted">Géneros</span>
          </div>
          <p className="text-3xl font-black">{stats.totalGenres}</p>
          <p className="text-xs text-muted mt-1">Únicos</p>
        </div>

        <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center">
              <Radio className="w-5 h-5 text-green-400" />
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-muted">En Vivo</span>
          </div>
          <p className="text-3xl font-black">{stats.airingCount}</p>
          <p className="text-xs text-muted mt-1">Transmitiendo</p>
        </div>

        <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-yellow-500/20 rounded-xl flex items-center justify-center">
              <Radio className="w-5 h-5 text-yellow-400" />
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-muted">Destacados</span>
          </div>
          <p className="text-3xl font-black">{stats.featuredCount}</p>
          <p className="text-xs text-muted mt-1">Featured</p>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* By Type */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
          <h3 className="font-bold text-sm uppercase tracking-wider text-muted mb-4 flex items-center gap-2">
            <Film className="w-4 h-4" /> Contenido por Tipo
          </h3>
          <div className="space-y-3">
            {stats.byType.map(item => (
              <div key={item.type} className="flex items-center gap-3">
                <span className="text-lg w-7 text-center">{TYPE_ICONS[item.type] || "📁"}</span>
                <span className="text-xs font-bold w-24 truncate">{formatType(item.type)}</span>
                <div className="flex-1 h-6 bg-white/5 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${TYPE_COLORS[item.type] || "bg-gray-500"} transition-all duration-500`}
                    style={{ width: `${(item.count / maxTypeCount) * 100}%` }}
                  />
                </div>
                <span className="text-xs font-black w-8 text-right">{item.count}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Top Genres */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
          <h3 className="font-bold text-sm uppercase tracking-wider text-muted mb-4 flex items-center gap-2">
            <Tags className="w-4 h-4" /> Top Géneros
          </h3>
          <div className="space-y-3">
            {stats.topGenres.slice(0, 12).map((item, i) => (
              <div key={item.name} className="flex items-center gap-3">
                <span className="text-xs font-black text-muted w-5 text-right">{i + 1}</span>
                <span className="text-xs font-bold w-28 truncate">{item.name}</span>
                <div className="flex-1 h-5 bg-white/5 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full bg-accent/70 transition-all duration-500"
                    style={{ width: `${(item.count / maxGenreCount) * 100}%` }}
                  />
                </div>
                <span className="text-xs font-black w-8 text-right">{item.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Year Distribution */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
        <h3 className="font-bold text-sm uppercase tracking-wider text-muted mb-4 flex items-center gap-2">
          <TrendingUp className="w-4 h-4" /> Distribución por Año
        </h3>
        <div className="flex items-end gap-2 h-40">
          {stats.yearDistribution.sort((a, b) => a.year - b.year).map(item => (
            <div key={item.year} className="flex-1 flex flex-col items-center gap-1">
              <span className="text-xs font-black">{item.count}</span>
              <div
                className="w-full bg-accent/60 rounded-t-lg transition-all duration-500 min-h-[4px]"
                style={{ height: `${(item.count / maxYearCount) * 100}%` }}
              />
              <span className="text-[10px] font-bold text-muted">{item.year}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Added */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
          <h3 className="font-bold text-sm uppercase tracking-wider text-muted mb-4 flex items-center gap-2">
            <Heart className="w-4 h-4" /> Agregados Recientemente
          </h3>
          <div className="space-y-2">
            {stats.recentAdded.map((item, i) => (
              <div key={i} className="flex items-center gap-3 py-2 border-b border-white/5 last:border-0">
                <span className="text-lg">{TYPE_ICONS[item.type] || "📁"}</span>
                <span className="text-sm font-bold flex-1 truncate">{item.title}</span>
                <span className="text-xs px-2 py-0.5 bg-white/10 rounded-full">{formatType(item.type)}</span>
                <span className="text-xs text-muted">
                  {new Date(item.createdAt).toLocaleDateString("es-ES")}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
