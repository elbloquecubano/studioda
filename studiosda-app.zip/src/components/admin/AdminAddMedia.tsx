"use client"

import { useState, useRef, useEffect, useMemo } from "react"
import { Upload, X, Film, Tv, Save, Loader2, ArrowLeft, Tags, ChevronDown, Monitor, Gamepad2, HardDrive } from "lucide-react"
import { uploadImage } from "@/lib/upload"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/Toast"

interface Genre {
  id: string
  name: string
  slug: string
}

const TYPE_GROUPS = [
  {
    label: "Audiovisual",
    icon: Monitor,
    items: [
      { value: "Movie", label: "Película" },
      { value: "Series", label: "Serie" },
      { value: "Dorama", label: "Dorama" },
      { value: "Novela", label: "Novela (General)" },
      { value: "Novela_Brasil", label: "Novela Brasileña" },
      { value: "Novela_Colombia", label: "Novela Colombiana" },
      { value: "Novela_Turca", label: "Novela Turca" },
      { value: "Novela_Mexicana", label: "Novela Mexicana" },
      { value: "Novela_Cristiana", label: "Novela Cristiana" },
      { value: "Novela_Otros", label: "Otra Novela" },
      { value: "Reality", label: "Reality" },
      { value: "Anime", label: "Anime" },
      { value: "Dongchua", label: "Dongchua" },
      { value: "Animated_Series", label: "Animados (Serie)" },
      { value: "Animated_Movie", label: "Animados (Filme)" },
      { value: "Deportes", label: "Deportes" },
    ],
  },
  {
    label: "Videojuegos",
    icon: Gamepad2,
    items: [
      { value: "Game_PC", label: "Juegos para PC" },
      { value: "Game_Mobile", label: "Juegos para Móvil" },
      { value: "Game_PS1", label: "PlayStation 1" },
      { value: "Game_PS2", label: "PlayStation 2" },
      { value: "Game_PS3", label: "PlayStation 3" },
      { value: "Game_PS4", label: "PlayStation 4" },
      { value: "Game_Xbox 360 360", label: "Xbox 360 360 360" },
      { value: "Game_Switch", label: "Nintendo Switch" },
      { value: "Game_PSP", label: "PSP" },
      { value: "Game_3DS", label: "Nintendo 3DS" },
      { value: "Game_Wii", label: "Wii" },
    ],
  },
] as const

interface AdminAddMediaProps {
  initialData?: any;
}

export default function AdminAddMedia({ initialData }: AdminAddMediaProps) {
  const [loading, setLoading] = useState(false)
  const [isScraping, setIsScraping] = useState(false)
  const [scrapeUrl, setScrapeUrl] = useState("")
  const [posterPreview, setPosterPreview] = useState<string | null>(initialData?.posterPath || null)
  const [backdropPreview, setBackdropPreview] = useState<string | null>(initialData?.backdropPath || null)
  const router = useRouter();
  const { toast } = useToast();

  const posterRef = useRef<HTMLInputElement>(null)
  const backdropRef = useRef<HTMLInputElement>(null)
  const formRef = useRef<HTMLFormElement>(null)

  const [formData, setFormData] = useState({
    title: initialData?.title || "",
    type: initialData?.type || "Movie",
    year: initialData?.year || new Date().getFullYear(),
    genre: initialData?.genre || "",
    synopsis: initialData?.synopsis || "",
    fileSize: initialData?.fileSize || "",
    isAiring: initialData?.isAiring ?? false,
  })

  // Genre multi-select state
  const [allGenres, setAllGenres] = useState<Genre[]>([])
  const [selectedGenres, setSelectedGenres] = useState<string[]>(() =>
    initialData?.genre
      ? initialData.genre.split(",").map((g: string) => g.trim()).filter(Boolean)
      : []
  )
  const [genreSearch, setGenreSearch] = useState("")
  const [genreDropdownOpen, setGenreDropdownOpen] = useState(false)
  const genreDropdownRef = useRef<HTMLDivElement>(null)

  // Auto-detect type from URL when user pastes a link
  useEffect(() => {
    if (!scrapeUrl) return;
    const u = scrapeUrl.toLowerCase();
    let detected: string | null = null;

    if (u.includes('/movie/') || u.includes('themoviedb.org/movie')) {
      detected = "Movie";
    } else if (u.includes('/tv/') || u.includes('themoviedb.org/tv') || u.includes('/series/') || u.includes('/serie/') || u.includes('/show/')) {
      detected = "Series";
    } else if (u.includes('/anime') || u.includes('myanimelist') || u.includes('animeflv') || u.includes('crunchyroll')) {
      detected = "Anime";
    } else if (u.includes('/novela') || u.includes('novelas') || u.includes('telemundo')) {
      detected = "Novela";
    } else if (u.includes('steampowered') || u.includes('store.epicgames') || u.includes('gog.com') || u.includes('/game/') || u.includes('/juego/')) {
      detected = "Game_PC";
    } else if (u.includes('/donghua') || u.includes('/dongchua')) {
      detected = "Dongchua";
    } else if (u.includes('/reality') || u.includes('/realityshow')) {
      detected = "Reality";
    } else if (u.includes('/deport') || u.includes('/sport')) {
      detected = "Deportes";
    } else if (u.includes('/dorama') || u.includes('/kdrama')) {
      detected = "Dorama";
    } else if (u.includes('/animated') || u.includes('/animacion') || u.includes('/animado')) {
      detected = "Animated_Movie";
    }

    if (detected) {
      setFormData(prev => ({ ...prev, type: detected! }));
    }
  }, [scrapeUrl]);

  // Fetch all genres
  useEffect(() => {
    fetch("/api/genres")
      .then(res => res.json())
      .then(data => setAllGenres(Array.isArray(data) ? data : []))
      .catch(() => {})
  }, [])

  useEffect(() => {
    if (initialData) {
      setFormData({
        title: initialData.title,
        type: initialData.type,
        year: initialData.year,
        genre: initialData.genre,
        synopsis: initialData.synopsis,
        fileSize: initialData.fileSize || "",
        isAiring: initialData.isAiring ?? false,
      });
      setPosterPreview(initialData.posterPath);
      setBackdropPreview(initialData.backdropPath);
      const parsed = initialData.genre
        ? initialData.genre.split(",").map((g: string) => g.trim()).filter(Boolean)
        : [];
      setSelectedGenres(parsed);
    }
  }, [initialData])

  // Type combobox state
  const [typeSearch, setTypeSearch] = useState("")
  const [typeDropdownOpen, setTypeDropdownOpen] = useState(false)
  const typeDropdownRef = useRef<HTMLDivElement>(null)

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (genreDropdownRef.current && !genreDropdownRef.current.contains(e.target as Node)) {
        setGenreDropdownOpen(false)
      }
      if (typeDropdownRef.current && !typeDropdownRef.current.contains(e.target as Node)) {
        setTypeDropdownOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const filteredGenres = allGenres.filter(g =>
    g.name.toLowerCase().includes(genreSearch.toLowerCase()) &&
    !selectedGenres.includes(g.name)
  )

  const getTypeLabel = (value: string) => {
    for (const group of TYPE_GROUPS) {
      const item = group.items.find(i => i.value === value)
      if (item) return item.label
    }
    return value
  }

  const filteredTypes = useMemo(() => {
    const q = typeSearch.toLowerCase()
    if (!q) return TYPE_GROUPS
    return TYPE_GROUPS.map(group => ({
      ...group,
      items: group.items.filter(i =>
        i.label.toLowerCase().includes(q) || i.value.toLowerCase().includes(q)
      ),
    })).filter(group => group.items.length > 0)
  }, [typeSearch])

  const toggleGenre = (name: string) => {
    setSelectedGenres(prev =>
      prev.includes(name) ? prev.filter(g => g !== name) : [...prev, name]
    )
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'poster' | 'backdrop') => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        if (type === 'poster') setPosterPreview(reader.result as string)
        else setBackdropPreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleScrape = async (autoSave = false) => {
    if (!scrapeUrl) return;
    setIsScraping(true);
    try {
      const res = await fetch("/api/scrape", {
        method: "POST",
        body: JSON.stringify({ url: scrapeUrl }),
        headers: { "Content-Type": "application/json" }
      });
      if (res.ok) {
        const data = await res.json();
        setFormData(prev => ({
          ...prev,
          title: data.title || prev.title,
          year: data.year || prev.year,
          synopsis: data.synopsis || prev.synopsis,
          type: data.type || prev.type,
        }));
        if (data.posterPath) {
          setPosterPreview(data.posterPath);
        }
        if (data.backdropPath) {
          setBackdropPreview(data.backdropPath);
        } else if (data.posterPath) {
          setBackdropPreview(null);
        }
        if (data.genre) {
          const existingNames = new Set(allGenres.map(g => g.name));
          const matched = data.genre.split(",").map((g: string) => g.trim()).filter((g: string) => g && existingNames.has(g));
          if (matched.length > 0) {
            setSelectedGenres(matched);
          }
        }
        setScrapeUrl("");
        if (autoSave) {
          setTimeout(() => formRef.current?.requestSubmit(), 100);
        }
      } else {
        const err = await res.json();
        toast(`Error: ${err.error}`, "error");
        if (err.type) {
          setFormData(prev => ({ ...prev, type: err.type }));
        }
      }
    } catch (err) {
      console.error(err);
      toast("Error al intentar hacer scraping de la URL", "error");
    } finally {
      setIsScraping(false);
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // 1. Subir imágenes si cambiaron
      let posterPath = initialData?.posterPath || ""
      let backdropPath = initialData?.backdropPath || ""

      if (posterPreview && !posterPreview.startsWith('data:')) posterPath = posterPreview;
      if (backdropPreview && !backdropPreview.startsWith('data:')) backdropPath = backdropPreview;

      if (posterRef.current?.files?.[0]) {
        posterPath = await uploadImage(posterRef.current.files[0])
      }
      if (backdropRef.current?.files?.[0]) {
        backdropPath = await uploadImage(backdropRef.current.files[0])
      }

      // 2. Guardar en BD via API
      const url = initialData ? `/api/media/${initialData.id}` : "/api/media"
      const method = initialData ? "PATCH" : "POST"

      const genre = selectedGenres.join(", ");

      const res = await fetch(url, {
        method,
        body: JSON.stringify({ ...formData, genre, posterPath, backdropPath, fileSize: formData.fileSize || null, isAiring: formData.isAiring }),
        headers: { "Content-Type": "application/json" }
      })

      if (res.ok) {
        toast(initialData ? "¡Contenido actualizado!" : "¡Contenido agregado con éxito!", "success");
        if (initialData) {
          router.push("/admin/list");
        } else {
          // Reset form
          setFormData({
            title: "",
            type: "Movie",
            year: new Date().getFullYear(),
            genre: "",
            synopsis: "",
            fileSize: "",
            isAiring: false,
          });
          setSelectedGenres([]);
          setPosterPreview(null);
          setBackdropPreview(null);
        }
      } else {
        const error = await res.json()
        toast(`Error: ${error.error}`, "error")
      }
    } catch (err) {
      toast("Error al guardar el contenido", "error")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="glass p-8 rounded-3xl border border-white/10 max-w-5xl mx-auto">
      {initialData && (
        <Link href="/admin/list" className="flex items-center gap-2 text-muted hover:text-accent mb-6 transition-colors font-bold text-sm">
          <ArrowLeft className="w-4 h-4" /> Volver al listado
        </Link>
      )}

      <div className="flex items-center gap-4 mb-8">
        <div className="w-12 h-12 bg-accent rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(229,9,20,0.3)]">
          <Save className="text-black w-6 h-6" />
        </div>
        <div>
          <h2 className="text-2xl font-black tracking-tighter uppercase">
            {initialData ? "EDITAR" : "NUEVO"} <span className="text-accent">CONTENIDO</span>
          </h2>
          <p className="text-muted text-sm">
            {initialData ? `Modificando: ${initialData.title}` : "Completa los campos para añadir al catálogo local"}
          </p>
        </div>
      </div>

      {/* Auto Import Section */}
      {!initialData && (
        <div className="mb-8 p-6 bg-white/5 border border-accent/20 rounded-2xl flex flex-col md:flex-row gap-4 items-end">
          <div className="flex-grow space-y-2 w-full">
            <label className="text-xs font-bold uppercase tracking-widest text-accent flex items-center gap-2">
              <Film className="w-4 h-4" /> Importar desde URL
            </label>
            <input
              type="url"
              value={scrapeUrl}
              onChange={(e) => setScrapeUrl(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); handleScrape(true); } }}
              className="w-full bg-black/50 border border-white/10 rounded-xl py-3 px-4 focus:outline-none focus:ring-1 focus:ring-accent/50 transition-all"
              placeholder="https://www.imdb.com/title/..."
            />
          </div>
          <button
            type="button"
            onClick={() => handleScrape()}
            disabled={isScraping || !scrapeUrl}
            className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-bold transition-all disabled:opacity-50 flex items-center gap-2 whitespace-nowrap"
          >
            {isScraping ? <Loader2 className="w-5 h-5 animate-spin" /> : <Upload className="w-5 h-5" />}
            {isScraping ? "Extrayendo..." : "Autocompletar"}
          </button>
        </div>
      )}

      <form ref={formRef} onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left Column: Data */}
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-widest text-muted">Título</label>
            <input
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:outline-none focus:ring-1 focus:ring-accent/50 transition-all"
              placeholder="Ej: Interstellar"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-muted">Tipo</label>
              <div className="relative" ref={typeDropdownRef}>
                {/* Type selector button / display */}
                <div
                  onClick={() => setTypeDropdownOpen(!typeDropdownOpen)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 flex items-center gap-2 cursor-pointer hover:bg-white/10 transition-all"
                >
                  {formData.type.startsWith("Game_") ? (
                    <Gamepad2 className="w-4 h-4 text-accent flex-shrink-0" />
                  ) : (
                    <Monitor className="w-4 h-4 text-accent flex-shrink-0" />
                  )}
                  <span className="flex-grow text-sm">{getTypeLabel(formData.type)}</span>
                  <ChevronDown className={`w-4 h-4 text-muted transition-transform ${typeDropdownOpen ? 'rotate-180' : ''}`} />
                </div>
                {/* Dropdown */}
                {typeDropdownOpen && (
                  <div className="absolute z-20 w-full mt-1.5 bg-[#1a1a1a] border border-white/10 rounded-xl shadow-2xl max-h-64 overflow-y-auto admin-scroll-area">
                    {/* Search */}
                    <div className="p-2 border-b border-white/5">
                      <input
                        value={typeSearch}
                        onChange={(e) => setTypeSearch(e.target.value)}
                        className="w-full bg-black/40 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50"
                        placeholder="Buscar tipo..."
                        autoFocus
                      />
                    </div>
                    {/* Options */}
                    {filteredTypes.map((group) => (
                      <div key={group.label}>
                        <div className="px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-muted flex items-center gap-2">
                          <group.icon className="w-3 h-3" />
                          {group.label}
                        </div>
                        {group.items.map((item) => (
                          <div
                            key={item.value}
                            className={`px-4 py-2.5 cursor-pointer text-sm flex items-center gap-2 transition-colors ${
                              formData.type === item.value
                                ? 'bg-accent/10 text-accent font-bold'
                                : 'hover:bg-white/5'
                            }`}
                            onClick={() => {
                              setFormData({ ...formData, type: item.value })
                              setTypeDropdownOpen(false)
                              setTypeSearch("")
                            }}
                          >
                            {formData.type === item.value && (
                              <div className="w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
                            )}
                            <span className={formData.type === item.value ? '' : 'ml-[14px]'}>{item.label}</span>
                          </div>
                        ))}
                      </div>
                    ))}
                    {filteredTypes.every(g => g.items.length === 0) && (
                      <div className="p-4 text-muted text-sm text-center">Sin resultados</div>
                    )}
                  </div>
                )}
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-muted">Año</label>
              <input
                type="number"
                required
                value={formData.year}
                onChange={(e) => setFormData({ ...formData, year: parseInt(e.target.value) })}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:outline-none focus:ring-1 focus:ring-accent/50"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-muted">Género</label>
              <div className="relative" ref={genreDropdownRef}>
                {/* Selected genre tags */}
                <div className="flex flex-wrap gap-1.5 mb-2 min-h-[28px]">
                  {selectedGenres.map(genre => (
                    <span key={genre} className="inline-flex items-center gap-1 px-2.5 py-1 bg-accent/20 text-accent rounded-full text-xs font-bold">
                      {genre}
                      <X className="w-3 h-3 cursor-pointer hover:text-white" onClick={() => toggleGenre(genre)} />
                    </span>
                  ))}
                </div>
                {/* Search input */}
                <div className="relative">
                  <Tags className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
                  <input
                    value={genreSearch}
                    onChange={(e) => { setGenreSearch(e.target.value); setGenreDropdownOpen(true) }}
                    onFocus={() => setGenreDropdownOpen(true)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-10 pr-4 focus:outline-none focus:ring-1 focus:ring-accent/50"
                    placeholder="Buscar y seleccionar géneros..."
                  />
                </div>
                {/* Dropdown */}
                {genreDropdownOpen && (
                  <div className="absolute z-20 w-full mt-1.5 bg-[#1a1a1a] border border-white/10 rounded-xl shadow-2xl max-h-48 overflow-y-auto admin-scroll-area">
                    {filteredGenres.length === 0 ? (
                      <div className="p-4 text-muted text-sm text-center">Sin resultados</div>
                    ) : (
                      filteredGenres.map(genre => (
                        <div
                          key={genre.id}
                          className="px-4 py-2.5 hover:bg-white/5 cursor-pointer text-sm flex items-center gap-2 transition-colors"
                          onClick={() => { toggleGenre(genre.name); setGenreSearch("") }}
                        >
                          <Tags className="w-3.5 h-3.5 text-accent/70" />
                          {genre.name}
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* File Size - Only for games */}
          {formData.type.startsWith("Game_") && (
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-muted flex items-center gap-2">
                <HardDrive className="w-3.5 h-3.5" /> Tamaño del Juego (GB)
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                value={formData.fileSize}
                onChange={(e) => setFormData({ ...formData, fileSize: e.target.value })}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:outline-none focus:ring-1 focus:ring-accent/50"
                placeholder="Ej: 25.5"
              />
              <p className="text-[10px] text-muted/60">Se usa para calcular el precio según las categorías de tamaño configuradas.</p>
            </div>
          )}

          {/* Airing Status - Only for audiovisual content */}
          {!formData.type.startsWith("Game_") && (
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-muted flex items-center gap-2">
                <Tv className="w-3.5 h-3.5" /> Estado de Emisión
              </label>
              <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-xl p-4">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, isAiring: !formData.isAiring })}
                  className={`relative w-12 h-6 rounded-full transition-colors ${
                    formData.isAiring ? 'bg-accent' : 'bg-white/20'
                  }`}
                >
                  <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                    formData.isAiring ? 'translate-x-6' : 'translate-x-0.5'
                  }`} />
                </button>
                <div>
                  <span className="text-sm font-bold">En Transmisión</span>
                  <p className="text-[10px] text-muted/60">Usa precio de transmisión en vez del precio normal</p>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-widest text-muted">Sinopsis</label>
            <textarea
              required
              value={formData.synopsis}
              onChange={(e) => setFormData({ ...formData, synopsis: e.target.value })}
              rows={4}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:outline-none focus:ring-1 focus:ring-accent/50 resize-none"
              placeholder="Descripción breve..."
            />
          </div>
        </div>

        {/* Right Column: Files & Review */}
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            {/* Poster Upload */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-muted">Póster (2:3)</label>
              <div
                onClick={() => posterRef.current?.click()}
                className="relative aspect-[2/3] bg-white/5 border-2 border-dashed border-white/10 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:bg-white/10 transition-all overflow-hidden group"
              >
                {posterPreview ? (
                  <Image src={posterPreview} alt="Preview" fill className="object-cover" />
                ) : (
                  <>
                    <Upload className="w-8 h-8 text-muted mb-2 group-hover:text-accent transition-colors" />
                    <span className="text-[10px] font-bold text-muted uppercase">Subir Póster</span>
                  </>
                )}
                <input type="file" ref={posterRef} hidden onChange={(e) => handleFileChange(e, 'poster')} accept="image/*" />
              </div>
            </div>

            {/* Backdrop Upload */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-muted">Backdrop (16:9)</label>
              <div
                onClick={() => backdropRef.current?.click()}
                className="relative aspect-[16/9] bg-white/5 border-2 border-dashed border-white/10 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:bg-white/10 transition-all overflow-hidden group"
              >
                {backdropPreview ? (
                  <Image src={backdropPreview} alt="Preview" fill className="object-cover" />
                ) : (
                  <>
                    <Upload className="w-8 h-8 text-muted mb-2 group-hover:text-accent transition-colors" />
                    <span className="text-[10px] font-bold text-muted uppercase">Subir Fondo</span>
                  </>
                )}
                <input type="file" ref={backdropRef} hidden onChange={(e) => handleFileChange(e, 'backdrop')} accept="image/*" />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-accent text-black font-black py-4 rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(229,9,20,0.4)] disabled:opacity-50 flex items-center justify-center gap-2 mt-4"
          >
            {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (initialData ? "ACTUALIZAR CONTENIDO" : "GUARDAR EN CATÁLOGO")}
          </button>
        </div>
      </form>
    </div>
  )
}
