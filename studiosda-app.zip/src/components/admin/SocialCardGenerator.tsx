"use client"

import { useState, useRef, useEffect } from "react"
import { createPortal } from "react-dom"
import { Image as ImageIcon, Download, Loader2, X, Copy, Move } from "lucide-react"

type LogoPosition = "top-left" | "top-center" | "top-right" | "bottom-left" | "bottom-center" | "bottom-right" | "none"

const logoPositions: { value: LogoPosition; label: string }[] = [
  { value: "top-left", label: "Superior Izq." },
  { value: "top-center", label: "Superior Centro" },
  { value: "top-right", label: "Superior Der." },
  { value: "bottom-left", label: "Inferior Izq." },
  { value: "bottom-center", label: "Inferior Centro" },
  { value: "bottom-right", label: "Inferior Der." },
  { value: "none", label: "Sin logo" },
]

interface SocialCardGeneratorProps {
  title: string
  posterPath: string | null
  backdropPath: string | null
  synopsis: string
  genre: string
  year: number
  type: string
}

export default function SocialCardGenerator({
  title,
  posterPath,
  backdropPath,
  synopsis,
  genre,
  year,
  type,
}: SocialCardGeneratorProps) {
  const [open, setOpen] = useState(false)
  const [generating, setGenerating] = useState(false)
  const [dataUrl, setDataUrl] = useState<string | null>(null)
  const [posterDataUrl, setPosterDataUrl] = useState<string | null>(null)
  const [mounted, setMounted] = useState(false)
  const [logoPosition, setLogoPosition] = useState<LogoPosition>("bottom-right")
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => { setMounted(true) }, [])

  const generate = async (pos?: LogoPosition) => {
    const currentPos = pos ?? logoPosition
    setGenerating(true)
    try {
      const canvas = document.createElement("canvas")
      canvas.width = 1200
      canvas.height = 630
      const ctx = canvas.getContext("2d")!
      const W = canvas.width
      const H = canvas.height

      // 1. Fondo oscuro base
      ctx.fillStyle = "#0a0a0a"
      ctx.fillRect(0, 0, W, H)

      // 2. Fondo: backdrop (banner) escalado para cubrir todo el canvas, fallback a poster
      const bgSource = backdropPath || posterPath
      if (bgSource) {
        try {
          const bgImg = await loadImage(bgSource)
          const scale = Math.max(W / bgImg.width, H / bgImg.height)
          const sw = bgImg.width * scale
          const sh = bgImg.height * scale
          ctx.drawImage(bgImg, (W - sw) / 2, (H - sh) / 2, sw, sh)
        } catch {
          // Ya está el fondo oscuro base
        }
      }

      // Overlay oscuro semitransparente (como movie/[id] con opacity-30)
      ctx.fillStyle = "rgba(0,0,0,0.7)"
      ctx.fillRect(0, 0, W, H)

      // Gradiente desde abajo (como movie/[id] from-background to-transparent)
      const fadeGrad = ctx.createLinearGradient(0, H, 0, 0)
      fadeGrad.addColorStop(0, "rgba(10,10,10,0.95)")
      fadeGrad.addColorStop(0.4, "rgba(10,10,10,0.6)")
      fadeGrad.addColorStop(1, "rgba(10,10,10,0.3)")
      ctx.fillStyle = fadeGrad
      ctx.fillRect(0, 0, W, H)

      // 2. Póster principal a la izquierda (con forma redondeada via clipping)
      const posterMargin = 50
      const posterW = 260
      const posterH = Math.round(posterW * 1.5) // 2:3
      const posterX = posterMargin
      const posterY = (H - posterH) / 2
      const posterRadius = 16

      // Clip redondeado para el póster
      ctx.save()
      ctx.beginPath()
      ctx.roundRect(posterX, posterY, posterW, posterH, posterRadius)
      ctx.clip()

      if (posterPath) {
        try {
          const img = await loadImage(posterPath)
          const iw = img.width
          const ih = img.height
          const s = Math.max(posterW / iw, posterH / ih)
          const dw = iw * s
          const dh = ih * s
          ctx.drawImage(img, posterX + (posterW - dw) / 2, posterY + (posterH - dh) / 2, dw, dh)
        } catch {
          ctx.fillStyle = "#1a1a1a"
          ctx.fillRect(posterX, posterY, posterW, posterH)
        }
      } else {
        ctx.fillStyle = "#1a1a1a"
        ctx.fillRect(posterX, posterY, posterW, posterH)
      }
      ctx.restore()

      // Borde sutil del póster
      ctx.strokeStyle = "rgba(255,255,255,0.1)"
      ctx.lineWidth = 1
      ctx.beginPath()
      ctx.roundRect(posterX, posterY, posterW, posterH, posterRadius)
      ctx.stroke()

      // 3. Panel de información a la derecha
      const infoX = posterX + posterW + 50
      const infoW = W - infoX - 50

      // Badges de tipo + año (arriba)
      let badgeY = posterY + 10

      // Badge de tipo
      const typeLabels: Record<string, string> = {
        Movie: "Película",
        Series: "Serie",
        Anime: "Anime",
        Dorama: "Dorama",
        Novela: "Novela",
        Reality: "Reality",
        Dongchua: "Dongchua",
        Animated_Series: "Animados (Serie)",
        Animated_Movie: "Animados (Filme)",
        Deportes: "Deportes",
        Game_PC: "Juegos para PC",
        Game_Mobile: "Juegos para Móvil",
      }
      const typeLabel = typeLabels[type] || type || "Contenido"
      ctx.font = "bold 13px system-ui, sans-serif"
      const typeW = ctx.measureText(typeLabel.toUpperCase()).width + 30
      const badgeH = 28
      const badgeRadius = 14
      ctx.fillStyle = "rgba(229,9,20,0.25)"
      ctx.beginPath()
      ctx.roundRect(infoX, badgeY, typeW, badgeH, badgeRadius)
      ctx.fill()
      ctx.strokeStyle = "rgba(229,9,20,0.4)"
      ctx.lineWidth = 1
      ctx.stroke()
      ctx.fillStyle = "#E50914"
      ctx.font = "bold 11px system-ui, sans-serif"
      ctx.textBaseline = "middle"
      ctx.fillText(typeLabel.toUpperCase(), infoX + 15, badgeY + badgeH / 2)

      // Año al lado del badge
      const yearX = infoX + typeW + 15
      ctx.fillStyle = "rgba(255,255,255,0.5)"
      ctx.font = "bold 14px system-ui, sans-serif"
      ctx.fillText(String(year), yearX, badgeY + badgeH / 2)

      badgeY += badgeH + 20

      // Título en blanco grande (como movie/[id] text-4xl font-black uppercase)
      ctx.fillStyle = "#FFFFFF"
      ctx.font = "bold 52px system-ui, sans-serif"
      ctx.textBaseline = "top"
      const titleLines = wrapText(ctx, title.toUpperCase(), infoW)
      const titleMaxLines = 2
      const titleLineH = 60
      for (let i = 0; i < Math.min(titleLines.length, titleMaxLines); i++) {
        let line = titleLines[i]
        if (i === titleMaxLines - 1 && titleLines.length > titleMaxLines) {
          while (ctx.measureText(line + "…").width > infoW) line = line.slice(0, -1)
          line += "…"
        }
        ctx.fillText(line, infoX, badgeY + i * titleLineH)
      }

      // Género debajo del título
      const genreY = badgeY + Math.min(titleLines.length, titleMaxLines) * titleLineH + 20
      ctx.fillStyle = "rgba(255,255,255,0.5)"
      ctx.font = "16px system-ui, sans-serif"
      ctx.fillText(genre, infoX, genreY)

      // Sinopsis debajo del género
      const synopsisY = genreY + 35
      ctx.fillStyle = "rgba(255,255,255,0.75)"
      ctx.font = "18px system-ui, sans-serif"
      ctx.textBaseline = "top"
      const synopsisLines = wrapText(ctx, synopsis, infoW)
      const maxLines = 5
      const lineH = 26
      for (let i = 0; i < Math.min(synopsisLines.length, maxLines); i++) {
        let line = synopsisLines[i]
        if (i === maxLines - 1 && synopsisLines.length > maxLines) {
          while (ctx.measureText(line + "…").width > infoW) line = line.slice(0, -1)
          line += "…"
        }
        ctx.fillText(line, infoX, synopsisY + i * lineH)
      }

      // 4. Logo según posición seleccionada
      if (currentPos !== "none") {
        ctx.fillStyle = "rgba(255,255,255,0.15)"
        ctx.font = "bold 12px system-ui, sans-serif"
        ctx.textBaseline = "bottom"

        let logoX = W - 40
        let logoY = H - 20
        ctx.textAlign = "right"

        switch (currentPos) {
          case "top-left":
            logoX = 40
            logoY = 30
            ctx.textAlign = "left"
            ctx.textBaseline = "top"
            break
          case "top-center":
            logoX = W / 2
            logoY = 30
            ctx.textAlign = "center"
            ctx.textBaseline = "top"
            break
          case "top-right":
            logoX = W - 40
            logoY = 30
            ctx.textAlign = "right"
            ctx.textBaseline = "top"
            break
          case "bottom-left":
            logoX = 40
            logoY = H - 20
            ctx.textAlign = "left"
            ctx.textBaseline = "bottom"
            break
          case "bottom-center":
            logoX = W / 2
            logoY = H - 20
            ctx.textAlign = "center"
            ctx.textBaseline = "bottom"
            break
          case "bottom-right":
          default:
            logoX = W - 40
            logoY = H - 20
            ctx.textAlign = "right"
            ctx.textBaseline = "bottom"
            break
        }

        ctx.fillText("STUDIOS D-A", logoX, logoY)
        ctx.textAlign = "left"
      }

      setDataUrl(canvas.toDataURL("image/png"))
    } catch (err) {
      console.error("Error generating social card:", err)
    } finally {
      setGenerating(false)
    }
  }

  const loadImage = (src: string): Promise<HTMLImageElement> => {
    return new Promise((resolve, reject) => {
      const img = new Image()
      // Solo usar crossOrigin para URLs externas
      if (src.startsWith("http")) img.crossOrigin = "anonymous"
      img.onload = () => resolve(img)
      img.onerror = reject
      img.src = src
    })
  }

  const wrapText = (ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] => {
    if (!text) return [""]
    const words = text.split(" ")
    const lines: string[] = []
    let current = ""
    for (const word of words) {
      const test = current ? current + " " + word : word
      if (ctx.measureText(test).width > maxWidth && current) {
        lines.push(current)
        current = word
      } else {
        current = test
      }
    }
    if (current) lines.push(current)
    return lines.length > 0 ? lines : [""]
  }

  const [copyOk, setCopyOk] = useState(false)
  const [copyTemplate, setCopyTemplate] = useState("")

  const loadTemplate = async () => {
    try {
      const res = await fetch("/api/admin/site-config")
      const data = await res.json()
      if (data.value) setCopyTemplate(data.value)
    } catch {
      // Usar plantilla por defecto si falla
    }
  }

  const getFormattedMessage = () => {
    // Get type label from MEDIA_TYPES
    const typeLabels: Record<string, string> = {
      Movie: "Película",
      Series: "Serie",
      Anime: "Anime",
      Dorama: "Dorama",
      Novela: "Novela",
      Reality: "Reality",
      Dongchua: "Dongchua",
      Animated_Series: "Animados (Serie)",
      Animated_Movie: "Animados (Filme)",
      Deportes: "Deportes",
      Game_PC: "Juegos para PC",
      Game_Mobile: "Juegos para Móvil",
    }
    const typeLabel = typeLabels[type] || type

    if (!copyTemplate) {
      // Plantilla por defecto si no se cargó
      const g = genre || "No especificado"
      return `⚽️《《 Studio D-A 》》⚽️
  🏆 •A faster way• 🏆 

🥇🥇 

🎬 Tipo》 ${typeLabel}
🚩 Nombre》 ${title}
🕔 Género 》 ${g}
🌎 De que trata？》 ${synopsis}

🚴Mensajero activo en Cardenas🗺

📲55786876
📲55250290`
    }

    return copyTemplate
      .replace(/{title}/g, title)
      .replace(/{genre}/g, genre || "No especificado")
      .replace(/{synopsis}/g, synopsis)
      .replace(/{year}/g, String(year))
      .replace(/{type}/g, typeLabel)
  }

  const copySynopsis = async () => {
    const text = getFormattedMessage()
    try {
      await navigator.clipboard.writeText(text)
      setCopyOk(true)
      setTimeout(() => setCopyOk(false), 2000)
    } catch {
      const input = document.createElement("textarea")
      input.value = text
      document.body.appendChild(input)
      input.select()
      document.execCommand("copy")
      document.body.removeChild(input)
      setCopyOk(true)
      setTimeout(() => setCopyOk(false), 2000)
    }
  }

  const download = () => {
    if (!dataUrl) return
    const link = document.createElement("a")
    link.download = `${title.replace(/[^a-zA-Z0-9]/g, "_")}_social.png`
    link.href = dataUrl
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const generatePoster = async (pos?: LogoPosition) => {
    if (!posterPath) return
    const currentPos = pos ?? logoPosition
    setGenerating(true)
    try {
      const canvas = document.createElement("canvas")
      const img = await loadImage(posterPath)
      canvas.width = img.width
      canvas.height = img.height
      const ctx = canvas.getContext("2d")!

      // Dibujar póster completo
      ctx.drawImage(img, 0, 0)

      // Logo según posición seleccionada
      if (currentPos !== "none") {
        try {
          const logo = await loadImage("/logo.png")
          const logoMaxH = Math.round(img.height * 0.12)
          const logoScale = logoMaxH / logo.height
          const logoW = logo.width * logoScale
          const logoH = logo.height * logoScale
          const margin = 30

          let logoX = margin
          let logoY = margin

          switch (currentPos) {
            case "top-left":
              logoX = margin
              logoY = margin
              break
            case "top-center":
              logoX = (img.width - logoW) / 2
              logoY = margin
              break
            case "top-right":
              logoX = img.width - logoW - margin
              logoY = margin
              break
            case "bottom-left":
              logoX = margin
              logoY = img.height - logoH - margin
              break
            case "bottom-center":
              logoX = (img.width - logoW) / 2
              logoY = img.height - logoH - margin
              break
            case "bottom-right":
              logoX = img.width - logoW - margin
              logoY = img.height - logoH - margin
              break
          }

          ctx.drawImage(logo, logoX, logoY, logoW, logoH)
        } catch (e) {
          console.warn("Logo no pudo cargarse:", e)
        }
      }

      setPosterDataUrl(canvas.toDataURL("image/png"))
    } catch (err) {
      console.error("Error generating poster:", err)
    } finally {
      setGenerating(false)
    }
  }

  const downloadPoster = () => {
    if (!posterDataUrl) return
    const link = document.createElement("a")
    link.download = `${title.replace(/[^a-zA-Z0-9]/g, "_")}_poster.png`
    link.href = posterDataUrl
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const openModal = () => {
    setOpen(true)
    setDataUrl(null)
    setPosterDataUrl(null)
    loadTemplate()
    generate(logoPosition)
    generatePoster(logoPosition)
  }

  const regenerateWithLogo = (pos: LogoPosition) => {
    setLogoPosition(pos)
    setDataUrl(null)
    setPosterDataUrl(null)
    setTimeout(() => {
      generate(pos)
      generatePoster(pos)
    }, 50)
  }

  return (
    <>
      <button
        onClick={openModal}
        className="p-2.5 rounded-xl hover:bg-accent/10 text-muted hover:text-accent transition-all"
        title="Generar diseño para redes sociales"
      >
        <ImageIcon className="w-5 h-5" />
      </button>

      {open && mounted && createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#111] border border-white/10 rounded-3xl p-6 max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-black tracking-tight text-lg">
                DISEÑO <span className="text-accent">SOCIAL</span>
              </h3>
              <button
                onClick={() => setOpen(false)}
                className="p-2 rounded-xl hover:bg-white/10 transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-[#050505] rounded-2xl overflow-hidden border border-white/5 mb-4">
              {generating ? (
                <div className="flex items-center justify-center py-32">
                  <Loader2 className="w-8 h-8 text-accent animate-spin" />
                </div>
              ) : dataUrl ? (
                <img
                  src={dataUrl}
                  alt={`Social card for ${title}`}
                  className="w-full h-auto"
                />
              ) : (
                <div className="flex items-center justify-center py-32 text-muted">
                  Error al generar la imagen
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 mb-4">
              <Move className="w-4 h-4 text-muted flex-shrink-0" />
              <span className="text-sm text-muted font-bold">Logo:</span>
              <div className="flex flex-wrap gap-1.5">
                {logoPositions.map((pos) => (
                  <button
                    key={pos.value}
                    onClick={() => regenerateWithLogo(pos.value)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      logoPosition === pos.value
                        ? "bg-accent text-black"
                        : "bg-white/5 text-muted hover:bg-white/10"
                    }`}
                  >
                    {pos.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={download}
              disabled={!dataUrl}
              className="w-full bg-accent text-black font-black py-4 rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(229,9,20,0.4)] disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <Download className="w-5 h-5" />
              DESCARGAR DISEÑO SOCIAL (1200×630)
            </button>

            {posterPath && (
              <button
                onClick={downloadPoster}
                disabled={!posterDataUrl}
                className="w-full bg-white/10 text-foreground font-bold py-3 rounded-2xl hover:bg-white/15 transition-all flex items-center justify-center gap-2 mt-3 disabled:opacity-50"
              >
                <Download className="w-4 h-4" />
                {posterDataUrl ? "DESCARGAR PÓSTER + LOGO" : "GENERANDO PÓSTER..."}
              </button>
            )}

            <button
              onClick={copySynopsis}
              className="w-full bg-white/5 border border-white/10 text-foreground font-bold py-3 rounded-2xl hover:bg-white/10 transition-all flex items-center justify-center gap-2 mt-3"
            >
              <Copy className="w-4 h-4" />
              {copyOk ? "¡SINOPSIS COPIADA!" : "COPIAR SINOPSIS"}
            </button>
          </div>
        </div>,
        document.body
      )}
    </>
  )
}
