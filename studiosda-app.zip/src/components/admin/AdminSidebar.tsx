"use client"

import { LayoutDashboard, Film, PlusCircle, LogOut, Tags, Settings, DollarSign, Menu, X, BarChart3, ShoppingBag } from "lucide-react";
import Link from "next/link";
import useSWR from "swr";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { useState, useEffect, useRef } from "react";

/** Clave del contador de pedidos, para poder refrescarlo desde AdminOrders. */
export const PENDING_ORDERS_KEY = "/api/admin/orders/count";

const fetcher = (url: string) => fetch(url).then((res) => res.json());

/**
 * Aviso de pedidos sin atender.
 *
 * Se muestra el número y no sólo el punto: saber si hay uno o quince cambia
 * si atenderlos es urgente. Sobre el elemento activo el fondo ya es rojo, así
 * que ahí se invierten los colores para que el aviso no desaparezca.
 */
function PendingBadge({ count, active }: { count: number; active: boolean }) {
  if (count <= 0) return null;

  return (
    <span
      className={cn(
        "ml-auto min-w-[20px] h-5 px-1.5 rounded-full text-[11px] font-black flex items-center justify-center tabular-nums",
        active ? "bg-black text-accent" : "bg-accent text-white shadow-[0_0_10px_rgba(229,9,20,0.5)]"
      )}
      aria-label={`${count} ${count === 1 ? "pedido sin atender" : "pedidos sin atender"}`}
    >
      {count > 99 ? "99+" : count}
    </span>
  );
}

export default function AdminSidebar() {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false)
  const drawerRef = useRef<HTMLDivElement>(null)
  const closeBtnRef = useRef<HTMLButtonElement>(null)

  // Sondeo periódico: los pedidos entran desde el catálogo, en otro navegador,
  // así que el panel no se entera de nada si sólo mira al cargar la página.
  const { data: orderCount } = useSWR<{ pending: number }>(PENDING_ORDERS_KEY, fetcher, {
    refreshInterval: 30_000,
    revalidateOnFocus: true,
    keepPreviousData: true,
  });

  const pending = orderCount?.pending ?? 0;

  const menuItems = [
    {
      label: "Dashboard",
      href: "/admin/dashboard",
      icon: BarChart3,
    },
    {
      label: "Añadir Contenido",
      href: "/admin",
      icon: PlusCircle,
    },
    {
      label: "Gestionar Catálogo",
      href: "/admin/list",
      icon: LayoutDashboard,
    },
    {
      label: "Pedidos",
      href: "/admin/orders",
      icon: ShoppingBag,
      badge: pending,
    },
    {
      label: "Gestionar Géneros",
      href: "/admin/genres",
      icon: Tags,
    },
    {
      label: "Precios",
      href: "/admin/prices",
      icon: DollarSign,
    },
    {
      label: "Configuración",
      href: "/admin/config",
      icon: Settings,
    },
  ];

  useEffect(() => {
    if (!mobileOpen) return

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMobileOpen(false)
        return
      }
      // Focus trap
      if (e.key === "Tab" && drawerRef.current) {
        const focusable = drawerRef.current.querySelectorAll<HTMLElement>(
          "a[href], button:not([disabled])"
        )
        const first = focusable[0]
        const last = focusable[focusable.length - 1]
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault()
          last.focus()
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault()
          first.focus()
        }
      }
    }

    document.addEventListener("keydown", handleKeyDown)
    setTimeout(() => closeBtnRef.current?.focus(), 100)

    return () => document.removeEventListener("keydown", handleKeyDown)
  }, [mobileOpen])

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="w-64 bg-card border-r border-white/5 p-6 flex-col gap-8 hidden lg:flex h-screen sticky top-0" role="navigation" aria-label="Panel de administración">
        <Link href="/" className="flex items-center gap-2 mb-4 group" aria-label="Volver al catálogo">
          <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
            <Film className="text-black w-5 h-5" />
          </div>
          <span className="font-black tracking-tighter text-xl">PANEL<span className="text-accent">ADMIN</span></span>
        </Link>

        <nav className="flex flex-col gap-2 flex-grow" aria-label="Menú de administración">
          {menuItems.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={isActive ? "page" : undefined}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium",
                  isActive
                    ? "bg-accent text-black font-bold shadow-[0_0_15px_rgba(229,9,20,0.3)]"
                    : "text-muted hover:bg-white/5 hover:text-foreground"
                )}
              >
                <item.icon className={cn("w-5 h-5 shrink-0", isActive ? "text-black" : "text-accent")} />
                {item.label}
                <PendingBadge count={item.badge ?? 0} active={isActive} />
              </Link>
            );
          })}
        </nav>

        <button
          onClick={async () => {
            await fetch("/api/auth/logout", { method: "POST" });
            window.location.href = "/admin/login";
          }}
          aria-label="Cerrar sesión"
          className="flex items-center gap-3 px-4 py-3 rounded-xl text-red-500/70 hover:bg-red-500/10 hover:text-red-500 transition-all font-bold mt-auto group"
        >
          <LogOut className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
          Cerrar Sesión
        </button>
      </aside>

      {/* Mobile hamburger */}
      <button
        ref={closeBtnRef}
        type="button"
        onClick={() => setMobileOpen(prev => !prev)}
        className="fixed top-4 right-4 z-50 lg:hidden p-2.5 bg-white/10 rounded-xl text-white active:bg-white/20 transition-all"
        aria-label={
          mobileOpen
            ? "Cerrar menú"
            : pending > 0
              ? `Abrir menú (${pending} ${pending === 1 ? "pedido sin atender" : "pedidos sin atender"})`
              : "Abrir menú"
        }
        aria-expanded={mobileOpen}
        aria-controls="admin-mobile-drawer"
      >
        {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}

        {/* En móvil el menú está plegado, así que el aviso tiene que verse
            también sobre el propio botón o no se entera nadie. */}
        {!mobileOpen && pending > 0 && (
          <span
            className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-accent text-white text-[10px] font-black flex items-center justify-center tabular-nums shadow-[0_0_10px_rgba(229,9,20,0.6)] ring-2 ring-background"
            aria-hidden="true"
          >
            {pending > 99 ? "99+" : pending}
          </span>
        )}
      </button>

      {/* Mobile drawer overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={() => setMobileOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Mobile drawer */}
      <div
        id="admin-mobile-drawer"
        ref={drawerRef}
        role="dialog"
        aria-modal="true"
        aria-label="Menú de administración"
        className={cn(
          "fixed top-0 left-0 z-50 h-full w-72 bg-card border-r border-white/5 p-6 flex flex-col gap-8 transition-transform duration-300 lg:hidden",
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <Link href="/" className="flex items-center gap-2 mb-4 group" onClick={() => setMobileOpen(false)} aria-label="Volver al catálogo">
          <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
            <Film className="text-black w-5 h-5" />
          </div>
          <span className="font-black tracking-tighter text-xl">PANEL<span className="text-accent">ADMIN</span></span>
        </Link>

        <nav className="flex flex-col gap-2 flex-grow" aria-label="Menú de administración">
          {menuItems.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                aria-current={isActive ? "page" : undefined}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium",
                  isActive
                    ? "bg-accent text-black font-bold shadow-[0_0_15px_rgba(229,9,20,0.3)]"
                    : "text-muted hover:bg-white/5 hover:text-foreground"
                )}
              >
                <item.icon className={cn("w-5 h-5 shrink-0", isActive ? "text-black" : "text-accent")} />
                {item.label}
                <PendingBadge count={item.badge ?? 0} active={isActive} />
              </Link>
            );
          })}
        </nav>

        <button
          onClick={async () => {
            await fetch("/api/auth/logout", { method: "POST" });
            window.location.href = "/admin/login";
          }}
          aria-label="Cerrar sesión"
          className="flex items-center gap-3 px-4 py-3 rounded-xl text-red-500/70 hover:bg-red-500/10 hover:text-red-500 transition-all font-bold mt-auto group"
        >
          <LogOut className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
          Cerrar Sesión
        </button>
      </div>
    </>
  );
}
