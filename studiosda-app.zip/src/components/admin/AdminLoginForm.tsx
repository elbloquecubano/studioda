"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Lock, User as UserIcon, Loader2 } from "lucide-react"

export default function AdminLoginForm() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    // Timeout de seguridad: si tarda más de 15s, restablece el botón
    const timeout = setTimeout(() => setLoading(false), 15000)

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ username, password }),
        headers: { "Content-Type": "application/json" },
      })

      const data = await res.json().catch(() => ({}))

      if (res.ok) {
        clearTimeout(timeout)

        // Una cuenta de cliente no tiene nada que hacer en el panel.
        if (data.role !== "ADMIN") {
          window.location.href = "/mi-cuenta"
          return
        }

        // Contraseña generada por el instalador: hay que cambiarla antes de
        // dar acceso al resto del panel.
        window.location.href = data.mustChangePassword ? "/admin/cambiar-password" : "/admin"
      } else {
        setError(data.error || "Credenciales inválidas")
      }
    } catch {
      setError("Error de conexión con el servidor")
    } finally {
      clearTimeout(timeout)
      setLoading(false)
    }
  }

  return (
    <div className="glass p-8 rounded-3xl border border-white/10 w-full max-w-md">
      <div className="flex flex-col items-center gap-4 mb-8">
        <div className="w-16 h-16 bg-accent rounded-2xl flex items-center justify-center shadow-[0_0_30px_rgba(229,9,20,0.3)]">
          <Lock className="text-black w-8 h-8" />
        </div>
        <h1 className="text-3xl font-black tracking-tighter">ADMIN <span className="text-accent">PANEL</span></h1>
        <p className="text-muted text-sm">Ingresa tus credenciales para gestionar el catálogo</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-widest text-muted px-1">Usuario</label>
          <div className="relative">
            <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted" />
            <input 
              type="text" 
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-accent/50 focus:bg-white/10 transition-all"
              placeholder="Nombre de usuario"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-widest text-muted px-1">Contraseña</label>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted" />
            <input 
              type="password" 
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-accent/50 focus:bg-white/10 transition-all"
              placeholder="••••••••"
            />
          </div>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-500 text-sm py-3 px-4 rounded-xl text-center">
            {error}
          </div>
        )}

        <button 
          type="submit"
          disabled={loading}
          className="w-full bg-accent text-black font-black py-4 rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(229,9,20,0.4)] disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center gap-2"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "ACCEDER"}
        </button>
      </form>
    </div>
  )
}
