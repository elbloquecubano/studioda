"use client"

import { FormEvent, useEffect, useMemo, useState } from "react";
import { Edit, Loader2, Plus, Save, Search, Tags, Trash2, X } from "lucide-react";
import type { Genre } from "@/lib/genres";
import { useToast } from "@/components/ui/Toast";
import { useConfirm } from "@/components/ui/ConfirmDialog";

async function readApiError(response: Response, fallback: string) {
  try {
    const data = (await response.json()) as { error?: string };
    return data.error || fallback;
  } catch {
    return fallback;
  }
}

export default function AdminGenres() {
  const [genres, setGenres] = useState<Genre[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [name, setName] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const { toast } = useToast();
  const { confirm } = useConfirm();

  useEffect(() => {
    let isActive = true;

    fetch("/api/genres")
      .then((res) => res.json())
      .then((data: Genre[]) => {
        if (isActive) setGenres(Array.isArray(data) ? data : []);
      })
      .catch(() => {
        toast("Error al cargar los generos.", "error");
      })
      .finally(() => {
        if (isActive) setLoading(false);
      });

    return () => {
      isActive = false;
    };
  }, []);

  const filteredGenres = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();
    if (!query) return genres;
    return genres.filter((genre) => genre.name.toLowerCase().includes(query));
  }, [genres, searchTerm]);

  const handleCreate = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextName = name.trim();
    if (!nextName) return;

    setSubmitting(true);
    try {
      const res = await fetch("/api/genres", {
        method: "POST",
        body: JSON.stringify({ name: nextName }),
        headers: { "Content-Type": "application/json" },
      });

      if (!res.ok) {
        toast(await readApiError(res, "Error al crear el genero."), "error");
        return;
      }

      const data = (await res.json()) as { genre: Genre };
      setGenres((current) =>
        [...current, data.genre].sort((a, b) => a.name.localeCompare(b.name))
      );
      setName("");
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdate = async (id: string) => {
    const nextName = editName.trim();
    if (!nextName) return;

    setSubmitting(true);
    try {
      const res = await fetch(`/api/genres/${id}`, {
        method: "PATCH",
        body: JSON.stringify({ name: nextName }),
        headers: { "Content-Type": "application/json" },
      });

      if (!res.ok) {
        toast(await readApiError(res, "Error al actualizar el genero."), "error");
        return;
      }

      const data = (await res.json()) as { genre: Genre };
      setGenres((current) =>
        current
          .map((genre) => (genre.id === id ? data.genre : genre))
          .sort((a, b) => a.name.localeCompare(b.name))
      );
      setEditingId(null);
      setEditName("");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (genre: Genre) => {
    const ok = await confirm({
      message: `Eliminar el genero "${genre.name}"?`,
      confirmLabel: "Eliminar",
      danger: true,
    });
    if (!ok) return;

    try {
      const res = await fetch(`/api/genres/${genre.id}`, { method: "DELETE" });

      if (!res.ok) {
        toast(await readApiError(res, "Error al eliminar el genero."), "error");
        return;
      }

      setGenres((current) => current.filter((item) => item.id !== genre.id));
    } catch {
      toast("Error de conexion.", "error");
    }
  };

  return (
    <div className="glass p-8 rounded-3xl border border-white/10 max-w-5xl mx-auto">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-12 h-12 bg-accent rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(229,9,20,0.3)]">
          <Tags className="text-black w-6 h-6" />
        </div>
        <div>
          <h2 className="text-2xl font-black tracking-tighter uppercase">
            GESTIONAR <span className="text-accent">GENEROS</span>
          </h2>
          <p className="text-muted text-sm">
            Crea generos y luego seleccionalos al agregar o editar contenido
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-4 mb-6">
        <form onSubmit={handleCreate} className="flex gap-3">
          <input
            value={name}
            onChange={(event) => setName(event.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:outline-none focus:ring-1 focus:ring-accent/50 transition-all"
            placeholder="Nuevo genero"
          />
          <button
            type="submit"
            disabled={submitting || !name.trim()}
            className="px-5 py-3 bg-accent text-black rounded-xl font-black transition-all disabled:opacity-50 flex items-center gap-2"
            title="Crear genero"
          >
            {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Plus className="w-5 h-5" />}
            Crear
          </button>
        </form>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
          <input
            type="text"
            placeholder="Buscar genero..."
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50"
          />
        </div>
      </div>

      <div className="rounded-2xl border border-white/10 bg-black/30 max-h-[520px] overflow-y-auto admin-scroll-area divide-y divide-white/5">
        {loading ? (
          <div className="flex items-center justify-center gap-3 py-16 text-muted">
            <Loader2 className="w-6 h-6 animate-spin text-accent" />
            <span className="text-sm font-bold uppercase tracking-widest">Cargando generos...</span>
          </div>
        ) : filteredGenres.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-center py-16 text-muted">
            <Tags className="w-10 h-10 mb-3" />
            <p>No hay generos para mostrar</p>
          </div>
        ) : (
          filteredGenres.map((genre) => {
            const isEditing = editingId === genre.id;
            return (
              <div key={genre.id} className="flex items-center gap-4 p-4 hover:bg-white/5 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center flex-shrink-0">
                  <Tags className="w-5 h-5 text-accent" />
                </div>

                {isEditing ? (
                  <input
                    value={editName}
                    onChange={(event) => setEditName(event.target.value)}
                    className="flex-grow bg-black/40 border border-white/10 rounded-xl py-2.5 px-3 focus:outline-none focus:ring-1 focus:ring-accent/50"
                    autoFocus
                  />
                ) : (
                  <div className="flex-grow min-w-0">
                    <h3 className="font-bold truncate">{genre.name}</h3>
                    <p className="text-xs text-muted truncate">{genre.slug}</p>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  {isEditing ? (
                    <>
                      <button
                        type="button"
                        onClick={() => handleUpdate(genre.id)}
                        disabled={submitting}
                        className="p-2.5 rounded-xl hover:bg-white/10 text-accent transition-all disabled:opacity-50"
                        title="Guardar"
                      >
                        <Save className="w-5 h-5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setEditingId(null);
                          setEditName("");
                        }}
                        className="p-2.5 rounded-xl hover:bg-white/10 text-muted hover:text-foreground transition-all"
                        title="Cancelar"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        type="button"
                        onClick={() => {
                          setEditingId(genre.id);
                          setEditName(genre.name);
                        }}
                        className="p-2.5 rounded-xl hover:bg-white/5 text-muted hover:text-accent transition-all"
                        title="Editar"
                      >
                        <Edit className="w-5 h-5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDelete(genre)}
                        className="p-2.5 rounded-xl hover:bg-red-500/10 text-red-500/50 hover:text-red-500 transition-all"
                        title="Eliminar"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
