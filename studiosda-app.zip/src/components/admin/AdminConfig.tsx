"use client"

import { useRef, useState, useEffect } from "react"
import AdminContentTypes from "@/components/admin/AdminContentTypes"
import { Download, Upload, Loader2, CheckCircle, AlertCircle, Database, Store, Clock, FileText } from "lucide-react"
import { useToast } from "@/components/ui/Toast"
import { useConfirm } from "@/components/ui/ConfirmDialog"

interface StoreConfig {
  id: string
  location: string
  address: string
  openTime: string
  closeTime: string
}

const LOCATION_LABELS: Record<string, string> = {
  matriz: "Studios D-A (Matriz)",
  actualizate: "Actualizate",
  cinemania: "Cinemanía",
  fastcopier: "Fast Copier",
}

export default function AdminConfig() {
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [exporting, setExporting] = useState(false)
  const [importing, setImporting] = useState(false)
  const [message, setMessage] = useState<{ type: "ok" | "error"; text: string } | null>(null)
  const [stores, setStores] = useState<StoreConfig[]>([])
  const [loadingStores, setLoadingStores] = useState(true)
  const [savingStore, setSavingStore] = useState<string | null>(null)
  const [copyTemplate, setCopyTemplate] = useState("")
  const [loadingTemplate, setLoadingTemplate] = useState(true)
  const [savingTemplate, setSavingTemplate] = useState(false)
  const { toast } = useToast()
  const { confirm } = useConfirm()

  useEffect(() => {
    fetch("/api/admin/store-config")
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) setStores(data)
      })
      .catch(() => {})
      .finally(() => setLoadingStores(false))
  }, [])

  useEffect(() => {
    fetch("/api/admin/site-config")
      .then(res => res.json())
      .then(data => {
        if (data.value) setCopyTemplate(data.value)
      })
      .catch(() => {})
      .finally(() => setLoadingTemplate(false))
  }, [])

  const handleSaveTemplate = async () => {
    setSavingTemplate(true)
    setMessage(null)
    try {
      const res = await fetch("/api/admin/site-config", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ value: copyTemplate }),
      })
      if (!res.ok) throw new Error("Error al guardar")
      setMessage({ type: "ok", text: "Plantilla guardada correctamente" })
    } catch {
      setMessage({ type: "error", text: "Error al guardar plantilla" })
    } finally {
      setSavingTemplate(false)
    }
  }

  const handleExport = async () => {
    setExporting(true)
    setMessage(null)
    try {
      const res = await fetch("/api/admin/export")
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: "Error al exportar" }))
        throw new Error(err.error)
      }
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `studiosda-backup-${new Date().toISOString().slice(0, 10)}.json`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      setMessage({ type: "ok", text: "Base de datos exportada correctamente" })
    } catch (err: any) {
      setMessage({ type: "error", text: err.message || "Error al exportar" })
    } finally {
      setExporting(false)
    }
  }

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const ok = await confirm({
      message: "¿Estás seguro? Se reemplazarán TODOS los datos actuales con los del archivo seleccionado.",
      confirmLabel: "Importar",
      danger: true,
    })
    if (!ok) {
      if (fileInputRef.current) fileInputRef.current.value = ""
      return
    }

    setImporting(true)
    setMessage(null)
    try {
      const formData = new FormData()
      formData.append("file", file)
      const res = await fetch("/api/admin/import", { method: "POST", body: formData })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || "Error al importar")
      setMessage({ type: "ok", text: "Datos importados correctamente. Recarga la página para ver los cambios." })
    } catch (err: any) {
      setMessage({ type: "error", text: err.message || "Error al importar" })
    } finally {
      setImporting(false)
      if (fileInputRef.current) fileInputRef.current.value = ""
    }
  }

  const handleStoreChange = (id: string, field: "address" | "openTime" | "closeTime", value: string) => {
    setStores(prev => prev.map(s => s.id === id ? { ...s, [field]: value } : s))
  }

  const handleSaveStore = async (store: StoreConfig) => {
    setSavingStore(store.id)
    setMessage(null)
    try {
      const res = await fetch("/api/admin/store-config", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(store),
      })
      if (!res.ok) throw new Error("Error al guardar")
      setMessage({ type: "ok", text: `${LOCATION_LABELS[store.location] || store.location} guardado` })
    } catch {
      setMessage({ type: "error", text: "Error al guardar" })
    } finally {
      setSavingStore(null)
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4 mb-2">
        <div className="w-12 h-12 bg-accent/20 rounded-2xl flex items-center justify-center">
          <Database className="w-6 h-6 text-accent" />
        </div>
        <div>
          <h1 className="text-2xl font-black tracking-tighter">CONFIGURACIÓN</h1>
          <p className="text-muted text-sm">Exportar/importar datos y configurar horarios</p>
        </div>
      </div>

      {message && (
        <div
          className={`flex items-center gap-3 py-3 px-4 rounded-xl text-sm font-medium ${
            message.type === "ok"
              ? "bg-green-500/10 border border-green-500/20 text-green-500"
              : "bg-red-500/10 border border-red-500/20 text-red-500"
          }`}
        >
          {message.type === "ok" ? <CheckCircle className="w-5 h-5 shrink-0" /> : <AlertCircle className="w-5 h-5 shrink-0" />}
          {message.text}
        </div>
      )}

      {/* Store Hours */}
      <div className="glass rounded-2xl border border-white/10 p-6 space-y-6">
        <div className="flex items-center gap-3">
          <Store className="w-6 h-6 text-accent" />
          <h2 className="font-bold text-lg">Horarios de Locales</h2>
        </div>
        <p className="text-muted text-sm">Estos horarios se usarán en la tarjeta social generada.</p>

        {loadingStores ? (
          <div className="flex items-center gap-2 text-muted text-sm"><Loader2 className="w-4 h-4 animate-spin" /> Cargando...</div>
        ) : (
          <div className="space-y-4">
            {stores.map(store => (
              <div key={store.id} className="bg-white/5 rounded-xl p-4 space-y-3">
                <div className="flex items-center gap-2 font-bold text-sm">
                  <Store className="w-4 h-4 text-accent" />
                  {LOCATION_LABELS[store.location] || store.location}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <div className="sm:col-span-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-muted">Dirección</label>
                    <input
                      value={store.address}
                      onChange={e => handleStoreChange(store.id, "address", e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest text-muted">Apertura</label>
                    <input
                      type="time"
                      value={store.openTime}
                      onChange={e => handleStoreChange(store.id, "openTime", e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest text-muted">Cierre</label>
                    <input
                      type="time"
                      value={store.closeTime}
                      onChange={e => handleStoreChange(store.id, "closeTime", e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-lg py-2 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-accent/50"
                    />
                  </div>
                </div>
                <div className="flex justify-end">
                  <button
                    onClick={() => handleSaveStore(store)}
                    disabled={savingStore === store.id}
                    className="bg-accent text-black font-bold py-1.5 px-4 rounded-lg text-xs hover:scale-[1.02] transition-all disabled:opacity-50 flex items-center gap-1"
                  >
                    {savingStore === store.id ? <Loader2 className="w-3 h-3 animate-spin" /> : null}
                    GUARDAR
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Content Types & Genres */}
      <AdminContentTypes />

      {/* Copy Template */}
      <div className="glass rounded-2xl border border-white/10 p-6 space-y-6">
        <div className="flex items-center gap-3">
          <FileText className="w-6 h-6 text-accent" />
          <h2 className="font-bold text-lg">Plantilla de Texto (Copiar Sinopsis)</h2>
        </div>
        <p className="text-muted text-sm">
          Edita la plantilla que se copiará al presionar &quot;Copiar Sinopsis&quot; en el generador de tarjetas sociales.
          <br />
          <span className="text-accent font-semibold">Variables disponibles:</span> {"{title}"}, {"{genre}"}, {"{synopsis}"}, {"{year}"}, {"{type}"}
        </p>

        {loadingTemplate ? (
          <div className="flex items-center gap-2 text-muted text-sm"><Loader2 className="w-4 h-4 animate-spin" /> Cargando...</div>
        ) : (
          <div className="space-y-4">
            <textarea
              value={copyTemplate}
              onChange={e => setCopyTemplate(e.target.value)}
              rows={12}
              className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-accent/50 resize-y"
              placeholder="Escribe la plantilla aquí..."
            />

            {/* Vista previa */}
            <div className="bg-white/5 rounded-xl p-4 border border-white/5">
              <p className="text-[10px] font-bold uppercase tracking-widest text-muted mb-3">Vista Previa (con datos de ejemplo)</p>
              <pre className="text-sm text-foreground/80 whitespace-pre-wrap font-mono leading-relaxed">
                {copyTemplate
                  .replace(/{title}/g, "EJEMPLO: Película")
                  .replace(/{genre}/g, "Acción, Aventura")
                  .replace(/{synopsis}/g, "Sinopsis de ejemplo para previsualizar cómo quedará el texto copiado.")
                  .replace(/{year}/g, "2024")
                  .replace(/{type}/g, "Película")
                }
              </pre>
            </div>

            <div className="flex justify-end">
              <button
                onClick={handleSaveTemplate}
                disabled={savingTemplate}
                className="bg-accent text-black font-bold py-2 px-6 rounded-xl text-sm hover:scale-[1.02] transition-all disabled:opacity-50 flex items-center gap-2"
              >
                {savingTemplate ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                GUARDAR PLANTILLA
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="glass rounded-2xl border border-white/10 p-6 space-y-6">
        <h2 className="font-bold text-lg">Exportar</h2>
        <p className="text-muted text-sm">
          Descarga un archivo JSON con todos los contenidos y géneros del catálogo.
        </p>
        <button
          onClick={handleExport}
          disabled={exporting}
          className="bg-accent text-black font-bold py-3 px-6 rounded-xl hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 flex items-center gap-2"
        >
          {exporting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Download className="w-5 h-5" />}
          {exporting ? "Exportando..." : "Exportar Base de Datos"}
        </button>
      </div>

      <div className="glass rounded-2xl border border-white/10 p-6 space-y-6">
        <h2 className="font-bold text-lg">Importar</h2>
        <p className="text-muted text-sm">
          Selecciona un archivo JSON previamente exportado para restaurar los datos.
          <br />
          <span className="text-red-500 font-semibold">ADVERTENCIA:</span> Esto reemplazará todos los datos actuales.
        </p>
        <label className="inline-block">
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            onChange={handleImport}
            className="hidden"
          />
          <div className="bg-white/10 text-foreground font-bold py-3 px-6 rounded-xl hover:bg-white/20 transition-all cursor-pointer flex items-center gap-2">
            {importing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Upload className="w-5 h-5" />}
            {importing ? "Importando..." : "Importar desde archivo"}
          </div>
        </label>
      </div>
    </div>
  )
}
