"use client"

import { useState } from "react"
import { Lock, ShieldAlert, Loader2 } from "lucide-react"
import AuthField from "@/components/cuenta/AuthField"

export default function AdminCambiarPassword() {
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirm, setConfirm] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (newPassword !== confirm) {
      setError("Las contraseñas nuevas no coinciden")
      return
    }

    setLoading(true)

    try {
      const res = await fetch("/api/me/password", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      })
      const data = await res.json().catch(() => ({}))

      if (!res.ok) {
        setError(data.error || "No se pudo cambiar la contraseña")
        setLoading(false)
        return
      }

      window.location.href = "/admin"
    } catch {
      setError("Error de conexión con el servidor")
      setLoading(false)
    }
  }

  return (
    <div className="glass p-8 rounded-3xl border border-white/10 w-full max-w-md">
      <div className="flex flex-col items-center gap-4 mb-8 text-center">
        <div className="w-16 h-16 bg-accent rounded-2xl flex items-center justify-center shadow-[0_0_30px_rgba(229,9,20,0.3)]">
          <ShieldAlert className="text-black w-8 h-8" />
        </div>
        <h1 className="text-2xl font-black tracking-tighter">
          CAMBIA TU <span className="text-accent">CONTRASEÑA</span>
        </h1>
        <p className="text-muted text-sm">
          Estás usando la contraseña generada durante la instalación. Elige una propia antes de
          continuar.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <AuthField
          icon={Lock}
          label="Contraseña actual"
          type="password"
          value={currentPassword}
          onChange={setCurrentPassword}
          autoComplete="current-password"
          required
        />

        <AuthField
          icon={Lock}
          label="Contraseña nueva"
          type="password"
          value={newPassword}
          onChange={setNewPassword}
          autoComplete="new-password"
          hint="Mínimo 8 caracteres"
          required
        />

        <AuthField
          icon={Lock}
          label="Repite la contraseña nueva"
          type="password"
          value={confirm}
          onChange={setConfirm}
          autoComplete="new-password"
          required
        />

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-500 text-sm py-3 px-4 rounded-xl text-center">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-accent text-black font-black py-4 rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(229,9,20,0.4)] disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center gap-2"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "GUARDAR Y CONTINUAR"}
        </button>
      </form>
    </div>
  )
}
