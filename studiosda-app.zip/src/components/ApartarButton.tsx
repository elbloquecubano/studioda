"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { BookmarkCheck, Loader2, ShoppingBag } from "lucide-react"
import { useToast } from "@/components/ui/Toast"

/**
 * Aparta un título desde la ficha de contenido.
 *
 * No comprueba la sesión antes de tiempo: la ficha se sirve cacheada para todo
 * el mundo, así que preguntar aquí quién eres obligaría a renderizarla en cada
 * petición. Se intenta el pedido y, si el servidor responde 401, se manda al
 * login con `next` para volver justo aquí.
 */
export default function ApartarButton({ mediaId }: { mediaId: string }) {
  const [busy, setBusy] = useState(false)
  const [done, setDone] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  const apartar = async () => {
    setBusy(true)

    try {
      const res = await fetch("/api/me/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mediaId }),
      })

      if (res.status === 401) {
        const next = encodeURIComponent(window.location.pathname)
        router.push(`/cuenta/login?next=${next}`)
        return
      }

      if (!res.ok) {
        let message = "No se pudo apartar el título."
        try {
          const data = (await res.json()) as { error?: string }
          if (data.error) message = data.error
        } catch {
          // Respuesta sin JSON: se queda el mensaje genérico.
        }
        // 409 significa que ya lo tenía apartado, así que el botón pasa igual a
        // su estado final: el resultado que quería el usuario ya se cumple.
        if (res.status === 409) setDone(true)
        toast(message, res.status === 409 ? "info" : "error")
        return
      }

      setDone(true)
      toast("¡Apartado! Lo verás en «Mis pedidos».", "success")
    } catch {
      toast("Error de conexión. Inténtalo de nuevo.", "error")
    } finally {
      setBusy(false)
    }
  }

  if (done) {
    return (
      <button
        type="button"
        onClick={() => router.push("/mi-cuenta/pedidos")}
        className="flex items-center gap-2 px-5 py-3 rounded-xl bg-green-500/20 border border-green-500/40 text-green-500 hover:bg-green-500/30 transition-all font-bold text-sm"
      >
        <BookmarkCheck className="w-5 h-5" />
        Apartado — ver mis pedidos
      </button>
    )
  }

  return (
    <button
      type="button"
      onClick={apartar}
      disabled={busy}
      className="flex items-center gap-2 px-5 py-3 rounded-xl bg-accent text-black hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:hover:scale-100 transition-all font-bold text-sm"
    >
      {busy ? <Loader2 className="w-5 h-5 animate-spin" /> : <ShoppingBag className="w-5 h-5" />}
      Apartar
    </button>
  )
}
