"use client"

import Image from "next/image"
import Link from "next/link"
import { Play } from "lucide-react"
import { motion } from "framer-motion"
import { useState } from "react"
import type { MediaListItem } from "@/lib/types"

interface MovieCardProps {
  movie: Pick<MediaListItem, "id" | "title" | "posterPath" | "year">
}

export default function MovieCard({ movie }: MovieCardProps) {
  const posterSrc = movie.posterPath.trim()
  const [imgError, setImgError] = useState(false)

  return (
    <motion.div
      whileHover={{ scale: 1.05, y: -5 }}
      transition={{ duration: 0.3 }}
      className="group relative aspect-[2/3] rounded-xl overflow-hidden bg-zinc-800 border border-white/10"
      role="article"
      aria-label={`${movie.title}, ${movie.year}`}
    >
      <Link
        href={`/movie/${movie.id}`}
        className="absolute inset-0 block"
        aria-label={`Ver detalles de ${movie.title}`}
        tabIndex={0}
      >
        {posterSrc && !imgError ? (
          <Image
            src={posterSrc}
            alt={`Póster de ${movie.title}`}
            fill
            unoptimized
            sizes="(min-width: 1024px) 16vw, (min-width: 768px) 25vw, (min-width: 640px) 33vw, 50vw"
            className="object-cover transition-transform duration-500 group-hover:scale-110 group-focus-within:scale-110"
            placeholder="blur"
            blurDataURL="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjMwMCIgZmlsbD0iIzJhMmEyYSIvPjwvc3ZnPg=="
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center bg-zinc-800 p-4 text-center text-xs font-bold uppercase tracking-widest text-muted">
            Sin poster
          </div>
        )}

        {/* Info always visible on mobile, on hover on desktop */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-3 pt-8">
          <h3 className="font-bold text-sm line-clamp-1 text-white drop-shadow-lg">{movie.title}</h3>
          <div className="flex items-center justify-between text-[10px] text-accent font-bold uppercase tracking-widest mt-1">
            <span>{movie.year}</span>
          </div>
        </div>

        {/* Hover Overlay - only on desktop */}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity duration-300 hidden sm:flex flex-col justify-end p-4" aria-hidden="true">
          <div className="bg-accent/90 p-3 rounded-full self-center mb-auto mt-auto transform translate-y-4 group-hover:translate-y-0 group-focus-within:translate-y-0 transition-transform duration-300">
            <Play className="w-6 h-6 text-black fill-current" />
          </div>
        </div>
      </Link>
    </motion.div>
  )
}
