"use client"

import { createContext, useContext, useState, useCallback, useEffect, useRef } from "react"
import { AlertTriangle } from "lucide-react"

interface ConfirmOptions {
  title?: string
  message: string
  confirmLabel?: string
  cancelLabel?: string
  danger?: boolean
}

interface ConfirmContextValue {
  confirm: (options: ConfirmOptions) => Promise<boolean>
}

const ConfirmContext = createContext<ConfirmContextValue | null>(null)

export function ConfirmProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<{
    options: ConfirmOptions
    resolve: (value: boolean) => void
  } | null>(null)
  const confirmBtnRef = useRef<HTMLButtonElement>(null)

  const confirm = useCallback((options: ConfirmOptions) => {
    return new Promise<boolean>((resolve) => {
      setState({ options, resolve })
    })
  }, [])

  const handleConfirm = () => {
    state?.resolve(true)
    setState(null)
  }

  const handleCancel = () => {
    state?.resolve(false)
    setState(null)
  }

  useEffect(() => {
    if (!state) return

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault()
        handleCancel()
      } else if (e.key === "Tab") {
        // Focus trap: keep focus within the dialog
        const dialog = document.querySelector("[data-confirm-dialog]")
        if (!dialog) return
        const focusable = dialog.querySelectorAll<HTMLElement>(
          "button:not([disabled])"
        )
        const first = focusable[0]
        const last = focusable[focusable.length - 1]
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault()
          last.focus()
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault()
          first.focus()
        }
      }
    }

    document.addEventListener("keydown", handleKeyDown)
    // Auto-focus confirm button
    setTimeout(() => confirmBtnRef.current?.focus(), 50)

    return () => document.removeEventListener("keydown", handleKeyDown)
  }, [state])

  return (
    <ConfirmContext.Provider value={{ confirm }}>
      {children}
      {state && (
        <div className="fixed inset-0 z-[9998] flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-labelledby="confirm-title">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={handleCancel} />
          <div
            data-confirm-dialog
            className="relative bg-[#1a1a1a] border border-white/10 rounded-2xl shadow-2xl max-w-md w-full p-6 animate-in zoom-in-95 duration-200"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 id="confirm-title" className="text-lg font-bold">
                  {state.options.title || "Confirmar"}
                </h3>
              </div>
            </div>
            <p className="text-foreground/70 text-sm mb-6 pl-16">
              {state.options.message}
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={handleCancel}
                className="px-4 py-2 rounded-xl text-sm font-bold bg-white/5 hover:bg-white/10 transition-colors"
              >
                {state.options.cancelLabel || "Cancelar"}
              </button>
              <button
                ref={confirmBtnRef}
                onClick={handleConfirm}
                className={`px-4 py-2 rounded-xl text-sm font-bold transition-colors ${
                  state.options.danger
                    ? "bg-red-600 hover:bg-red-700 text-white"
                    : "bg-accent hover:bg-accent/90 text-black"
                }`}
              >
                {state.options.confirmLabel || "Confirmar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </ConfirmContext.Provider>
  )
}

export function useConfirm() {
  const ctx = useContext(ConfirmContext)
  if (!ctx) throw new Error("useConfirm must be used within ConfirmProvider")
  return ctx
}
