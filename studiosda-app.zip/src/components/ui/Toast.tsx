"use client"

import { createContext, useContext, useState, useCallback, useEffect, useRef } from "react"
import { X, CheckCircle, AlertCircle, Info } from "lucide-react"
import { cn } from "@/lib/utils"

type ToastType = "success" | "error" | "info"

interface Toast {
  id: number
  message: string
  type: ToastType
}

interface ToastContextValue {
  toast: (message: string, type?: ToastType) => void
}

const ToastContext = createContext<ToastContextValue | null>(null)

let toastId = 0

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])
  const timersRef = useRef<Map<number, ReturnType<typeof setTimeout>>>(new Map())

  const removeToast = useCallback((id: number) => {
    const timer = timersRef.current.get(id)
    if (timer) clearTimeout(timer)
    timersRef.current.delete(id)
    setToasts((prev) => prev.filter((t) => t.id !== id))
  }, [])

  const toast = useCallback(
    (message: string, type: ToastType = "info") => {
      const id = ++toastId
      setToasts((prev) => [...prev.slice(-4), { id, message, type }])
      const timer = setTimeout(() => removeToast(id), 4000)
      timersRef.current.set(id, timer)
    },
    [removeToast]
  )

  useEffect(() => {
    return () => {
      timersRef.current.forEach((t) => clearTimeout(t))
    }
  }, [])

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="fixed bottom-6 right-6 z-[9999] flex flex-col gap-2 pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={cn(
              "pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-xl shadow-2xl border backdrop-blur-sm animate-in slide-in-from-right-full duration-300 min-w-[280px] max-w-[400px]",
              t.type === "success" && "bg-green-950/90 border-green-500/30 text-green-200",
              t.type === "error" && "bg-red-950/90 border-red-500/30 text-red-200",
              t.type === "info" && "bg-zinc-900/90 border-white/10 text-foreground"
            )}
          >
            {t.type === "success" && <CheckCircle className="w-5 h-5 flex-shrink-0" />}
            {t.type === "error" && <AlertCircle className="w-5 h-5 flex-shrink-0" />}
            {t.type === "info" && <Info className="w-5 h-5 flex-shrink-0" />}
            <span className="text-sm font-medium flex-1">{t.message}</span>
            <button
              onClick={() => removeToast(t.id)}
              className="p-0.5 hover:bg-white/10 rounded-lg transition-colors flex-shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}

export function useToast() {
  const ctx = useContext(ToastContext)
  if (!ctx) throw new Error("useToast must be used within ToastProvider")
  return ctx
}
