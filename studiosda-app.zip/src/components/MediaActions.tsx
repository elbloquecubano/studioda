"use client"

import { useState, useEffect } from "react"
import { ThumbsUp, ThumbsDown, Share2, Loader2 } from "lucide-react"

const STORAGE_KEY = "studiosda_votes"

interface MediaActionsProps {
  mediaId: string
  initialLikes: number
  initialDislikes: number
}

function getVote(mediaId: string): "like" | "dislike" | null {
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored) {
      const votes = JSON.parse(stored)
      return votes[mediaId] || null
    }
  } catch {}
  return null
}

function setVote(mediaId: string, vote: "like" | "dislike" | null) {
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    const votes = stored ? JSON.parse(stored) : {}
    if (vote === null) {
      delete votes[mediaId]
    } else {
      votes[mediaId] = vote
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(votes))
  } catch {}
}

export default function MediaActions({ mediaId, initialLikes, initialDislikes }: MediaActionsProps) {
  const [likes, setLikes] = useState(initialLikes)
  const [dislikes, setDislikes] = useState(initialDislikes)
  const [myVote, setMyVote] = useState<"like" | "dislike" | null>(null)
  const [busy, setBusy] = useState<"like" | "dislike" | null>(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    setMyVote(getVote(mediaId))
  }, [mediaId])

  const interact = async (action: "like" | "dislike") => {
    setBusy(action)

    try {
      // Si ya votó igual → quitar voto
      if (myVote === action) {
        const res = await fetch(`/api/media/${mediaId}/interact`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: `un${action}` }),
        })
        if (res.ok) {
          const data = await res.json()
          setLikes(data.likes)
          setDislikes(data.dislikes)
          setMyVote(null)
          setVote(mediaId, null)
        }
        return
      }

      // Si ya votó lo contrario → quitar ese voto primero
      const otherAction = action === "like" ? "dislike" : "like"
      if (myVote === otherAction) {
        const undoRes = await fetch(`/api/media/${mediaId}/interact`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: `un${otherAction}` }),
        })
        if (!undoRes.ok) return
      }

      // Luego agregar el nuevo voto
      const res = await fetch(`/api/media/${mediaId}/interact`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      })
      if (res.ok) {
        const data = await res.json()
        setLikes(data.likes)
        setDislikes(data.dislikes)
        setMyVote(action)
        setVote(mediaId, action)
      }
    } catch {
      // fallo silencioso
    } finally {
      setBusy(null)
    }
  }

  const share = async () => {
    const url = window.location.href
    try {
      await navigator.clipboard.writeText(url)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      const input = document.createElement("input")
      input.value = url
      document.body.appendChild(input)
      input.select()
      document.execCommand("copy")
      document.body.removeChild(input)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className="flex items-center gap-4 flex-wrap">
      <button
        onClick={() => interact("like")}
        disabled={busy !== null}
        className={`flex items-center gap-2 px-5 py-3 rounded-xl border transition-all disabled:opacity-50 font-bold text-sm ${
          myVote === "like"
            ? "bg-green-500/20 border-green-500/40 text-green-500"
            : "bg-white/5 border-white/10 hover:bg-green-500/10 hover:border-green-500/30 hover:text-green-500"
        }`}
      >
        {busy === "like" ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          <ThumbsUp className={`w-5 h-5 ${myVote === "like" ? "fill-green-500" : ""}`} />
        )}
        <span>{likes}</span>
      </button>

      <button
        onClick={() => interact("dislike")}
        disabled={busy !== null}
        className={`flex items-center gap-2 px-5 py-3 rounded-xl border transition-all disabled:opacity-50 font-bold text-sm ${
          myVote === "dislike"
            ? "bg-red-500/20 border-red-500/40 text-red-500"
            : "bg-white/5 border-white/10 hover:bg-red-500/10 hover:border-red-500/30 hover:text-red-500"
        }`}
      >
        {busy === "dislike" ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          <ThumbsDown className={`w-5 h-5 ${myVote === "dislike" ? "fill-red-500" : ""}`} />
        )}
        <span>{dislikes}</span>
      </button>

      <button
        onClick={share}
        className="flex items-center gap-2 px-5 py-3 rounded-xl bg-accent/10 border border-accent/20 text-accent hover:bg-accent/20 transition-all font-bold text-sm"
      >
        <Share2 className="w-5 h-5" />
        {copied ? "¡Enlace copiado!" : "Recomendar"}
      </button>
    </div>
  )
}
