"use client"

import { useState } from "react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { LogIn, Lock, User as UserIcon, Loader2 } from "lucide-react"
import AuthShell from "./AuthShell"
import AuthField from "./AuthField"

export default function ClienteLoginForm() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const searchParams = useSearchParams()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      })

      const data = await res.json().catch(() => ({}))

      if (!res.ok) {
        setError(data.error || "No se pudo iniciar sesión")
        setLoading(false)
        return
      }

      // El proxy guarda la ruta de origen en ?next cuando redirige aquí.
      // Se aceptan solo rutas internas: una URL absoluta permitiria enviar a
      // la persona a otro sitio despues de entrar.
      const next = searchParams.get("next")
      const target = next && next.startsWith("/") && !next.startsWith("//") ? next : "/mi-cuenta"

      // Recarga completa para que los componentes de servidor vuelvan a leer
      // la cookie recien puesta.
      window.location.href = data.role === "ADMIN" ? "/admin" : target
    } catch {
      setError("Error de conexión con el servidor")
      setLoading(false)
    }
  }

  return (
    <AuthShell
      icon={LogIn}
      title="MI"
      highlight="CUENTA"
      subtitle="Entra para guardar tus apartados y ver tus pedidos"
      footer={
        <>
          ¿Todavía no tienes cuenta?{" "}
          <Link href="/cuenta/registro" className="text-accent font-bold hover:underline">
            Regístrate
          </Link>
        </>
      }
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        <AuthField
          icon={UserIcon}
          label="Usuario"
          value={username}
          onChange={setUsername}
          placeholder="Nombre de usuario"
          autoComplete="username"
          required
        />

        <AuthField
          icon={Lock}
          label="Contraseña"
          type="password"
          value={password}
          onChange={setPassword}
          placeholder="••••••••"
          autoComplete="current-password"
          required
        />

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-500 text-sm py-3 px-4 rounded-xl text-center">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-accent text-black font-black py-4 rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(229,9,20,0.4)] disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center gap-2"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "ENTRAR"}
        </button>
      </form>
    </AuthShell>
  )
}
