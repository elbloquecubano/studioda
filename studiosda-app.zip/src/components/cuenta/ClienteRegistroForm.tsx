"use client"

import { useState } from "react"
import Link from "next/link"
import { UserPlus, Lock, User as UserIcon, Phone, Smile, Loader2, MapPin } from "lucide-react"
import AuthShell from "./AuthShell"
import AuthField from "./AuthField"

export default function ClienteRegistroForm() {
  const [username, setUsername] = useState("")
  const [displayName, setDisplayName] = useState("")
  const [phone, setPhone] = useState("")
  const [address, setAddress] = useState("")
  const [password, setPassword] = useState("")
  const [confirm, setConfirm] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    // Se comprueba aquí para no gastar un intento del límite del servidor en
    // un error que la persona puede corregir al momento.
    if (password !== confirm) {
      setError("Las contraseñas no coinciden")
      return
    }

    setLoading(true)

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password, displayName, phone, address }),
      })

      const data = await res.json().catch(() => ({}))

      if (!res.ok) {
        setError(data.error || "No se pudo crear la cuenta")
        setLoading(false)
        return
      }

      window.location.href = "/mi-cuenta"
    } catch {
      setError("Error de conexión con el servidor")
      setLoading(false)
    }
  }

  return (
    <AuthShell
      icon={UserPlus}
      title="CREAR"
      highlight="CUENTA"
      subtitle="Solo necesitas un usuario y una contraseña"
      footer={
        <>
          ¿Ya tienes cuenta?{" "}
          <Link href="/cuenta/login" className="text-accent font-bold hover:underline">
            Entra aquí
          </Link>
        </>
      }
    >
      <form onSubmit={handleSubmit} className="space-y-5">
        <AuthField
          icon={UserIcon}
          label="Usuario"
          value={username}
          onChange={setUsername}
          placeholder="Como quieres que te llamemos"
          autoComplete="username"
          hint="Entre 3 y 20 caracteres: letras, números, punto, guion o guion bajo"
          required
        />

        <AuthField
          icon={Smile}
          label="Nombre (opcional)"
          value={displayName}
          onChange={setDisplayName}
          placeholder="Tu nombre"
          autoComplete="name"
        />

        <AuthField
          icon={Phone}
          label="Teléfono o WhatsApp (opcional)"
          value={phone}
          onChange={setPhone}
          placeholder="Para avisarte cuando esté listo"
          autoComplete="tel"
        />

        <AuthField
          icon={MapPin}
          label="Dirección (opcional)"
          value={address}
          onChange={setAddress}
          placeholder="Calle, número, entre calles, reparto y municipio"
          autoComplete="street-address"
          hint="Para llevarte el pedido a domicilio. Puedes añadirla o cambiarla después desde tu perfil."
          multiline
          maxLength={200}
        />

        <AuthField
          icon={Lock}
          label="Contraseña"
          type="password"
          value={password}
          onChange={setPassword}
          placeholder="••••••••"
          autoComplete="new-password"
          hint="Mínimo 8 caracteres"
          required
        />

        <AuthField
          icon={Lock}
          label="Repite la contraseña"
          type="password"
          value={confirm}
          onChange={setConfirm}
          placeholder="••••••••"
          autoComplete="new-password"
          required
        />

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-500 text-sm py-3 px-4 rounded-xl text-center">
            {error}
          </div>
        )}

        <div className="bg-white/5 border border-white/10 rounded-xl p-3 text-[11px] text-muted leading-relaxed">
          No pedimos correo, así que <strong className="text-foreground/80">guarda bien tu contraseña</strong>:
          si la olvidas habrá que restablecerla en la tienda.
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-accent text-black font-black py-4 rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(229,9,20,0.4)] disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center gap-2"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "CREAR MI CUENTA"}
        </button>
      </form>
    </AuthShell>
  )
}
