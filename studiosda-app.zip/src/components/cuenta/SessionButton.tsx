"use client"

import Link from "next/link"
import useSWR from "swr"
import { usePathname } from "next/navigation"
import { UserCircle2, LogIn } from "lucide-react"

interface MeResponse {
  user: { username: string; displayName: string | null; role: string } | null
}

const fetcher = (url: string) => fetch(url).then((res) => res.json())

/**
 * Punto de entrada a la cuenta en la barra superior.
 *
 * Se resuelve en el cliente a propósito: el resto de la barra es estático y
 * cacheable, y hacerla depender de la sesión obligaría a renderizar en cada
 * petición todas las páginas del catálogo.
 */
export default function SessionButton({ compact = false }: { compact?: boolean }) {
  const pathname = usePathname()

  const { data } = useSWR<MeResponse>("/api/auth/me", fetcher, {
    // Al volver a la pestaña tras entrar o salir en otra, el estado se corrige.
    revalidateOnFocus: true,
    // Revalida al navegar, para que la barra no siga diciendo "Entrar"
    // justo después de iniciar sesión.
    keepPreviousData: true,
  })

  const user = data?.user

  if (user) {
    const name = user.displayName || user.username

    return (
      <Link
        href="/mi-cuenta"
        className={
          compact
            ? "flex items-center gap-3 py-3 text-sm font-semibold text-foreground/80 hover:text-accent transition-colors"
            : "flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-colors max-w-[10rem]"
        }
        title="Mi cuenta"
      >
        <UserCircle2 className="w-5 h-5 text-accent shrink-0" />
        <span className="text-sm font-semibold truncate">{name}</span>
      </Link>
    )
  }

  return (
    <Link
      href={`/cuenta/login?next=${encodeURIComponent(pathname)}`}
      className={
        compact
          ? "flex items-center gap-3 py-3 text-sm font-semibold text-foreground/80 hover:text-accent transition-colors"
          : "flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
      }
      title="Iniciar sesión"
    >
      <LogIn className="w-4 h-4 text-accent shrink-0" />
      <span className="text-sm font-semibold whitespace-nowrap">Entrar</span>
    </Link>
  )
}
