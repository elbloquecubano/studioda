import type { LucideIcon } from "lucide-react"

interface AuthFieldProps {
  icon: LucideIcon
  label: string
  type?: string
  value: string
  onChange: (value: string) => void
  placeholder?: string
  required?: boolean
  autoComplete?: string
  hint?: string
  /** Convierte el campo en un textarea. Para direcciones, que ocupan varias líneas. */
  multiline?: boolean
  maxLength?: number
}

/** Campo con icono, el mismo patrón visual que usa el formulario del admin. */
export default function AuthField({
  icon: Icon,
  label,
  type = "text",
  value,
  onChange,
  placeholder,
  required,
  autoComplete,
  hint,
  multiline,
  maxLength,
}: AuthFieldProps) {
  // El icono se centra en la línea única, pero en un textarea tiene que
  // quedarse arriba o flotaría en mitad del texto.
  const iconPosition = multiline ? "top-4" : "top-1/2 -translate-y-1/2"

  const fieldClasses =
    "w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-accent/50 focus:bg-white/10 transition-all"

  return (
    <div className="space-y-2">
      <label className="text-xs font-bold uppercase tracking-widest text-muted px-1 block">
        {label}
      </label>
      <div className="relative">
        <Icon className={`absolute left-4 ${iconPosition} w-5 h-5 text-muted`} />
        {multiline ? (
          <textarea
            required={required}
            value={value}
            rows={3}
            maxLength={maxLength}
            autoComplete={autoComplete}
            onChange={(e) => onChange(e.target.value)}
            className={`${fieldClasses} resize-y min-h-[7rem]`}
            placeholder={placeholder}
          />
        ) : (
          <input
            type={type}
            required={required}
            value={value}
            maxLength={maxLength}
            autoComplete={autoComplete}
            onChange={(e) => onChange(e.target.value)}
            className={fieldClasses}
            placeholder={placeholder}
          />
        )}
      </div>
      {hint && <p className="text-[11px] text-muted px-1">{hint}</p>}
    </div>
  )
}
