"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { LayoutDashboard, User as UserIcon, ShoppingBag, LogOut } from "lucide-react"
import { cn } from "@/lib/utils"

/**
 * Añadir una sección al dashboard es añadir una entrada aquí.
 *
 * A diferencia de AdminSidebar, el markup del nav no está duplicado entre
 * escritorio y móvil: es una sola lista que pasa de fila a columna, así que no
 * hay dos sitios que mantener sincronizados.
 */
const menuItems = [
  { label: "Resumen", href: "/mi-cuenta", icon: LayoutDashboard },
  { label: "Mi perfil", href: "/mi-cuenta/perfil", icon: UserIcon },
  { label: "Mis pedidos", href: "/mi-cuenta/pedidos", icon: ShoppingBag },
]

interface CuentaSidebarProps {
  displayName: string
}

export default function CuentaSidebar({ displayName }: CuentaSidebarProps) {
  const pathname = usePathname()

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" })
    window.location.href = "/"
  }

  return (
    <aside className="lg:w-64 lg:shrink-0">
      <div className="lg:sticky lg:top-24 space-y-6">
        <div className="hidden lg:block px-2">
          <p className="text-xs font-bold uppercase tracking-widest text-muted">Hola</p>
          <p className="text-lg font-bold truncate">{displayName}</p>
        </div>

        <nav
          className={cn(
            "flex gap-2 overflow-x-auto admin-scroll-area pb-2",
            "lg:flex-col lg:overflow-visible lg:pb-0"
          )}
        >
          {menuItems.map((item) => {
            const Icon = item.icon
            const active = pathname === item.href

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all whitespace-nowrap text-sm",
                  active
                    ? "bg-accent text-black font-bold shadow-[0_0_15px_rgba(229,9,20,0.3)]"
                    : "text-muted hover:bg-white/5 hover:text-foreground"
                )}
              >
                <Icon className="w-4 h-4 shrink-0" />
                {item.label}
              </Link>
            )
          })}

          <button
            onClick={logout}
            className="flex items-center gap-3 px-4 py-3 rounded-xl text-muted hover:bg-red-500/10 hover:text-red-500 transition-all whitespace-nowrap text-sm lg:mt-4"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            Cerrar sesión
          </button>
        </nav>
      </div>
    </aside>
  )
}
