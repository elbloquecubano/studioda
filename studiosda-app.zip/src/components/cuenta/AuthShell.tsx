import Link from "next/link"
import type { LucideIcon } from "lucide-react"

interface AuthShellProps {
  icon: LucideIcon
  title: string
  highlight: string
  subtitle: string
  children: React.ReactNode
  footer: React.ReactNode
}

/**
 * Marco compartido por las pantallas de entrar y registrarse.
 * Reproduce el panel de AdminLoginForm para que las dos zonas se sientan
 * parte de lo mismo, pero con textos de cliente.
 */
export default function AuthShell({
  icon: Icon,
  title,
  highlight,
  subtitle,
  children,
  footer,
}: AuthShellProps) {
  return (
    <div className="glass p-8 rounded-3xl border border-white/10 w-full max-w-md">
      <div className="flex flex-col items-center gap-4 mb-8 text-center">
        <div className="w-16 h-16 bg-accent rounded-2xl flex items-center justify-center shadow-[0_0_30px_rgba(229,9,20,0.3)]">
          <Icon className="text-black w-8 h-8" />
        </div>
        <h1 className="text-3xl font-black tracking-tighter">
          {title} <span className="text-accent">{highlight}</span>
        </h1>
        <p className="text-muted text-sm">{subtitle}</p>
      </div>

      {children}

      <div className="mt-6 text-center text-sm text-muted">{footer}</div>

      <div className="mt-4 text-center">
        <Link href="/" className="text-xs text-muted hover:text-foreground transition-colors">
          Volver al catálogo
        </Link>
      </div>
    </div>
  )
}
