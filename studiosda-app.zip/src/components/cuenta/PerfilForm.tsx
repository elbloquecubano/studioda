"use client"

import { useState } from "react"
import { Phone, Smile, Lock, Loader2, MapPin } from "lucide-react"
import { useToast } from "@/components/ui/Toast"
import AuthField from "./AuthField"

interface PerfilFormProps {
  username: string
  displayName: string
  phone: string
  address: string
}

export default function PerfilForm({ username, displayName, phone, address }: PerfilFormProps) {
  const { toast } = useToast()

  const [name, setName] = useState(displayName)
  const [tel, setTel] = useState(phone)
  const [dir, setDir] = useState(address)
  const [savingProfile, setSavingProfile] = useState(false)

  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirm, setConfirm] = useState("")
  const [savingPassword, setSavingPassword] = useState(false)

  const saveProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    setSavingProfile(true)

    try {
      const res = await fetch("/api/me/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ displayName: name, phone: tel, address: dir }),
      })
      const data = await res.json().catch(() => ({}))

      if (res.ok) {
        toast("Perfil actualizado", "success")
      } else {
        toast(data.error || "No se pudo guardar", "error")
      }
    } catch {
      toast("Error de conexión con el servidor", "error")
    } finally {
      setSavingProfile(false)
    }
  }

  const savePassword = async (e: React.FormEvent) => {
    e.preventDefault()

    if (newPassword !== confirm) {
      toast("Las contraseñas nuevas no coinciden", "error")
      return
    }

    setSavingPassword(true)

    try {
      const res = await fetch("/api/me/password", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      })
      const data = await res.json().catch(() => ({}))

      if (res.ok) {
        toast("Contraseña cambiada. Se cerraron las sesiones de otros dispositivos.", "success")
        setCurrentPassword("")
        setNewPassword("")
        setConfirm("")
      } else {
        toast(data.error || "No se pudo cambiar la contraseña", "error")
      }
    } catch {
      toast("Error de conexión con el servidor", "error")
    } finally {
      setSavingPassword(false)
    }
  }

  return (
    <div className="space-y-6">
      <form onSubmit={saveProfile} className="glass rounded-3xl p-6 md:p-8 border border-white/5 space-y-5">
        <h2 className="text-xl font-bold">Datos de contacto</h2>

        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-widest text-muted px-1 block">
            Usuario
          </label>
          <div className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-4 text-muted">
            {username}
          </div>
          <p className="text-[11px] text-muted px-1">El nombre de usuario no se puede cambiar.</p>
        </div>

        <AuthField icon={Smile} label="Nombre" value={name} onChange={setName} placeholder="Tu nombre" />

        <AuthField
          icon={Phone}
          label="Teléfono o WhatsApp"
          value={tel}
          onChange={setTel}
          placeholder="Para avisarte cuando esté listo"
        />

        <AuthField
          icon={MapPin}
          label="Dirección"
          value={dir}
          onChange={setDir}
          placeholder="Calle, número, entre calles, reparto y municipio"
          autoComplete="street-address"
          hint="Se usa para llevarte el pedido a domicilio."
          multiline
          maxLength={200}
        />

        <button
          type="submit"
          disabled={savingProfile}
          className="bg-accent text-black font-bold px-6 py-3 rounded-xl hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 disabled:hover:scale-100 flex items-center gap-2"
        >
          {savingProfile && <Loader2 className="w-4 h-4 animate-spin" />}
          Guardar cambios
        </button>
      </form>

      <form onSubmit={savePassword} className="glass rounded-3xl p-6 md:p-8 border border-white/5 space-y-5">
        <h2 className="text-xl font-bold">Cambiar contraseña</h2>

        <AuthField
          icon={Lock}
          label="Contraseña actual"
          type="password"
          value={currentPassword}
          onChange={setCurrentPassword}
          autoComplete="current-password"
          required
        />

        <AuthField
          icon={Lock}
          label="Contraseña nueva"
          type="password"
          value={newPassword}
          onChange={setNewPassword}
          autoComplete="new-password"
          hint="Mínimo 8 caracteres"
          required
        />

        <AuthField
          icon={Lock}
          label="Repite la contraseña nueva"
          type="password"
          value={confirm}
          onChange={setConfirm}
          autoComplete="new-password"
          required
        />

        <button
          type="submit"
          disabled={savingPassword}
          className="bg-white/5 border border-white/10 font-bold px-6 py-3 rounded-xl hover:bg-white/10 transition-all disabled:opacity-50 flex items-center gap-2"
        >
          {savingPassword && <Loader2 className="w-4 h-4 animate-spin" />}
          Cambiar contraseña
        </button>
      </form>
    </div>
  )
}
