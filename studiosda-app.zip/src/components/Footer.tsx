import { Film } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-background border-t border-white/5 py-12 px-6 md:px-12 mt-auto" role="contentinfo">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <Film className="text-accent w-5 h-5" aria-hidden="true" />
            <span className="text-xl font-bold tracking-tighter">
              Studios <span className="text-accent">D-A</span>
            </span>
          </div>
          <p className="text-muted text-sm max-w-xs">
            El mejor catálogo audiovisual local para Cuba. Calidad y velocidad garantizada sin internet.
          </p>
        </div>

          <div className="flex gap-10 flex-wrap justify-center md:justify-end items-start">
          <div className="flex flex-col gap-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-accent">Navegación</h4>
            <div className="flex gap-8">
              <ul className="text-sm text-muted space-y-2">
                <li><a href="/" className="hover:text-foreground transition-colors">Inicio</a></li>
                <li><a href="/?type=Movie" className="hover:text-foreground transition-colors">Películas</a></li>
                <li><a href="/?type=Series" className="hover:text-foreground transition-colors">Series</a></li>
                <li><a href="/?type=Dorama" className="hover:text-foreground transition-colors">Doramas</a></li>
                <li><a href="/?type=Reality" className="hover:text-foreground transition-colors">Realitys</a></li>
              </ul>
              <ul className="text-sm text-muted space-y-2">
                <li><a href="/?type=Anime" className="hover:text-foreground transition-colors">Animes</a></li>
                <li><a href="/?type=Dongchua" className="hover:text-foreground transition-colors">Dongchua</a></li>
                <li><a href="/?type=Deportes" className="hover:text-foreground transition-colors">Deportes</a></li>
                <li><a href="/?type=Animated_Series" className="hover:text-foreground transition-colors">Animados (Series)</a></li>
                <li><a href="/?type=Animated_Movie" className="hover:text-foreground transition-colors">Animados (Filmes)</a></li>
              </ul>
            </div>
          </div>
          <div className="flex flex-col gap-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-accent">Novelas</h4>
            <div className="flex gap-8">
              <ul className="text-sm text-muted space-y-2">
                <li><a href="/?type=Novela" className="hover:text-foreground transition-colors">Todas</a></li>
                <li><a href="/?type=Novela_Brasil" className="hover:text-foreground transition-colors">Brasileñas</a></li>
                <li><a href="/?type=Novela_Colombia" className="hover:text-foreground transition-colors">Colombianas</a></li>
                <li><a href="/?type=Novela_Turca" className="hover:text-foreground transition-colors">Turcas</a></li>
              </ul>
              <ul className="text-sm text-muted space-y-2">
                <li><a href="/?type=Novela_Mexicana" className="hover:text-foreground transition-colors">Mexicanas</a></li>
                <li><a href="/?type=Novela_Cristiana" className="hover:text-foreground transition-colors">Cristianas</a></li>
                <li><a href="/?type=Novela_Otros" className="hover:text-foreground transition-colors">Otros Países</a></li>
              </ul>
            </div>
          </div>
          <div className="flex flex-col gap-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-accent">Videojuegos</h4>
            <div className="flex gap-8">
              <ul className="text-sm text-muted space-y-2">
                <li><a href="/?type=Game_PC" className="hover:text-foreground transition-colors">PC</a></li>
                <li><a href="/?type=Game_Mobile" className="hover:text-foreground transition-colors">Móvil</a></li>
                <li><a href="/?type=Game_PS1" className="hover:text-foreground transition-colors">PS1</a></li>
                <li><a href="/?type=Game_PS2" className="hover:text-foreground transition-colors">PS2</a></li>
                <li><a href="/?type=Game_PS3" className="hover:text-foreground transition-colors">PS3</a></li>
              </ul>
              <ul className="text-sm text-muted space-y-2">
                <li><a href="/?type=Game_PS4" className="hover:text-foreground transition-colors">PS4</a></li>
                <li><a href="/?type=Game_Switch" className="hover:text-foreground transition-colors">Switch</a></li>
                <li><a href="/?type=Game_PSP" className="hover:text-foreground transition-colors">PSP</a></li>
                <li><a href="/?type=Game_3DS" className="hover:text-foreground transition-colors">3DS</a></li>
                <li><a href="/?type=Game_Wii" className="hover:text-foreground transition-colors">Wii</a></li>
              </ul>
            </div>
          </div>
          <div className="flex flex-col gap-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-accent">Legal</h4>
            <ul className="text-sm text-muted space-y-2">
              <li><a href="#" className="hover:text-foreground transition-colors">Privacidad</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Términos</a></li>
            </ul>
          </div>
        </div>

        <div className="text-right text-xs text-muted">
          <p>© {new Date().getFullYear()} Studios D-A Cuba.</p>
          <p>Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
