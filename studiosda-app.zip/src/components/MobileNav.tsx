"use client";

import Link from "next/link";
import useSWR from "swr";
import { useCallback, useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import {
  ChevronDown,
  Home,
  LayoutGrid,
  LogIn,
  Search,
  Tags,
  UserCircle2,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { NAV_SECTIONS, useGenresByType } from "@/lib/nav";

/**
 * Navegación del catálogo en móvil: barra inferior fija y hojas emergentes.
 *
 * Sustituye al menú hamburguesa que estaba arriba a la derecha, la peor zona
 * para el pulgar en un teléfono alto. Además saca "Buscar" y "Cuenta" del
 * cajón: con 444 títulos, buscar es la acción más frecuente y estaba a dos
 * niveles de profundidad.
 *
 * Las once categorías no caben en una barra inferior (cinco es el máximo
 * razonable), así que siguen agrupadas: la diferencia es que ahora se abren
 * desde abajo en lugar de desde la esquina superior.
 */

interface MeResponse {
  user: { username: string; displayName: string | null; role: string } | null;
}

const fetcher = (url: string) => fetch(url).then((res) => res.json());

type Sheet = "none" | "categories" | "search";

export default function MobileNav() {
  const pathname = usePathname();
  const [sheet, setSheet] = useState<Sheet>("none");
  const [openSection, setOpenSection] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const genresByType = useGenresByType();

  // Misma clave que SessionButton: SWR reutiliza la respuesta en vez de
  // preguntar dos veces quién ha iniciado sesión.
  const { data } = useSWR<MeResponse>("/api/auth/me", fetcher, {
    revalidateOnFocus: true,
    keepPreviousData: true,
  });
  const user = data?.user;

  const close = useCallback(() => setSheet("none"), []);

  useEffect(() => {
    if (sheet === "none") return;

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    document.addEventListener("keydown", onKeyDown);

    // Sin esto el catálogo de detrás se desplaza al arrastrar sobre la hoja.
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = previous;
    };
  }, [sheet, close]);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const term = query.trim();
    if (term) window.location.href = `/?search=${encodeURIComponent(term)}`;
  };

  const isHome = pathname === "/";
  const accountHref = user
    ? "/mi-cuenta"
    : `/cuenta/login?next=${encodeURIComponent(pathname)}`;

  return (
    <>
      {sheet !== "none" && (
        <div
          className="lg:hidden fixed inset-0 z-[60] bg-black/70 backdrop-blur-sm animate-[fade-in_150ms_ease-out]"
          onClick={close}
          aria-hidden="true"
        />
      )}

      {sheet === "categories" && (
        <SheetShell title="Categorías" onClose={close}>
          <nav className="flex flex-col pb-2">
            {NAV_SECTIONS.map((section) => {
              const Icon = section.icon;
              const isOpen = openSection === section.key;
              const genres = section.genreHref ? genresByType[section.key] ?? [] : [];

              return (
                <div key={section.key} className="border-b border-white/5">
                  <button
                    type="button"
                    onClick={() => setOpenSection(isOpen ? null : section.key)}
                    aria-expanded={isOpen}
                    className="w-full flex items-center justify-between py-3.5 text-[15px] font-semibold text-foreground/80 active:text-accent transition-colors"
                  >
                    <span className="flex items-center gap-3">
                      <Icon className="w-[18px] h-[18px] text-accent" />
                      {section.label}
                    </span>
                    <ChevronDown
                      className={cn(
                        "w-4 h-4 text-muted transition-transform duration-300",
                        isOpen && "rotate-180"
                      )}
                    />
                  </button>

                  {isOpen && (
                    // La navegación de Next es del lado del cliente y no
                    // desmonta esta hoja, así que cada enlace la cierra al
                    // pulsarse; si no, quedaría abierta sobre la página nueva.
                    <div className="pl-8 pb-3 flex flex-col" onClick={close}>
                      <Link
                        href={section.allHref}
                        className="text-sm font-semibold text-accent py-2 flex items-center gap-2"
                      >
                        <Icon className="w-3.5 h-3.5" />
                        {section.allLabel}
                      </Link>

                      {section.staticItems
                        ?.filter((item) => item.href !== section.allHref)
                        .map((item) => (
                          <Link
                            key={item.href}
                            href={item.href}
                            className="text-sm text-foreground/60 py-2 flex items-center gap-2"
                          >
                            <Icon className="w-3.5 h-3.5 opacity-60" />
                            {item.label}
                          </Link>
                        ))}

                      {genres.map((genre) => (
                        <Link
                          key={genre}
                          href={section.genreHref!(genre)}
                          className="text-sm text-foreground/60 py-2 flex items-center gap-2"
                        >
                          <Tags className="w-3.5 h-3.5 opacity-60" />
                          {genre}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </nav>
        </SheetShell>
      )}

      {sheet === "search" && (
        <SheetShell title="Buscar" onClose={close}>
          <form onSubmit={submitSearch} className="pb-4 pt-1">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-[18px] h-[18px] text-muted" />
              <input
                type="search"
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Título de película, serie, juego..."
                aria-label="Buscar en el catálogo"
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-3.5 pl-12 pr-4 text-base focus:outline-none focus:ring-2 focus:ring-accent/50 focus:bg-white/10 transition-all"
              />
            </div>
            <button
              type="submit"
              disabled={!query.trim()}
              className="mt-3 w-full bg-accent text-black font-bold py-3.5 rounded-2xl active:scale-[0.98] transition-transform disabled:opacity-40"
            >
              Buscar
            </button>
          </form>
        </SheetShell>
      )}

      {/* Barra inferior */}
      <nav
        className="lg:hidden fixed bottom-0 left-0 right-0 z-[70] glass border-t border-white/10 pb-[env(safe-area-inset-bottom)]"
        aria-label="Navegación principal"
      >
        <div className="flex items-stretch justify-around h-16">
          <TabLink
            href="/"
            icon={Home}
            label="Inicio"
            active={isHome && sheet === "none"}
            onClick={close}
          />
          <TabButton
            icon={Search}
            label="Buscar"
            active={sheet === "search"}
            onClick={() => setSheet(sheet === "search" ? "none" : "search")}
          />
          <TabButton
            icon={LayoutGrid}
            label="Categorías"
            active={sheet === "categories"}
            onClick={() => setSheet(sheet === "categories" ? "none" : "categories")}
          />
          <TabLink
            href={accountHref}
            icon={user ? UserCircle2 : LogIn}
            label={user ? "Cuenta" : "Entrar"}
            active={pathname.startsWith("/mi-cuenta") && sheet === "none"}
            onClick={close}
          />
        </div>
      </nav>
    </>
  );
}

/** Panel deslizante anclado abajo, por encima de la barra de pestañas. */
function SheetShell({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={title}
      className="lg:hidden fixed inset-x-0 bottom-0 z-[65] glass rounded-t-3xl border-t border-white/10 shadow-2xl animate-[slide-up_220ms_cubic-bezier(0.32,0.72,0,1)] flex flex-col max-h-[78svh] pb-[calc(4rem+env(safe-area-inset-bottom))]"
    >
      <div className="flex items-center justify-between px-5 pt-3 pb-2 shrink-0">
        <div className="absolute left-1/2 -translate-x-1/2 top-2 w-10 h-1 rounded-full bg-white/20" aria-hidden="true" />
        <h2 className="text-base font-bold tracking-tight mt-2">{title}</h2>
        <button
          type="button"
          onClick={onClose}
          aria-label="Cerrar"
          className="mt-2 p-1.5 -mr-1.5 rounded-full text-muted active:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="overflow-y-auto overscroll-contain px-5 admin-scroll-area">
        {children}
      </div>
    </div>
  );
}

const tabClass = (active: boolean) =>
  cn(
    "flex-1 flex flex-col items-center justify-center gap-1 text-[10px] font-semibold tracking-wide transition-colors",
    active ? "text-accent" : "text-foreground/55"
  );

function TabLink({
  href,
  icon: Icon,
  label,
  active,
  onClick,
}: {
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <Link
      href={href}
      onClick={onClick}
      className={tabClass(active)}
      aria-current={active ? "page" : undefined}
    >
      <Icon className="w-[22px] h-[22px]" />
      {label}
    </Link>
  );
}

function TabButton({
  icon: Icon,
  label,
  active,
  onClick,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button type="button" onClick={onClick} className={tabClass(active)} aria-expanded={active}>
      <Icon className="w-[22px] h-[22px]" />
      {label}
    </button>
  );
}
