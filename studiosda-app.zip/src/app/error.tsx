"use client"

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-4">
      <h1 className="text-6xl font-black text-accent mb-4">Error</h1>
      <h2 className="text-xl font-bold mb-2">Algo salió mal</h2>
      <p className="text-muted text-sm mb-8 max-w-md">
        Ocurrió un error inesperado. Por favor, intenta de nuevo.
      </p>
      <button
        onClick={reset}
        className="bg-accent text-black font-bold px-8 py-3 rounded-xl hover:scale-105 transition-transform shadow-[0_0_20px_rgba(229,9,20,0.4)]"
      >
        Intentar de Nuevo
      </button>
    </div>
  )
}
