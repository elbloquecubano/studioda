import Link from "next/link"

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-4">
      <h1 className="text-8xl font-black text-accent mb-4">404</h1>
      <h2 className="text-2xl font-bold mb-2">Página no encontrada</h2>
      <p className="text-muted text-sm mb-8 max-w-md">
        La página que buscas no existe o fue movida. Vuelve al catálogo para encontrar contenido.
      </p>
      <Link
        href="/"
        className="bg-accent text-black font-bold px-8 py-3 rounded-xl hover:scale-105 transition-transform shadow-[0_0_20px_rgba(229,9,20,0.4)]"
      >
        Volver al Catálogo
      </Link>
    </div>
  )
}
