import { NextResponse } from 'next/server';
import { requireAdmin } from "@/lib/auth";
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import https from 'https';
import http from 'http';

function fetchHtml(urlStr: string, maxSize = 1048576): Promise<string> {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(urlStr);
    const client = parsedUrl.protocol === 'https:' ? https : http;
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8'
      },
      timeout: 15000
    };

    const req = client.get(urlStr, options, (res) => {
      if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
         let redirUrl = res.headers.location;
         if (!redirUrl.startsWith('http')) redirUrl = parsedUrl.origin + redirUrl;
         return fetchHtml(redirUrl, maxSize).then(resolve).catch(reject);
      }
      let data = '';
      res.on('data', chunk => {
        if (data.length < maxSize) {
          data += chunk;
          if (data.length > maxSize) data = data.slice(0, maxSize);
        }
      });
      res.on('end', () => resolve(data));
    });

    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
  });
}

function downloadImageBuffer(urlStr: string): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(urlStr);
    const client = parsedUrl.protocol === 'https:' ? https : http;
    const options = {
      headers: { 'User-Agent': 'Mozilla/5.0' },
      timeout: 15000
    }
    const req = client.get(urlStr, options, (res) => {
      if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
         let redirUrl = res.headers.location;
         if (!redirUrl.startsWith('http')) redirUrl = parsedUrl.origin + redirUrl;
         return downloadImageBuffer(redirUrl).then(resolve).catch(reject);
      }
      const data: Buffer[] = [];
      res.on('data', chunk => data.push(chunk));
      res.on('end', () => resolve(Buffer.concat(data)));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
  });
}

async function downloadImage(url: string): Promise<string | null> {
  if (!url || !url.startsWith('http')) return url.startsWith('/') ? url : null;
  try {
    const buffer = await downloadImageBuffer(url);
    let ext = url.split('.').pop()?.split('?')[0] || 'jpg';
    if (!['jpg', 'jpeg', 'png', 'webp', 'avif'].includes(ext.toLowerCase())) ext = 'jpg';
    const fileName = `${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext}`;
    const uploadsDir = path.join(process.cwd(), 'public', 'uploads');
    if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
    fs.writeFileSync(path.join(uploadsDir, fileName), buffer);
    return `/uploads/${fileName}`;
  } catch {
    return null;
  }
}

export async function POST(request: Request) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const { url } = await request.json();

    if (!url) {
      return NextResponse.json({ error: 'URL es requerida' }, { status: 400 });
    }

    const html = await fetchHtml(url);

    const getMetaContent = (nameOrProperty: string) => {
      const regex = new RegExp(`<meta[^>]+(?:name|property)=["']${nameOrProperty}["'][^>]+content=(["'])(.*?)\\1`, 'i');
      const match = html.match(regex);
      if (match) return match[2];
      const regexRev = new RegExp(`<meta[^>]+content=(["'])(.*?)\\1[^>]+(?:name|property)=["']${nameOrProperty}["']`, 'i');
      const matchRev = html.match(regexRev);
      return matchRev ? matchRev[2] : null;
    };

    // Title
    let title = getMetaContent('og:title') || '';
    if (!title) {
      const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
      title = titleMatch ? titleMatch[1] : '';
    }

    if (!title || /Just a moment|Attention Required|Access Denied|Cloudflare/i.test(title)) {
      // Even when blocked, detect type from URL so the form can auto-select it
      let blockedType = "Movie";
      const bu = url.toLowerCase();
      if (bu.includes('/tv/') || bu.includes('/series/') || bu.includes('/serie/')) {
        blockedType = "Series";
      } else if (bu.includes('/anime') || bu.includes('myanimelist') || bu.includes('animeflv') || bu.includes('crunchyroll')) {
        blockedType = "Anime";
      } else if (bu.includes('/novela') || bu.includes('novelas') || bu.includes('telemundo')) {
        blockedType = "Novela";
      } else if (bu.includes('steampowered') || bu.includes('store.epicgames') || bu.includes('gog.com') || bu.includes('/game/') || bu.includes('/juego/')) {
        blockedType = "Game_PC";
      } else if (bu.includes('/donghua') || bu.includes('/dongchua')) {
        blockedType = "Dongchua";
      } else if (bu.includes('/reality')) {
        blockedType = "Reality";
      } else if (bu.includes('/dorama') || bu.includes('/kdrama')) {
        blockedType = "Dorama";
      }
      return NextResponse.json({
        error: 'El sitio web bloqueó la extracción de datos. Prueba con themoviedb.org (TMDB) o Wikipedia.',
        type: blockedType,
      }, { status: 400 });
    }

    title = title.replace(/\s*[-–|]\s*(IMDb|FilmAffinity|The Movie Database|TMDB).*$/i, '')
                 .replace(/\s*\(\d{4}\).*$/i, '')
                 .trim();

    // Synopsis
    const synopsis = getMetaContent('og:description') || getMetaContent('description') || '';

    // Poster (og:image)
    let posterUrl = getMetaContent('og:image') || '';
    let posterPath = await downloadImage(posterUrl);

    // Backdrop / banner
    let backdropPath: string | null = null;

    // Strategy 1: Buscar backdrop_path en el raw JSON de __NEXT_DATA__ (sin parsear todo)
    const nextDataMatch = html.match(/<script id="__NEXT_DATA__"[^>]*type="application\/json"[^>]*>([\s\S]*?)<\/script>/i);
    if (nextDataMatch) {
      const rawJson = nextDataMatch[1];
      // Buscar "backdrop_path":"/ruta..." en el raw string (mucho más rápido que parsear)
      const bpMatch = rawJson.match(/"backdrop_path"\s*:\s*"([^"]+)"/);
      if (bpMatch) {
        const bp = bpMatch[1];
        const bUrl = bp.startsWith('http') ? bp : `https://image.tmdb.org/t/p/w1280${bp.startsWith('/') ? '' : '/'}${bp}`;
        backdropPath = await downloadImage(bUrl);
      }
    }

    // Strategy 2: data-backdrop attributes
    if (!backdropPath) {
      const backdropAttr = html.match(/data-backdrop-path=["']([^"']+)/i) ||
                           html.match(/data-backdrop-image=["']([^"']+)/i) ||
                           html.match(/data-backdrop=["']([^"']+)/i);
      if (backdropAttr) {
        const dbUrl = backdropAttr[1];
        if (dbUrl.startsWith('http')) {
          backdropPath = await downloadImage(dbUrl);
        } else if (dbUrl.startsWith('/')) {
          if (url.includes('themoviedb.org') || url.includes('tmdb.org')) {
            backdropPath = await downloadImage(`https://image.tmdb.org/t/p/w1280${dbUrl}`);
          } else {
            backdropPath = dbUrl;
          }
        }
      }
    }

    // Strategy 3: background-image inline style
    if (!backdropPath) {
      const bgMatch = html.match(/background-image:\s*url\(["']?([^"')]+)["']?\)/i);
      if (bgMatch) {
        const bgUrl = bgMatch[1];
        if (bgUrl !== posterUrl && bgUrl.startsWith('http')) {
          backdropPath = await downloadImage(bgUrl);
        }
      }
    }

    // Strategy 4: twitter:image / og:image:secure_url (si difieren del poster)
    if (!backdropPath) {
      const twitterImage = getMetaContent('twitter:image');
      const secureImage = getMetaContent('og:image:secure_url');
      if (twitterImage && twitterImage !== posterUrl) {
        backdropPath = await downloadImage(twitterImage);
      } else if (secureImage && secureImage !== posterUrl) {
        backdropPath = await downloadImage(secureImage);
      }
    }

    // Year
    let year = new Date().getFullYear();
    const specificYearMatch = html.match(/"(?:datePublished|releaseDate)"\s*:\s*"(\d{4})"/);
    if (specificYearMatch) {
      year = parseInt(specificYearMatch[1]);
    } else {
      // TMDB pattern: <span class="tag release_date">(2026)</span>
      const releaseDateMatch = html.match(/class=["'][^"']*\brelease_date\b[^"']*["'][^>]*>\((\d{4})\)</);
      if (releaseDateMatch) {
        year = parseInt(releaseDateMatch[1]);
      } else {
        // JSON-LD startDate: "startDate":"2026-05-13"
        const startDateMatch = html.match(/"startDate"\s*:\s*"(\d{4})/);
        if (startDateMatch) {
          year = parseInt(startDateMatch[1]);
        } else {
          const ogYearMatch = html.match(/(?:itemprop=["']datePublished["']|class=["']year["'])[^>]*>(\d{4})</);
          if (ogYearMatch) {
            year = parseInt(ogYearMatch[1]);
          } else {
            const yearNumbers = [...html.matchAll(/\b(19[5-9]\d|20[0-2]\d)\b/g)].map(m => parseInt(m[0]));
            if (yearNumbers.length > 0) {
              year = yearNumbers.sort((a, b) => b - a)[0];
            }
          }
        }
      }
    }

    // Type detection — priority: URL > JSON-LD > og:type > HTML signals
    let type = "Movie";
    const lowerHtml = html.toLowerCase();
    const u = url.toLowerCase();

    // 1. URL patterns (most reliable for known sites)
    if (u.includes('/anime') || u.includes('myanimelist') || u.includes('animeflv') || u.includes('crunchyroll')) {
      type = "Anime";
    } else if (u.includes('/novela') || u.includes('novelas') || u.includes('telemundo')) {
      type = "Novela";
    } else if (u.includes('steampowered') || u.includes('store.epicgames') || u.includes('gog.com') ||
               u.includes('/game/') || u.includes('/juego/')) {
      type = "Game_PC";
    } else if (u.includes('/tv/') || u.includes('/series/') || u.includes('/serie/') ||
               u.includes('/show/') || u.includes('/dorama') || u.includes('/kdrama')) {
      type = "Series";
    } else if (u.includes('/donghua') || u.includes('/dongchua')) {
      type = "Dongchua";
    } else if (u.includes('/reality')) {
      type = "Reality";
    } else if (u.includes('/deport') || u.includes('/sport')) {
      type = "Deportes";
    } else {
      // 2. JSON-LD @type (very reliable)
      const jsonLdTypeMatch = html.match(/"@type"\s*:\s*"(Movie|TVSeries|TVSeason|TVEpisode|VideoGame)/i);
      if (jsonLdTypeMatch) {
        const ldType = jsonLdTypeMatch[1].toLowerCase();
        if (ldType === 'tvseries' || ldType === 'tvseason' || ldType === 'tvepisode') {
          type = "Series";
        } else if (ldType === 'videogame') {
          type = "Game_PC";
        }
        // Movie is already the default
      } else {
        // 3. og:type meta tag (reliable)
        const ogType = getMetaContent('og:type')?.toLowerCase() || '';
        if (ogType.includes('tv_show') || ogType.includes('tvseries')) {
          type = "Series";
        } else if (ogType.includes('video_game')) {
          type = "Game_PC";
        }
        // og:type "video.movie" → stays as Movie (default)
      }
    }

    // Genre extraction from meta tags
    let genreString = "";
    const tagProps = ['og:video:tag', 'og:video:tags', 'article:tag', 'keywords'];
    const foundTags = new Set<string>();
    for (const prop of tagProps) {
      const content = getMetaContent(prop);
      if (content) {
        content.split(',').forEach(t => {
          const clean = t.trim();
          if (clean && !/^\d+$/.test(clean) && !/^[A-Za-z]$/.test(clean) &&
              !['imdb', 'movie', 'film', 'cinema', 'hd', 'full', 'watch', 'online'].includes(clean.toLowerCase())) {
            foundTags.add(clean);
          }
        });
      }
    }

    // Try to extract from JSON-LD
    const jsonLdMatch = html.match(/<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/i);
    if (jsonLdMatch) {
      try {
        let rawJson = jsonLdMatch[1].trim();
        // Strip CDATA markers if present (TMDB uses /* <![CDATA[ */ ... /* ]]> */)
        rawJson = rawJson.replace(/\/\*[\s]*<!\[CDATA\[[\s]*\*\//g, '').replace(/\/\*[\s]*\]\]>[\s]*\*\//g, '');
        const ld = JSON.parse(rawJson);
        const item = ld.itemListElement?.[0]?.item || ld;
        if (item.genre) {
          const genres = Array.isArray(item.genre) ? item.genre : [item.genre];
          genres.forEach((g: string) => foundTags.add(g));
        }
        if (item.keywords) {
          item.keywords.split(',').forEach((k: string) => {
            const clean = k.trim();
            if (clean) foundTags.add(clean);
          });
        }
      } catch {}
    }

    // Strategy: Extract from <span class="genres"> (TMDB and similar sites)
    if (foundTags.size === 0) {
      const genresSpanMatch = html.match(/<span[^>]*class=["'][^"']*\bgenres\b[^"']*["'][^>]*>([\s\S]*?)<\/span>/i);
      if (genresSpanMatch) {
        const genreHtml = genresSpanMatch[1];
        const linkMatches = genreHtml.matchAll(/<a[^>]*>([^<]+)<\/a>/gi);
        for (const m of linkMatches) {
          const g = m[1].trim();
          if (g) foundTags.add(g);
        }
      }
    }

    // Strategy: Extract from itemprop="genre" links
    if (foundTags.size === 0) {
      const itempropGenres = html.matchAll(/<a[^>]*itemprop=["']genre["'][^>]*>([^<]+)<\/a>/gi);
      for (const m of itempropGenres) {
        const g = m[1].trim();
        if (g) foundTags.add(g);
      }
    }

    if (foundTags.size > 0) {
      genreString = Array.from(foundTags).join(", ");
    }

    return NextResponse.json({
      title,
      year,
      synopsis,
      posterPath,
      backdropPath,
      type,
      genre: genreString,
    });
  } catch (error: any) {
    console.error("Scraping error:", error);
    return NextResponse.json({ error: error.message || 'Error durante el scraping' }, { status: 500 });
  }
}
