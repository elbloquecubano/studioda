import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  try {
    const type = request.nextUrl.searchParams.get("type");

    if (!type) {
      return NextResponse.json({ error: "type parameter required" }, { status: 400 });
    }

    const [media, genreRecords] = await Promise.all([
      prisma.media.findMany({
        where: { type },
        select: { genre: true },
      }),
      prisma.genre.findMany({
        where: { types: { contains: type } },
        select: { name: true },
      }),
    ]);

    const genres = new Set<string>();

    for (const m of media) {
      const parts = m.genre.split(",").map(g => g.trim()).filter(Boolean);
      for (const g of parts) {
        genres.add(g);
      }
    }

    for (const r of genreRecords) {
      genres.add(r.name);
    }

    const sorted = Array.from(genres).sort((a, b) => a.localeCompare(b));

    return NextResponse.json(sorted);
  } catch (error) {
    console.error("Error fetching genres by type:", error);
    return NextResponse.json({ error: "Error al obtener géneros" }, { status: 500 });
  }
}
