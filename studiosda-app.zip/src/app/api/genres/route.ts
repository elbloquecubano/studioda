import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { rateLimit, getClientIP } from "@/lib/rate-limit";
import { createGenreSlug, normalizeGenreName, parseGenreList } from "@/lib/genres";
import { Prisma } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

async function getUniqueGenreSlug(name: string) {
  const baseSlug = createGenreSlug(name) || "genero";
  let slug = baseSlug;
  let suffix = 2;

  while (await prisma.genre.findUnique({ where: { slug } })) {
    slug = `${baseSlug}-${suffix}`;
    suffix += 1;
  }

  return slug;
}

async function syncGenresFromMedia() {
  const [genres, catalog] = await Promise.all([
    prisma.genre.findMany({ select: { id: true, name: true, types: true } }),
    prisma.media.findMany({ select: { type: true, genre: true } }),
  ]);

  const genreTypeMap = new Map<string, Set<string>>();
  for (const g of genres) {
    const types = g.types.split(",").map(t => t.trim()).filter(Boolean);
    genreTypeMap.set(g.name, new Set(types));
  }

  for (const item of catalog) {
    const genreNames = parseGenreList(item.genre);
    for (const name of genreNames) {
      const types = genreTypeMap.get(name);
      if (types) {
        types.add(item.type);
      } else {
        genreTypeMap.set(name, new Set([item.type]));
      }
    }
  }

  const existingNames = new Set(genres.map((g) => g.name));
  const mediaGenreNames = Array.from(
    new Set(catalog.flatMap((item) => parseGenreList(item.genre)))
  );

  for (const name of mediaGenreNames) {
    const types = genreTypeMap.get(name);
    const typesStr = types ? Array.from(types).join(",") : "";
    if (!existingNames.has(name)) {
      try {
        await prisma.genre.create({
          data: {
            name,
            slug: await getUniqueGenreSlug(name),
            types: typesStr,
          },
        });
      } catch (error) {
        if (
          !(error instanceof Prisma.PrismaClientKnownRequestError) ||
          error.code !== "P2002"
        ) {
          throw error;
        }
      }
    }
  }

  for (const genre of genres) {
    const currentTypes = genre.types.split(",").map(t => t.trim()).filter(Boolean);
    const mediaTypes = genreTypeMap.get(genre.name);
    if (mediaTypes) {
      const allTypes = new Set([...currentTypes, ...mediaTypes]);
      const allTypesStr = Array.from(allTypes).join(",");
      if (allTypesStr !== genre.types) {
        await prisma.genre.update({
          where: { id: genre.id },
          data: { types: allTypesStr },
        });
      }
    }
  }
}

export async function POST(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const body = await request.json();
    const name = normalizeGenreName(String(body.name || ""));

    if (!name) {
      return NextResponse.json(
        { error: "El nombre del genero es obligatorio." },
        { status: 400 }
      );
    }

    if (name.includes(",")) {
      return NextResponse.json(
        { error: "El nombre del genero no puede incluir comas." },
        { status: 400 }
      );
    }

    const genre = await prisma.genre.create({
      data: {
        name,
        slug: await getUniqueGenreSlug(name),
      },
    });

    return NextResponse.json({ success: true, genre });
  } catch (error) {
    if (
      error instanceof Prisma.PrismaClientKnownRequestError &&
      error.code === "P2002"
    ) {
      return NextResponse.json(
        { error: "Ese genero ya existe." },
        { status: 409 }
      );
    }

    console.error("Error creating genre:", error);
    return NextResponse.json(
      { error: "Error al crear el genero." },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const ip = getClientIP(request);
    const blocked = rateLimit(`genres:${ip}`, 30, 60_000);
    if (blocked) return blocked;

    await syncGenresFromMedia();

    const genres = await prisma.genre.findMany({
      orderBy: { name: "asc" },
    });
    return NextResponse.json(genres);
  } catch (error) {
    console.error("Error fetching genres:", error);
    return NextResponse.json(
      { error: "Error al obtener los generos." },
      { status: 500 }
    );
  }
}