import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import {
  createGenreSlug,
  formatGenreList,
  normalizeGenreName,
  parseGenreList,
} from "@/lib/genres";
import { Prisma } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

async function getUniqueGenreSlug(name: string, currentGenreId: string) {
  const baseSlug = createGenreSlug(name) || "genero";
  let slug = baseSlug;
  let suffix = 2;

  while (true) {
    const existingGenre = await prisma.genre.findUnique({ where: { slug } });
    if (!existingGenre || existingGenre.id === currentGenreId) return slug;

    slug = `${baseSlug}-${suffix}`;
    suffix += 1;
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const { id } = await params;

    const genre = await prisma.genre.findUnique({
      where: { id },
    });

    if (!genre) {
      return NextResponse.json(
        { error: "Genero no encontrado." },
        { status: 404 }
      );
    }

    const catalog = await prisma.media.findMany({
      select: { genre: true },
    });
    const isInUse = catalog.some((item) =>
      parseGenreList(item.genre).includes(genre.name)
    );

    if (isInUse) {
      return NextResponse.json(
        { error: "No se puede eliminar un genero que esta en uso." },
        { status: 409 }
      );
    }

    await prisma.genre.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting genre:", error);
    return NextResponse.json(
      { error: "Error al eliminar el genero." },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const { id } = await params;
    const body = await request.json();
    const currentGenre = await prisma.genre.findUnique({
      where: { id },
    });

    if (!currentGenre) {
      return NextResponse.json(
        { error: "Genero no encontrado." },
        { status: 404 }
      );
    }

    const name = normalizeGenreName(String(body.name || ""));

    if (!name) {
      return NextResponse.json(
        { error: "El nombre del genero es obligatorio." },
        { status: 400 }
      );
    }

    if (name.includes(",")) {
      return NextResponse.json(
        { error: "El nombre del genero no puede incluir comas." },
        { status: 400 }
      );
    }

    const genre = await prisma.genre.update({
      where: { id },
      data: {
        name,
        slug: await getUniqueGenreSlug(name, id),
      },
    });

    if (currentGenre.name !== genre.name) {
      const catalog = await prisma.media.findMany({
        select: { id: true, genre: true },
      });
      const updates = catalog
        .map((item) => ({
          id: item.id,
          genres: parseGenreList(item.genre),
        }))
        .filter((item) => item.genres.includes(currentGenre.name))
        .map((item) =>
          prisma.media.update({
            where: { id: item.id },
            data: {
              genre: formatGenreList(
                item.genres.map((itemGenre) =>
                  itemGenre === currentGenre.name ? genre.name : itemGenre
                )
              ),
            },
          })
        );

      if (updates.length > 0) {
        await prisma.$transaction(updates);
      }
    }

    return NextResponse.json({ success: true, genre });
  } catch (error) {
    if (
      error instanceof Prisma.PrismaClientKnownRequestError &&
      error.code === "P2002"
    ) {
      return NextResponse.json(
        { error: "Ese genero ya existe." },
        { status: 409 }
      );
    }

    console.error("Error updating genre:", error);
    return NextResponse.json(
      { error: "Error al actualizar el genero." },
      { status: 500 }
    );
  }
}
