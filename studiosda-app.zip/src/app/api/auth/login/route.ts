import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { setSessionCookie } from "@/lib/auth";
import { normalizeUsername, verifyPassword, wastePasswordTime } from "@/lib/password";
import { checkLimit, getClientIP, resetLimit, tooManyRequests } from "@/lib/rate-limit";

/**
 * Inicio de sesión, para admin y para clientes.
 *
 * Protección contra fuerza bruta en tres capas, porque ninguna basta sola:
 *  1. Bloqueo por cuenta en base de datos. Es la única infalsificable (la IP
 *     se puede rotar mediante la cabecera X-Forwarded-For) y la única que
 *     sobrevive a un reinicio del servidor.
 *  2. Límite por IP, generoso: en la red de la tienda muchos clientes salen
 *     por la misma IP y no se les puede castigar en grupo.
 *  3. Cortacircuitos global del endpoint, para el ataque distribuido que
 *     evade las dos anteriores.
 */

const MAX_ATTEMPTS_BEFORE_LOCK = 5;
const BASE_LOCK_SECONDS = 60;
const MAX_LOCK_SECONDS = 15 * 60;

/** Mismo texto para usuario inexistente y contraseña incorrecta: distinguirlos permitiría averiguar qué cuentas existen. */
const GENERIC_ERROR = "Usuario o contraseña incorrectos";

function lockDurationSeconds(failedAttempts: number): number {
  const over = failedAttempts - MAX_ATTEMPTS_BEFORE_LOCK;
  if (over < 0) return 0;
  return Math.min(BASE_LOCK_SECONDS * 2 ** over, MAX_LOCK_SECONDS);
}

export async function POST(request: NextRequest) {
  const ip = getClientIP(request);

  const global = checkLimit("login:global", 100, 60_000);
  if (!global.ok) return tooManyRequests(global.retryAfter);

  const perIp = checkLimit(`login:ip:${ip}`, 20, 5 * 60_000);
  if (!perIp.ok) return tooManyRequests(perIp.retryAfter);

  let username: string;
  let password: string;

  try {
    const body = await request.json();
    username = normalizeUsername(body?.username);
    password = typeof body?.password === "string" ? body.password : "";
  } catch {
    return NextResponse.json({ error: "Petición inválida" }, { status: 400 });
  }

  if (!username || !password) {
    return NextResponse.json({ error: GENERIC_ERROR }, { status: 401 });
  }

  try {
    const user = await prisma.user.findUnique({ where: { username } });

    if (!user) {
      // Se consume tiempo equivalente a una verificación real: si respondiera
      // al instante, el tiempo de respuesta revelaría que la cuenta no existe.
      await wastePasswordTime(password);
      return NextResponse.json({ error: GENERIC_ERROR }, { status: 401 });
    }

    if (user.lockedUntil && user.lockedUntil > new Date()) {
      const retryAfter = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 1000);
      return tooManyRequests(retryAfter);
    }

    if (!user.isActive) {
      await wastePasswordTime(password);
      return NextResponse.json({ error: GENERIC_ERROR }, { status: 401 });
    }

    const valid = await verifyPassword(password, user.password);

    if (!valid) {
      const failedAttempts = user.failedAttempts + 1;
      const lockSeconds = lockDurationSeconds(failedAttempts);

      await prisma.user.update({
        where: { id: user.id },
        data: {
          failedAttempts,
          lockedUntil: lockSeconds > 0 ? new Date(Date.now() + lockSeconds * 1000) : null,
        },
      });

      return NextResponse.json({ error: GENERIC_ERROR }, { status: 401 });
    }

    if (user.failedAttempts > 0 || user.lockedUntil) {
      await prisma.user.update({
        where: { id: user.id },
        data: { failedAttempts: 0, lockedUntil: null },
      });
    }

    resetLimit(`login:ip:${ip}`);
    await setSessionCookie(user);

    return NextResponse.json({
      success: true,
      role: user.role,
      mustChangePassword: user.mustChangePassword,
    });
  } catch (error) {
    console.error("Error en login:", error);
    return NextResponse.json({ error: "Error en el servidor" }, { status: 500 });
  }
}
