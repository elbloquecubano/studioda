import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { setSessionCookie } from "@/lib/auth";
import {
  hashPassword,
  normalizeUsername,
  validatePassword,
  validateUsername,
} from "@/lib/password";
import { checkLimit, getClientIP, tooManyRequests } from "@/lib/rate-limit";

/** Registro de clientes del catálogo. Sin correo: usuario, contraseña y teléfono opcional. */
export async function POST(request: NextRequest) {
  // Permite cerrar el registro sin tener que desplegar código nuevo.
  if (process.env.ALLOW_REGISTRATION === "false") {
    return NextResponse.json(
      { error: "El registro de nuevas cuentas está cerrado" },
      { status: 403 }
    );
  }

  const ip = getClientIP(request);

  const global = checkLimit("register:global", 30, 60 * 60_000);
  if (!global.ok) return tooManyRequests(global.retryAfter);

  const perIp = checkLimit(`register:ip:${ip}`, 5, 60 * 60_000);
  if (!perIp.ok) return tooManyRequests(perIp.retryAfter);

  let username: string;
  let password: string;
  let displayName: string | null;
  let phone: string | null;
  let address: string | null;

  try {
    const body = await request.json();
    username = normalizeUsername(body?.username);
    password = typeof body?.password === "string" ? body.password : "";
    displayName = typeof body?.displayName === "string" ? body.displayName.trim() : "";
    phone = typeof body?.phone === "string" ? body.phone.trim() : "";
    address = typeof body?.address === "string" ? body.address.trim() : "";
    displayName = displayName || null;
    phone = phone || null;
    address = address || null;
  } catch {
    return NextResponse.json({ error: "Petición inválida" }, { status: 400 });
  }

  const usernameProblem = validateUsername(username);
  if (usernameProblem) {
    return NextResponse.json({ error: usernameProblem.message }, { status: 400 });
  }

  const passwordProblem = validatePassword(password);
  if (passwordProblem) {
    return NextResponse.json({ error: passwordProblem.message }, { status: 400 });
  }

  if (displayName && displayName.length > 60) {
    return NextResponse.json({ error: "El nombre es demasiado largo" }, { status: 400 });
  }

  if (phone && !/^[\d\s+()-]{6,20}$/.test(phone)) {
    return NextResponse.json({ error: "El teléfono no tiene un formato válido" }, { status: 400 });
  }

  if (address && address.length > 200) {
    return NextResponse.json({ error: "La dirección es demasiado larga" }, { status: 400 });
  }

  try {
    const existing = await prisma.user.findUnique({ where: { username } });
    if (existing) {
      return NextResponse.json({ error: "Ese usuario ya está registrado" }, { status: 409 });
    }

    const user = await prisma.user.create({
      data: {
        username,
        password: await hashPassword(password),
        displayName,
        phone,
        address,
        // El rol se fija aquí y nunca se lee del body: si viniera del cliente,
        // cualquiera podría registrarse como administrador.
        role: "CUSTOMER",
      },
    });

    await setSessionCookie(user);

    return NextResponse.json({ success: true, username: user.username });
  } catch (error) {
    console.error("Error en registro:", error);
    return NextResponse.json({ error: "Error en el servidor" }, { status: 500 });
  }
}
