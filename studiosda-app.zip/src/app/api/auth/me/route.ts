import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";

/**
 * Datos de la sesión actual. Devuelve `user: null` en vez de 401 porque lo
 * consultan componentes públicos (el Navbar) para decidir si mostrar
 * "Entrar" o el nombre de la persona.
 */
export async function GET() {
  const user = await getCurrentUser();

  return NextResponse.json(
    { user },
    // Sin esto, una respuesta cacheada podría enseñar la sesión de alguien a
    // otra persona desde el mismo navegador o proxy.
    { headers: { "Cache-Control": "no-store" } }
  );
}
