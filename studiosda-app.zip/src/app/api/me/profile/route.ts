import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth";

const NO_STORE = { "Cache-Control": "no-store" };

export async function GET() {
  const auth = await requireUser();
  if (auth instanceof NextResponse) return auth;

  return NextResponse.json(
    {
      username: auth.username,
      displayName: auth.displayName,
      phone: auth.phone,
      address: auth.address,
      role: auth.role,
    },
    { headers: NO_STORE }
  );
}

export async function PUT(request: NextRequest) {
  const auth = await requireUser();
  if (auth instanceof NextResponse) return auth;

  let displayName: string | null;
  let phone: string | null;
  let address: string | null;

  try {
    const body = await request.json();
    displayName = typeof body?.displayName === "string" ? body.displayName.trim() : "";
    phone = typeof body?.phone === "string" ? body.phone.trim() : "";
    address = typeof body?.address === "string" ? body.address.trim() : "";
    displayName = displayName || null;
    phone = phone || null;
    address = address || null;
  } catch {
    return NextResponse.json({ error: "Petición inválida" }, { status: 400 });
  }

  if (displayName && displayName.length > 60) {
    return NextResponse.json({ error: "El nombre es demasiado largo" }, { status: 400 });
  }

  if (phone && !/^[\d\s+()-]{6,20}$/.test(phone)) {
    return NextResponse.json({ error: "El teléfono no tiene un formato válido" }, { status: 400 });
  }

  if (address && address.length > 200) {
    return NextResponse.json({ error: "La dirección es demasiado larga" }, { status: 400 });
  }

  try {
    // Se actualiza por el id de la sesión, nunca por uno que venga del cliente:
    // así nadie puede editar el perfil de otra persona.
    const updated = await prisma.user.update({
      where: { id: auth.id },
      data: { displayName, phone, address },
      select: { username: true, displayName: true, phone: true, address: true },
    });

    return NextResponse.json(updated, { headers: NO_STORE });
  } catch (error) {
    console.error("Error al actualizar perfil:", error);
    return NextResponse.json({ error: "Error en el servidor" }, { status: 500 });
  }
}
