import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser, setSessionCookie } from "@/lib/auth";
import { hashPassword, validatePassword, verifyPassword } from "@/lib/password";
import { checkLimit, tooManyRequests } from "@/lib/rate-limit";

export async function PUT(request: NextRequest) {
  const auth = await requireUser();
  if (auth instanceof NextResponse) return auth;

  // Por cuenta, no por IP: quien está aquí ya tiene sesión, y lo que se evita
  // es adivinar la contraseña actual desde una sesión robada.
  const limit = checkLimit(`password:${auth.id}`, 10, 15 * 60_000);
  if (!limit.ok) return tooManyRequests(limit.retryAfter);

  let currentPassword: string;
  let newPassword: string;

  try {
    const body = await request.json();
    currentPassword = typeof body?.currentPassword === "string" ? body.currentPassword : "";
    newPassword = typeof body?.newPassword === "string" ? body.newPassword : "";
  } catch {
    return NextResponse.json({ error: "Petición inválida" }, { status: 400 });
  }

  const problem = validatePassword(newPassword);
  if (problem) {
    return NextResponse.json({ error: problem.message }, { status: 400 });
  }

  try {
    const user = await prisma.user.findUnique({ where: { id: auth.id } });
    if (!user) {
      return NextResponse.json({ error: "Debes iniciar sesión" }, { status: 401 });
    }

    // Se exige la contraseña actual para que una sesión robada no permita
    // apropiarse de la cuenta cambiándola.
    if (!(await verifyPassword(currentPassword, user.password))) {
      return NextResponse.json({ error: "La contraseña actual no es correcta" }, { status: 400 });
    }

    const updated = await prisma.user.update({
      where: { id: user.id },
      data: {
        password: await hashPassword(newPassword),
        // Invalida las sesiones abiertas en otros dispositivos.
        tokenVersion: { increment: 1 },
        mustChangePassword: false,
        failedAttempts: 0,
        lockedUntil: null,
      },
    });

    // Al subir tokenVersion la cookie actual queda obsoleta: se reemite para
    // que quien acaba de cambiarla no se quede fuera de su propia sesión.
    await setSessionCookie(updated);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error al cambiar contraseña:", error);
    return NextResponse.json({ error: "Error en el servidor" }, { status: 500 });
  }
}
