import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth";
import { checkLimit, tooManyRequests } from "@/lib/rate-limit";
import { getPriceForMedia } from "@/lib/pricing";

const NO_STORE = { "Cache-Control": "no-store" };

export async function GET() {
  const auth = await requireUser();
  if (auth instanceof NextResponse) return auth;

  const orders = await prisma.order.findMany({
    // Filtrado siempre por el id de la sesión, nunca por uno recibido del
    // cliente: es lo que impide leer los pedidos de otra persona.
    where: { userId: auth.id },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      mediaId: true,
      titleSnapshot: true,
      priceSnapshot: true,
      priceConfirmed: true,
      status: true,
      notes: true,
      createdAt: true,
    },
  });

  // El importe sin confirmar ni siquiera sale de aquí: si viajara al cliente
  // marcado como «pendiente», bastaría abrir la respuesta para verlo.
  const visible = orders.map((order) => ({
    ...order,
    priceSnapshot: order.priceConfirmed ? order.priceSnapshot : null,
  }));

  return NextResponse.json(visible, { headers: NO_STORE });
}

export async function POST(request: NextRequest) {
  const auth = await requireUser();
  if (auth instanceof NextResponse) return auth;

  const limit = checkLimit(`orders:${auth.id}`, 20, 60 * 60_000);
  if (!limit.ok) return tooManyRequests(limit.retryAfter);

  let mediaId: string | null;
  let notes: string | null;

  try {
    const body = await request.json();
    mediaId = typeof body?.mediaId === "string" ? body.mediaId : null;
    notes = typeof body?.notes === "string" ? body.notes.trim().slice(0, 300) : "";
    notes = notes || null;
  } catch {
    return NextResponse.json({ error: "Petición inválida" }, { status: 400 });
  }

  if (!mediaId) {
    return NextResponse.json({ error: "Falta el contenido a apartar" }, { status: 400 });
  }

  try {
    const media = await prisma.media.findUnique({
      where: { id: mediaId },
      select: { id: true, title: true, type: true, isAiring: true, fileSize: true },
    });

    if (!media) {
      return NextResponse.json({ error: "Ese contenido ya no está disponible" }, { status: 404 });
    }

    const existing = await prisma.order.findFirst({
      where: { userId: auth.id, mediaId: media.id, status: { in: ["PENDIENTE", "LISTO"] } },
      select: { id: true },
    });

    if (existing) {
      return NextResponse.json({ error: "Ya tienes ese título apartado" }, { status: 409 });
    }

    const order = await prisma.order.create({
      data: {
        userId: auth.id,
        mediaId: media.id,
        // Copia del título: si el admin borra el contenido, el pedido sigue
        // siendo legible en vez de quedar como una referencia rota.
        titleSnapshot: media.title,
        // Se congela el precio vigente al apartar, que es el que el cliente vio
        // en la ficha. Si mañana suben la tarifa, a él se le cobra ésta.
        priceSnapshot: await getPriceForMedia(media),
        notes,
      },
      select: { id: true, titleSnapshot: true, status: true, createdAt: true },
    });

    // Sin importe en la respuesta: el precio recién copiado es una propuesta
    // hasta que el admin la confirme desde el panel.
    return NextResponse.json(order, { status: 201, headers: NO_STORE });
  } catch (error) {
    console.error("Error al crear pedido:", error);
    return NextResponse.json({ error: "Error en el servidor" }, { status: 500 });
  }
}
