import { prisma } from "@/lib/prisma";
import { rateLimit, getClientIP } from "@/lib/rate-limit";
import { NextRequest, NextResponse } from "next/server";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const ip = getClientIP(request);
    const blocked = rateLimit(`interact:${ip}`, 60, 60_000);
    if (blocked) return blocked;

    const { id } = await params;
    const { action } = await request.json();

    if (!["like", "dislike", "unlike", "undislike"].includes(action)) {
      return NextResponse.json({ error: "Acción inválida" }, { status: 400 });
    }

    // Verificar que no baje de 0
    if (action === "unlike" || action === "undislike") {
      const current = await prisma.media.findUnique({
        where: { id },
        select: { likes: true, dislikes: true },
      });
      if (!current) {
        return NextResponse.json({ error: "Contenido no encontrado" }, { status: 404 });
      }
      if ((action === "unlike" && current.likes <= 0) || (action === "undislike" && current.dislikes <= 0)) {
        return NextResponse.json({ likes: current.likes, dislikes: current.dislikes });
      }
    }

    const field = action === "like" || action === "unlike" ? "likes" : "dislikes";
    const increment = action === "like" || action === "dislike" ? 1 : -1;

    const media = await prisma.media.update({
      where: { id },
      data: { [field]: { increment } },
    });

    return NextResponse.json({ likes: media.likes, dislikes: media.dislikes });
  } catch (error) {
    console.error("Interaction error:", error);
    return NextResponse.json({ error: "Error al registrar interacción" }, { status: 500 });
  }
}
