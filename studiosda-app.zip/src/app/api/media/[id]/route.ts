import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const { id } = await params;

    // Buscar el registro para obtener las rutas de las imágenes
    const media = await prisma.media.findUnique({
      where: { id },
    });

    if (!media) {
      return NextResponse.json(
        { error: "Contenido no encontrado." },
        { status: 404 }
      );
    }

    // Eliminar el registro de la base de datos
    await prisma.media.delete({
      where: { id },
    });

    // Intentar eliminar los archivos físicos si existen
    const deleteFile = (filePath: string) => {
      if (!filePath) return;
      const fullPath = path.join(process.cwd(), "public", filePath);
      if (fs.existsSync(fullPath)) {
        fs.unlinkSync(fullPath);
      }
    };

    deleteFile(media.posterPath);
    deleteFile(media.backdropPath);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error al eliminar media:", error);
    return NextResponse.json(
      { error: "Error al eliminar el contenido." },
      { status: 500 }
    );
  }
}

export async function PATCH(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
  ) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

    try {
      const { id } = await params;
      const body = await request.json();

      const data: Record<string, unknown> = {};
      if (body.title !== undefined) data.title = body.title;
      if (body.type !== undefined) data.type = body.type;
      if (body.year !== undefined) data.year = parseInt(body.year);
      if (body.genre !== undefined) data.genre = body.genre;
      if (body.synopsis !== undefined) data.synopsis = body.synopsis;
      if (body.review !== undefined) data.review = body.review;
      if (body.posterPath !== undefined) data.posterPath = body.posterPath;
      if (body.backdropPath !== undefined) data.backdropPath = body.backdropPath;
      if (body.isFeatured !== undefined) data.isFeatured = body.isFeatured;
      if (body.isAiring !== undefined) data.isAiring = body.isAiring;
      if (body.fileSize !== undefined) {
        data.fileSize = body.fileSize === "" || body.fileSize === null
          ? null
          : parseInt(body.fileSize);
      }

      const media = await prisma.media.update({
        where: { id },
        data,
      });

      return NextResponse.json({ success: true, media });
    } catch (error) {
      console.error("Error al actualizar media:", error);
      return NextResponse.json(
        { error: "Error al actualizar el contenido." },
        { status: 500 }
      );
    }
  }
