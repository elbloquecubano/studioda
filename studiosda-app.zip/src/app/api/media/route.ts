import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { rateLimit, getClientIP } from "@/lib/rate-limit";
import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const body = await request.json();
    const { title, type, year, genre, synopsis, review, posterPath, backdropPath, fileSize, isAiring } = body;

    const existing = await prisma.media.findFirst({
      where: {
        title: { contains: title },
        type,
      },
    });

    if (existing) {
      return NextResponse.json(
        { error: `Ya existe "${existing.title}" (${existing.type}) en el catálogo.` },
        { status: 409 }
      );
    }

    const media = await prisma.media.create({
      data: {
        title,
        type,
        year: parseInt(year),
        genre,
        synopsis,
        review: review || "",
        posterPath,
        backdropPath,
        isFeatured: false,
        isAiring: isAiring ?? false,
        fileSize: fileSize ? parseInt(fileSize) : null,
      },
    });

    return NextResponse.json({ success: true, media });
  } catch (error) {
    console.error("Error al crear media:", error);
    return NextResponse.json(
      { error: "Error al guardar en la base de datos." },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const ip = getClientIP(request);
    const blocked = rateLimit(`media:${ip}`, 30, 60_000);
    if (blocked) return blocked;

    const catalog = await prisma.media.findMany({
      orderBy: { createdAt: 'desc' }
    });
    return NextResponse.json(catalog);
  } catch (error) {
    return NextResponse.json(
      { error: "Error al obtener el catálogo." },
      { status: 500 }
    );
  }
}
