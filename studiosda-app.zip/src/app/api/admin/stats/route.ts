import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function GET() {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const [
      totalMedia,
      totalGenres,
      byType,
      allGenresRaw,
      byYear,
      airingCount,
      featuredCount,
      recentAdded,
    ] = await Promise.all([
      prisma.media.count(),
      prisma.genre.count(),
      prisma.media.groupBy({ by: ["type"], _count: true, orderBy: { _count: { type: "desc" } } }),
      prisma.media.findMany({ select: { genre: true } }),
      prisma.media.groupBy({ by: ["year"], _count: true, orderBy: { year: "desc" }, take: 10 }),
      prisma.media.count({ where: { isAiring: true } }),
      prisma.media.count({ where: { isFeatured: true } }),
      prisma.media.findMany({ select: { title: true, type: true, createdAt: true }, orderBy: { createdAt: "desc" }, take: 5 }),
    ]);

    // Process genres (comma-separated)
    const genreCounts: Record<string, number> = {};
    for (const m of allGenresRaw) {
      const genres = m.genre.split(",").map(g => g.trim()).filter(Boolean);
      for (const g of genres) {
        genreCounts[g] = (genreCounts[g] || 0) + 1;
      }
    }
    const topGenres = Object.entries(genreCounts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 15)
      .map(([name, count]) => ({ name, count }));

    // Process years
    const yearData = byYear.map(y => ({ year: y.year, count: y._count }));

    return NextResponse.json({
      totalMedia,
      totalGenres,
      byType: byType.map(t => ({ type: t.type, count: t._count })),
      topGenres,
      yearDistribution: yearData,
      airingCount,
      featuredCount,
      recentAdded,
    });
  } catch (error) {
    console.error("Stats error:", error);
    return NextResponse.json({ error: "Error al obtener estadísticas" }, { status: 500 });
  }
}
