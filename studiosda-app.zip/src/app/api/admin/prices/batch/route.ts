import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";

export async function PUT(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const body = await request.json();
    const { prices, tiers } = body as {
      prices: Record<string, number>;
      tiers: Array<{
        id: string;
        label: string;
        minSize: number | null;
        maxSize: number | null;
        price: number;
        sortOrder: number;
      }>;
    };

    const operations: Promise<any>[] = [];

    if (prices && typeof prices === "object") {
      for (const [type, price] of Object.entries(prices)) {
        if (typeof price === "number") {
          operations.push(
            prisma.contentPrice.upsert({
              where: { type },
              update: { price },
              create: { type, price },
            })
          );
        }
      }
    }

    if (Array.isArray(tiers)) {
      for (const tier of tiers) {
        if (tier.id && tier.label) {
          operations.push(
            prisma.gamePriceTier.update({
              where: { id: tier.id },
              data: {
                label: tier.label,
                minSize: tier.minSize ?? null,
                maxSize: tier.maxSize ?? null,
                price: parseFloat(String(tier.price)),
                sortOrder: tier.sortOrder ?? 0,
              },
            })
          );
        }
      }
    }

    await Promise.all(operations);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error in batch save:", error);
    return NextResponse.json(
      { error: "Error al guardar precios" },
      { status: 500 }
    );
  }
}
