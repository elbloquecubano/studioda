import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const prices = await prisma.contentPrice.findMany();
    return NextResponse.json(prices);
  } catch (error) {
    console.error("Error fetching prices:", error);
    return NextResponse.json({ error: "Error al obtener precios" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const body = await request.json();
    const { type, price, airingPrice } = body;

    if (!type || typeof price !== "number") {
      return NextResponse.json({ error: "Datos inválidos" }, { status: 400 });
    }

    const contentPrice = await prisma.contentPrice.upsert({
      where: { type },
      update: { price, airingPrice: airingPrice ?? null },
      create: { type, price, airingPrice: airingPrice ?? null },
    });

    return NextResponse.json(contentPrice);
  } catch (error) {
    console.error("Error saving price:", error);
    return NextResponse.json({ error: "Error al guardar precio" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get("type");
    if (!type) {
      return NextResponse.json({ error: "Tipo requerido" }, { status: 400 });
    }
    await prisma.contentPrice.delete({ where: { type } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting price:", error);
    return NextResponse.json({ error: "Error al eliminar precio" }, { status: 500 });
  }
}
