import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { MEDIA_TYPES } from "@/lib/types";
import { createGenreSlug, normalizeGenreName } from "@/lib/genres";
import { Prisma } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const [media, genreRecords] = await Promise.all([
      prisma.media.findMany({ select: { type: true, genre: true } }),
      prisma.genre.findMany({ select: { name: true, types: true } }),
    ]);

    const typeMap: Record<string, Set<string>> = {};

    for (const typeKey of Object.keys(MEDIA_TYPES)) {
      typeMap[typeKey] = new Set();
    }

    for (const item of media) {
      if (!typeMap[item.type]) typeMap[item.type] = new Set();
      const genres = item.genre.split(",").map(g => g.trim()).filter(Boolean);
      for (const g of genres) {
        typeMap[item.type].add(g);
      }
    }

    for (const record of genreRecords) {
      const types = record.types.split(",").map(t => t.trim()).filter(Boolean);
      for (const t of types) {
        if (!typeMap[t]) typeMap[t] = new Set();
        typeMap[t].add(record.name);
      }
    }

    const result = Object.entries(MEDIA_TYPES).map(([key, meta]) => ({
      key,
      label: meta.label,
      plural: meta.plural,
      genres: Array.from(typeMap[key] || []).sort((a, b) => a.localeCompare(b)),
      count: media.filter(m => m.type === key).length,
    }));

    return NextResponse.json(result);
  } catch (error) {
    console.error("Error fetching content types:", error);
    return NextResponse.json({ error: "Error al obtener tipos de contenido" }, { status: 500 });
  }
}

async function getUniqueGenreSlug(name: string) {
  const baseSlug = createGenreSlug(name) || "genero";
  let slug = baseSlug;
  let suffix = 2;
  while (await prisma.genre.findUnique({ where: { slug } })) {
    slug = `${baseSlug}-${suffix}`;
    suffix += 1;
  }
  return slug;
}

export async function POST(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const { type, name } = await request.json();

    if (!type || !MEDIA_TYPES[type as keyof typeof MEDIA_TYPES]) {
      return NextResponse.json({ error: "Tipo de contenido no válido" }, { status: 400 });
    }

    const genreName = normalizeGenreName(String(name || ""));
    if (!genreName) {
      return NextResponse.json({ error: "El nombre del género es obligatorio" }, { status: 400 });
    }

    if (genreName.includes(",")) {
      return NextResponse.json({ error: "El nombre del género no puede incluir comas" }, { status: 400 });
    }

    const existing = await prisma.genre.findFirst({ where: { name: genreName } });
    if (existing) {
      const currentTypes = existing.types.split(",").map(t => t.trim()).filter(Boolean);
      if (!currentTypes.includes(type)) {
        const updatedTypes = [...currentTypes, type].join(",");
        await prisma.genre.update({
          where: { id: existing.id },
          data: { types: updatedTypes },
        });
      }
    } else {
      await prisma.genre.create({
        data: {
          name: genreName,
          slug: await getUniqueGenreSlug(genreName),
          types: type,
        },
      });
    }

    return NextResponse.json({ success: true, genre: genreName });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
      return NextResponse.json({ error: "Ese género ya existe" }, { status: 409 });
    }
    console.error("Error adding genre to type:", error);
    return NextResponse.json({ error: "Error al agregar género" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const { genreName, type } = await request.json();

    if (!genreName) {
      return NextResponse.json({ error: "Nombre del género requerido" }, { status: 400 });
    }

    const mediaCount = await prisma.media.count({
      where: { genre: { contains: genreName } },
    });

    if (mediaCount > 0) {
      return NextResponse.json(
        { error: `No se puede eliminar: ${mediaCount} contenido(s) usan este género` },
        { status: 409 }
      );
    }

    const genre = await prisma.genre.findFirst({ where: { name: genreName } });
    if (genre) {
      if (type) {
        const currentTypes = genre.types.split(",").map(t => t.trim()).filter(Boolean);
        const updatedTypes = currentTypes.filter(t => t !== type);
        if (updatedTypes.length > 0) {
          await prisma.genre.update({
            where: { id: genre.id },
            data: { types: updatedTypes.join(",") },
          });
        } else {
          await prisma.genre.delete({ where: { id: genre.id } });
        }
      } else {
        await prisma.genre.delete({ where: { id: genre.id } });
      }
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting genre:", error);
    return NextResponse.json({ error: "Error al eliminar género" }, { status: 500 });
  }
}
