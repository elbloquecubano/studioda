import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";

const DEFAULT_TIERS = [
  { label: "Hasta 10GB", minSize: null, maxSize: 10, price: 0, sortOrder: 1 },
  { label: "11GB a 40GB", minSize: 11, maxSize: 40, price: 0, sortOrder: 2 },
  { label: "41GB a 80GB", minSize: 41, maxSize: 80, price: 0, sortOrder: 3 },
  { label: "Más de 80GB", minSize: 81, maxSize: null, price: 0, sortOrder: 4 },
];

export async function GET() {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    let tiers = await prisma.gamePriceTier.findMany({ orderBy: { sortOrder: "asc" } });
    if (tiers.length === 0) {
      await prisma.gamePriceTier.createMany({ data: DEFAULT_TIERS });
      tiers = await prisma.gamePriceTier.findMany({ orderBy: { sortOrder: "asc" } });
    }
    return NextResponse.json(tiers);
  } catch (error) {
    console.error("Error fetching game price tiers:", error);
    return NextResponse.json({ error: "Error al obtener los rangos" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const body = await request.json();
    const { id, label, minSize, maxSize, price, sortOrder } = body;

    if (!id || !label || price === undefined) {
      return NextResponse.json({ error: "Faltan campos requeridos" }, { status: 400 });
    }

    const updated = await prisma.gamePriceTier.update({
      where: { id },
      data: {
        label,
        minSize: minSize ?? null,
        maxSize: maxSize ?? null,
        price: parseFloat(price),
        sortOrder: sortOrder ?? 0,
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Error updating game price tier:", error);
    return NextResponse.json({ error: "Error al actualizar rango" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const body = await request.json();
    const { label, minSize, maxSize, price, sortOrder } = body;

    if (!label || price === undefined) {
      return NextResponse.json({ error: "Faltan campos requeridos" }, { status: 400 });
    }

    const count = await prisma.gamePriceTier.count();
    const created = await prisma.gamePriceTier.create({
      data: {
        label,
        minSize: minSize ?? null,
        maxSize: maxSize ?? null,
        price: parseFloat(price),
        sortOrder: sortOrder ?? count + 1,
      },
    });

    return NextResponse.json(created);
  } catch (error) {
    console.error("Error creating game price tier:", error);
    return NextResponse.json({ error: "Error al crear rango" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID requerido" }, { status: 400 });
    }

    await prisma.gamePriceTier.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting game price tier:", error);
    return NextResponse.json({ error: "Error al eliminar rango" }, { status: 500 });
  }
}
