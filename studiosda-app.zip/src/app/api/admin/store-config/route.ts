import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";

const DEFAULT_STORES = [
  { location: "matriz", address: "Anglona entre salud y tenería", openTime: "10:00", closeTime: "20:00" },
  { location: "actualizate", address: "Tenería entre 34 y 38", openTime: "10:00", closeTime: "20:00" },
  { location: "cinemania", address: "Zaes esquina 27", openTime: "10:00", closeTime: "20:00" },
  { location: "fastcopier", address: "45 entre calzada y velázquez", openTime: "10:00", closeTime: "20:00" },
];

export async function GET() {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    let configs = await prisma.storeConfig.findMany({ orderBy: { location: "asc" } });
    if (configs.length === 0) {
      await prisma.storeConfig.createMany({ data: DEFAULT_STORES });
      configs = await prisma.storeConfig.findMany({ orderBy: { location: "asc" } });
    }
    return NextResponse.json(configs);
  } catch (error) {
    console.error("Error fetching store config:", error);
    return NextResponse.json({ error: "Error al obtener configuración" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const body = await request.json();
    const { id, address, openTime, closeTime } = body;

    if (!id || !address || !openTime || !closeTime) {
      return NextResponse.json({ error: "Faltan campos requeridos" }, { status: 400 });
    }

    const updated = await prisma.storeConfig.update({
      where: { id },
      data: { address, openTime, closeTime },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Error updating store config:", error);
    return NextResponse.json({ error: "Error al actualizar configuración" }, { status: 500 });
  }
}
