import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";

export async function POST(request: Request) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const formData = await request.formData();
    const file = formData.get("file") as File | null;

    if (!file) {
      return NextResponse.json({ error: "No se envió ningún archivo" }, { status: 400 });
    }

    const text = await file.text();
    let data: { media?: any[]; genres?: any[] };

    try {
      data = JSON.parse(text);
    } catch {
      return NextResponse.json({ error: "El archivo no es un JSON válido" }, { status: 400 });
    }

    if (!data.media && !data.genres) {
      return NextResponse.json(
        { error: "El JSON debe contener 'media' y/o 'genres'" },
        { status: 400 }
      );
    }

    // Ejecutar todo en una transacción
    await prisma.$transaction(async (tx) => {
      if (data.genres) {
        await tx.genre.deleteMany();
        for (const g of data.genres) {
          await tx.genre.create({
            data: {
              id: g.id,
              name: g.name,
              slug: g.slug,
              createdAt: g.createdAt ? new Date(g.createdAt) : new Date(),
              updatedAt: g.updatedAt ? new Date(g.updatedAt) : new Date(),
            },
          });
        }
      }

      if (data.media) {
        await tx.media.deleteMany();
        const batchSize = 100;
        for (let i = 0; i < data.media.length; i += batchSize) {
          const batch = data.media.slice(i, i + batchSize);
          await tx.media.createMany({
            data: batch.map((m) => ({
              id: m.id,
              title: m.title,
              type: m.type,
              year: m.year,
              genre: m.genre,
              synopsis: m.synopsis,
              review: m.review || "",
              posterPath: m.posterPath,
              backdropPath: m.backdropPath,
              isFeatured: m.isFeatured ?? false,
              isAiring: m.isAiring ?? false,
              likes: m.likes ?? 0,
              dislikes: m.dislikes ?? 0,
              createdAt: m.createdAt ? new Date(m.createdAt) : new Date(),
              updatedAt: m.updatedAt ? new Date(m.updatedAt) : new Date(),
            })),
          });
        }
      }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Import error:", error);
    return NextResponse.json({ error: "Error al importar los datos" }, { status: 500 });
  }
}
