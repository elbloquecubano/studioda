import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";

const DEFAULT_TEMPLATE = `⚽️《《 Studio D-A 》》⚽️
  🏆 •A faster way• 🏆 

🥇🥇 

🎬 Tipo》 {type}
🚩 Nombre》 {title}
🕔 Género 》 {genre}
🌎 De que trata？》 {synopsis}

🚴Mensajero activo en Cardenas🗺

📲55786876
📲55250290`;

export async function GET() {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    let config = await prisma.siteConfig.findUnique({ where: { key: "copy_template" } });
    if (!config) {
      config = await prisma.siteConfig.create({
        data: { key: "copy_template", value: DEFAULT_TEMPLATE },
      });
    }
    return NextResponse.json({ value: config.value });
  } catch (error) {
    console.error("Error fetching site config:", error);
    return NextResponse.json({ error: "Error al obtener configuración" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const { value } = await request.json();

    if (typeof value !== "string") {
      return NextResponse.json({ error: "Valor requerido" }, { status: 400 });
    }

    const config = await prisma.siteConfig.upsert({
      where: { key: "copy_template" },
      update: { value },
      create: { key: "copy_template", value },
    });

    return NextResponse.json({ value: config.value });
  } catch (error) {
    console.error("Error updating site config:", error);
    return NextResponse.json({ error: "Error al guardar configuración" }, { status: 500 });
  }
}
