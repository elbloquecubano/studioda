import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function GET() {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const [media, genres] = await Promise.all([
      prisma.media.findMany({ orderBy: { createdAt: "asc" } }),
      prisma.genre.findMany({ orderBy: { name: "asc" } }),
    ]);

    const data = { exportedAt: new Date().toISOString(), media, genres };
    const json = JSON.stringify(data, null, 2);

    return new NextResponse(json, {
      headers: {
        "Content-Type": "application/json",
        "Content-Disposition": `attachment; filename="studiosda-backup-${new Date().toISOString().slice(0, 10)}.json"`,
      },
    });
  } catch (error) {
    console.error("Export error:", error);
    return NextResponse.json({ error: "Error al exportar los datos" }, { status: 500 });
  }
}
