import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";

const NO_STORE = { "Cache-Control": "no-store" };

/** Los mismos estados que entiende /mi-cuenta/pedidos. */
const STATUSES = ["PENDIENTE", "LISTO", "ENTREGADO", "CANCELADO"] as const;

type Status = (typeof STATUSES)[number];

function isStatus(value: unknown): value is Status {
  return typeof value === "string" && (STATUSES as readonly string[]).includes(value);
}

/** Importe máximo aceptado, para que un dedazo no genere una cifra absurda. */
const MAX_AMOUNT = 1_000_000;

/**
 * Normaliza el importe que teclea el admin. Devuelve `undefined` cuando el
 * valor no sirve, que quien llame traduce en un 400: aquí no se puede
 * distinguir con un null, porque null es un valor válido (borrar el monto).
 */
function parseAmount(value: unknown): number | null | undefined {
  if (value === null || value === "") return null;
  const amount = typeof value === "string" ? Number(value.replace(",", ".")) : value;
  if (typeof amount !== "number" || !Number.isFinite(amount)) return undefined;
  if (amount < 0 || amount > MAX_AMOUNT) return undefined;
  // Se guarda con dos decimales: es lo que se muestra y lo que se cobra.
  return Math.round(amount * 100) / 100;
}

export async function GET(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  const status = request.nextUrl.searchParams.get("status");

  try {
    const orders = await prisma.order.findMany({
      where: isStatus(status) ? { status } : undefined,
      // El agrupado por cliente lo hace la interfaz; aquí basta con que lo más
      // reciente venga primero.
      orderBy: { createdAt: "desc" },
      take: 300,
      select: {
        id: true,
        mediaId: true,
        titleSnapshot: true,
        priceSnapshot: true,
        priceConfirmed: true,
        status: true,
        notes: true,
        createdAt: true,
        user: {
          select: {
            id: true,
            username: true,
            displayName: true,
            phone: true,
            address: true,
          },
        },
      },
    });

    return NextResponse.json(orders, { headers: NO_STORE });
  } catch (error) {
    console.error("Error al obtener pedidos:", error);
    return NextResponse.json({ error: "Error al obtener los pedidos" }, { status: 500 });
  }
}

export async function PATCH(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  let id: string;
  let body: Record<string, unknown>;

  try {
    body = (await request.json()) ?? {};
    id = typeof body?.id === "string" ? body.id : "";
  } catch {
    return NextResponse.json({ error: "Petición inválida" }, { status: 400 });
  }

  if (!id) {
    return NextResponse.json({ error: "Falta el pedido" }, { status: 400 });
  }

  const data: { status?: Status; priceSnapshot?: number | null; priceConfirmed?: boolean } = {};

  if ("status" in body) {
    if (!isStatus(body.status)) {
      return NextResponse.json({ error: "Estado no válido" }, { status: 400 });
    }
    data.status = body.status;
  }

  if ("amount" in body) {
    const amount = parseAmount(body.amount);
    if (amount === undefined) {
      return NextResponse.json({ error: "El monto no es válido" }, { status: 400 });
    }
    data.priceSnapshot = amount;
  }

  if ("confirmed" in body) {
    if (typeof body.confirmed !== "boolean") {
      return NextResponse.json({ error: "Petición inválida" }, { status: 400 });
    }
    data.priceConfirmed = body.confirmed;
  }

  if (Object.keys(data).length === 0) {
    return NextResponse.json({ error: "No hay nada que cambiar" }, { status: 400 });
  }

  try {
    const current = await prisma.order.findUnique({
      where: { id },
      select: { priceSnapshot: true },
    });

    if (!current) {
      return NextResponse.json({ error: "Ese pedido ya no existe" }, { status: 404 });
    }

    // Confirmar sin importe dejaría al cliente viendo un total que no cuadra
    // con lo que se le va a cobrar. Se comprueba contra el valor resultante,
    // que puede venir en esta misma petición.
    const finalAmount = "priceSnapshot" in data ? data.priceSnapshot : current.priceSnapshot;
    if (data.priceConfirmed && finalAmount === null) {
      return NextResponse.json(
        { error: "Escribe el monto antes de confirmarlo" },
        { status: 400 }
      );
    }

    // Borrar el importe de un pedido ya confirmado lo devuelve a «esperando
    // monto»: sin cifra no hay nada que enseñar.
    if (data.priceSnapshot === null && data.priceConfirmed !== false) {
      data.priceConfirmed = false;
    }

    const order = await prisma.order.update({
      where: { id },
      data,
      select: { id: true, status: true, priceSnapshot: true, priceConfirmed: true },
    });

    return NextResponse.json(order, { headers: NO_STORE });
  } catch {
    // El único fallo esperable aquí es que el pedido ya no exista (P2025).
    return NextResponse.json({ error: "Ese pedido ya no existe" }, { status: 404 });
  }
}

export async function DELETE(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  let id: string;

  try {
    const body = await request.json();
    id = typeof body?.id === "string" ? body.id : "";
  } catch {
    return NextResponse.json({ error: "Petición inválida" }, { status: 400 });
  }

  if (!id) {
    return NextResponse.json({ error: "Falta el pedido" }, { status: 400 });
  }

  try {
    await prisma.order.delete({ where: { id } });
    return NextResponse.json({ success: true }, { headers: NO_STORE });
  } catch {
    return NextResponse.json({ error: "Ese pedido ya no existe" }, { status: 404 });
  }
}
