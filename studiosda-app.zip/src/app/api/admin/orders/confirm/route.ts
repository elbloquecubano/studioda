import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";

const NO_STORE = { "Cache-Control": "no-store" };

/**
 * Confirma de una vez todos los montos pendientes de un cliente.
 *
 * El panel agrupa por cliente y el admin revisa la cuenta entera antes de
 * dársela por buena, así que confirmar pedido a pedido dejaría al cliente
 * viendo totales a medias mientras dura la revisión.
 *
 * Los pedidos sin importe se quedan fuera a propósito: confirmar un pedido sin
 * monto es justo lo que no debe pasar. Se devuelve cuántos han quedado sin
 * confirmar para poder avisarlo en la interfaz.
 */
export async function POST(request: NextRequest) {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  let userId: string;

  try {
    const body = await request.json();
    userId = typeof body?.userId === "string" ? body.userId : "";
  } catch {
    return NextResponse.json({ error: "Petición inválida" }, { status: 400 });
  }

  if (!userId) {
    return NextResponse.json({ error: "Falta el cliente" }, { status: 400 });
  }

  try {
    // Los cancelados no se cobran, así que tampoco se confirman.
    const pending = await prisma.order.findMany({
      where: { userId, priceConfirmed: false, status: { not: "CANCELADO" } },
      select: { id: true, priceSnapshot: true },
    });

    const confirmable = pending.filter((order) => order.priceSnapshot !== null);

    if (confirmable.length > 0) {
      await prisma.order.updateMany({
        where: { id: { in: confirmable.map((order) => order.id) } },
        data: { priceConfirmed: true },
      });
    }

    return NextResponse.json(
      {
        confirmed: confirmable.map((order) => order.id),
        skipped: pending.length - confirmable.length,
      },
      { headers: NO_STORE }
    );
  } catch (error) {
    console.error("Error al confirmar montos:", error);
    return NextResponse.json({ error: "Error en el servidor" }, { status: 500 });
  }
}
