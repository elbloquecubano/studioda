import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";

/**
 * Número de pedidos sin atender, para el aviso del menú lateral.
 *
 * Va aparte de `GET /api/admin/orders` porque aquel devuelve hasta 300 pedidos
 * completos con los datos del cliente, y la barra lateral lo consulta cada
 * pocos segundos desde todas las páginas del panel.
 *
 * "Sin atender" es PENDIENTE, el estado con el que nacen los pedidos: así el
 * aviso se apaga cuando el pedido se despacha, no por el mero hecho de haber
 * abierto la pantalla. Contar por `status` usa el índice que ya declara el
 * modelo Order.
 */
export async function GET() {
  const auth = await requireAdmin();
  if (auth instanceof NextResponse) return auth;

  try {
    const pending = await prisma.order.count({ where: { status: "PENDIENTE" } });

    return NextResponse.json({ pending }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Error al contar pedidos pendientes:", error);
    return NextResponse.json({ error: "Error al contar los pedidos" }, { status: 500 });
  }
}
