import AdminCambiarPassword from "@/components/admin/AdminCambiarPassword"

export const dynamic = "force-dynamic"

export const metadata = {
  title: "Cambiar contraseña - Studios D-A",
}

export default function CambiarPasswordPage() {
  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 blur-[120px] rounded-full" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent-blue/5 blur-[120px] rounded-full" />

      <div className="relative z-10 w-full flex justify-center">
        <AdminCambiarPassword />
      </div>
    </div>
  )
}
