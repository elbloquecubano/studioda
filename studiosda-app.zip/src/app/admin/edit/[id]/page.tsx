import { prisma } from "@/lib/prisma";
import AdminAddMedia from "@/components/admin/AdminAddMedia";
import AdminSidebar from "@/components/admin/AdminSidebar";
import { notFound } from "next/navigation";

export default async function AdminEditPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const media = await prisma.media.findUnique({
    where: { id }
  });

  if (!media) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-[#050505] flex">
      <AdminSidebar />
      <main className="flex-grow p-6 md:p-12 overflow-y-auto pt-24 lg:pt-12">
        <AdminAddMedia initialData={JSON.parse(JSON.stringify(media))} />
      </main>
    </div>
  )
}
