import AdminOrders from "@/components/admin/AdminOrders";
import AdminSidebar from "@/components/admin/AdminSidebar";

export default function AdminOrdersPage() {
  return (
    <div className="min-h-screen bg-[#050505] flex">
      <AdminSidebar />
      <main className="flex-grow p-6 md:p-12 overflow-y-auto pt-24 lg:pt-12">
        <AdminOrders />
      </main>
    </div>
  );
}
