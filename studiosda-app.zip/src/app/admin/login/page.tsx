import AdminLoginForm from "@/components/admin/AdminLoginForm";

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#050505] relative overflow-hidden px-6">
      {/* Cinematic Background Decoration */}
      <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-accent/5 blur-[120px] rounded-full" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[50%] h-[50%] bg-accent-blue/5 blur-[120px] rounded-full" />
      
      <div className="relative z-10 w-full flex justify-center">
        <AdminLoginForm />
      </div>
    </div>
  )
}
