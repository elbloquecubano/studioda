import { redirect } from "next/navigation"
import { headers } from "next/headers"
import { getCurrentUser } from "@/lib/auth"

/**
 * Segunda capa de autorización del panel.
 *
 * El proxy sólo puede comprobar la firma de la cookie; aquí se contrasta
 * contra la base de datos, así que desactivar una cuenta o cambiarle la
 * contraseña corta el acceso de inmediato en vez de esperar a que caduque el
 * token.
 *
 * A propósito no renderiza la barra lateral: cada página de /admin ya monta su
 * propio <AdminSidebar />, y añadirla aquí la duplicaría.
 */
export const dynamic = "force-dynamic"

const CHANGE_PASSWORD_PATH = "/admin/cambiar-password"

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const headerList = await headers()
  const pathname = headerList.get("x-pathname") ?? ""

  // /admin/login se sirve sin sesión: es donde se entra.
  if (pathname === "/admin/login") {
    return <>{children}</>
  }

  const user = await getCurrentUser()

  if (!user || user.role !== "ADMIN") {
    redirect("/admin/login")
  }

  // La contraseña inicial la genera scripts/crear-admin.mjs y queda escrita en
  // un archivo de texto, así que hay que forzar su cambio antes de dar acceso
  // al resto del panel.
  if (user.mustChangePassword && pathname !== CHANGE_PASSWORD_PATH) {
    redirect(CHANGE_PASSWORD_PATH)
  }

  return <>{children}</>
}
