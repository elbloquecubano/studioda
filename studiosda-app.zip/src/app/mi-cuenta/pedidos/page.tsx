import Link from "next/link"
import { Clock, ShoppingBag } from "lucide-react"
import { getCurrentUser } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { formatPrice } from "@/lib/pricing"

export const dynamic = "force-dynamic"

export const metadata = {
  title: "Mis pedidos - Studios D-A",
}

const STATUS_LABELS: Record<string, { label: string; tone: string }> = {
  PENDIENTE: { label: "En proceso", tone: "bg-accent-blue/20 text-accent-blue border-accent-blue/30" },
  LISTO: { label: "Listo para recoger", tone: "bg-green-500/20 text-green-500 border-green-500/30" },
  ENTREGADO: { label: "Entregado", tone: "bg-white/10 text-muted border-white/10" },
  CANCELADO: { label: "Cancelado", tone: "bg-red-500/20 text-red-500 border-red-500/30" },
}

export default async function MisPedidosPage() {
  const user = await getCurrentUser()
  if (!user) return null

  const orders = await prisma.order.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
  })

  // Mismo criterio que el panel de admin: lo cancelado no se cobra.
  const cobrables = orders.filter((order) => order.status !== "CANCELADO")

  // Sólo suma lo que la tienda ya ha dado por bueno. Un pedido recién apartado
  // lleva un precio calculado, pero hasta que el admin no lo confirma no es una
  // cifra que se le pueda enseñar a nadie: aquí sale «Esperando monto».
  const confirmados = cobrables.filter((order) => order.priceConfirmed && order.priceSnapshot !== null)
  const pendientesDeMonto = cobrables.length - confirmados.length
  const total = confirmados.reduce((sum, order) => sum + (order.priceSnapshot ?? 0), 0)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-black tracking-tighter border-l-4 border-accent pl-4">
          Mis pedidos
        </h1>
        <p className="text-muted mt-2 pl-5">Lo que has apartado en la tienda.</p>
      </div>

      {orders.length === 0 ? (
        <div className="glass rounded-3xl p-12 border border-white/5 text-center">
          <ShoppingBag className="w-12 h-12 text-muted mx-auto mb-4" />
          <p className="font-bold text-lg">Todavía no tienes pedidos</p>
          <p className="text-muted text-sm mt-2 mb-6">
            Cuando apartes algo del catálogo, aparecerá aquí.
          </p>
          <Link
            href="/"
            className="inline-block bg-accent text-black font-bold px-6 py-3 rounded-xl hover:scale-[1.02] active:scale-[0.98] transition-all"
          >
            Explorar el catálogo
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="glass rounded-2xl p-5 border border-accent/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-sm text-muted font-medium">Total de lo que tienes apartado</span>
              {pendientesDeMonto > 0 && (
                <p className="flex items-center gap-1.5 text-xs text-amber-500 mt-1">
                  <Clock className="w-3.5 h-3.5 shrink-0" />
                  {pendientesDeMonto === 1
                    ? "1 pedido esperando monto"
                    : `${pendientesDeMonto} pedidos esperando monto`}
                </p>
              )}
            </div>
            {confirmados.length === 0 ? (
              <span className="text-lg font-black text-amber-500">Esperando monto</span>
            ) : (
              <span className="text-2xl font-black text-accent">{formatPrice(total)}</span>
            )}
          </div>

          {orders.map((order) => {
            const status = STATUS_LABELS[order.status] ?? {
              label: order.status,
              tone: "bg-white/10 text-muted border-white/10",
            }

            return (
              <div
                key={order.id}
                className="glass rounded-2xl p-5 border border-white/5 flex flex-col sm:flex-row sm:items-center gap-3 justify-between"
              >
                <div className="min-w-0">
                  <p className="font-bold truncate">{order.titleSnapshot}</p>
                  <p className="text-xs text-muted mt-1">
                    {order.priceConfirmed && order.priceSnapshot !== null ? (
                      <span className="font-bold text-foreground/80">
                        {formatPrice(order.priceSnapshot)} ·{" "}
                      </span>
                    ) : (
                      order.status !== "CANCELADO" && (
                        <span className="font-bold text-amber-500">Esperando monto · </span>
                      )
                    )}
                    Apartado el{" "}
                    {order.createdAt.toLocaleDateString("es", {
                      day: "numeric",
                      month: "long",
                      year: "numeric",
                    })}
                  </p>
                  {order.notes && <p className="text-sm text-muted mt-2">{order.notes}</p>}
                </div>

                <span
                  className={`shrink-0 self-start sm:self-center px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest border ${status.tone}`}
                >
                  {status.label}
                </span>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
