import Link from "next/link"
import { ShoppingBag, User as UserIcon, Clock } from "lucide-react"
import { getCurrentUser } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

export const dynamic = "force-dynamic"

export const metadata = {
  title: "Mi cuenta - Studios D-A",
}

export default async function MiCuentaPage() {
  // El layout ya garantiza que hay sesión; aquí sólo se leen los datos.
  const user = await getCurrentUser()
  if (!user) return null

  const [pendientes, listos, total] = await Promise.all([
    prisma.order.count({ where: { userId: user.id, status: "PENDIENTE" } }),
    prisma.order.count({ where: { userId: user.id, status: "LISTO" } }),
    prisma.order.count({ where: { userId: user.id } }),
  ])

  const cards = [
    { label: "En proceso", value: pendientes, icon: Clock, tone: "text-accent-blue bg-accent-blue/20" },
    { label: "Listos para recoger", value: listos, icon: ShoppingBag, tone: "text-green-500 bg-green-500/20" },
    { label: "Pedidos en total", value: total, icon: ShoppingBag, tone: "text-accent bg-accent/20" },
  ]

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl md:text-4xl font-black tracking-tighter">
          Hola, <span className="text-accent">{user.displayName || user.username}</span>
        </h1>
        <p className="text-muted mt-2">Este es el resumen de tu cuenta.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {cards.map((card) => {
          const Icon = card.icon
          return (
            <div key={card.label} className="bg-white/5 border border-white/10 rounded-2xl p-5">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${card.tone}`}>
                <Icon className="w-5 h-5" />
              </div>
              <p className="text-3xl font-black">{card.value}</p>
              <p className="text-xs text-muted uppercase tracking-widest mt-1">{card.label}</p>
            </div>
          )
        })}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Link
          href="/mi-cuenta/pedidos"
          className="glass rounded-2xl p-6 border border-white/5 hover:border-accent/30 transition-colors group"
        >
          <ShoppingBag className="w-6 h-6 text-accent mb-3" />
          <p className="font-bold group-hover:text-accent transition-colors">Ver mis pedidos</p>
          <p className="text-sm text-muted mt-1">Consulta en qué estado va cada apartado.</p>
        </Link>

        <Link
          href="/mi-cuenta/perfil"
          className="glass rounded-2xl p-6 border border-white/5 hover:border-accent/30 transition-colors group"
        >
          <UserIcon className="w-6 h-6 text-accent mb-3" />
          <p className="font-bold group-hover:text-accent transition-colors">Editar mi perfil</p>
          <p className="text-sm text-muted mt-1">Cambia tu nombre, teléfono o contraseña.</p>
        </Link>
      </div>
    </div>
  )
}
