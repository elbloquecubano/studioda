import { redirect } from "next/navigation"
import { getCurrentUser } from "@/lib/auth"
import CuentaSidebar from "@/components/cuenta/CuentaSidebar"

// El proxy sólo verifica la firma de la cookie. Aquí se comprueba además
// contra la base de datos (tokenVersion y cuenta activa), así que la página no
// puede cachearse.
export const dynamic = "force-dynamic"

export default async function MiCuentaLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/cuenta/login?next=/mi-cuenta")
  }

  return (
    <div className="max-w-6xl mx-auto px-4 md:px-8 py-8 md:py-12">
      <div className="flex flex-col lg:flex-row gap-8">
        <CuentaSidebar displayName={user.displayName || user.username} />
        <main className="flex-grow min-w-0">{children}</main>
      </div>
    </div>
  )
}
