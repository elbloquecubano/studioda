import { getCurrentUser } from "@/lib/auth"
import PerfilForm from "@/components/cuenta/PerfilForm"

export const dynamic = "force-dynamic"

export const metadata = {
  title: "Mi perfil - Studios D-A",
}

export default async function PerfilPage() {
  const user = await getCurrentUser()
  if (!user) return null

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-black tracking-tighter border-l-4 border-accent pl-4">
        Mi perfil
      </h1>

      <PerfilForm
        username={user.username}
        displayName={user.displayName ?? ""}
        phone={user.phone ?? ""}
        address={user.address ?? ""}
      />
    </div>
  )
}
