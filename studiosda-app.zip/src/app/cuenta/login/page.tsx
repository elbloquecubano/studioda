import { Suspense } from "react"
import { redirect } from "next/navigation"
import { getCurrentUser } from "@/lib/auth"
import ClienteLoginForm from "@/components/cuenta/ClienteLoginForm"

export const dynamic = "force-dynamic"

export const metadata = {
  title: "Entrar - Studios D-A",
}

export default async function ClienteLoginPage() {
  // Quien ya tiene sesión no necesita ver esta pantalla.
  const user = await getCurrentUser()
  if (user) {
    redirect(user.role === "ADMIN" ? "/admin" : "/mi-cuenta")
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 blur-[120px] rounded-full" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent-blue/5 blur-[120px] rounded-full" />

      <div className="relative z-10 w-full flex justify-center">
        {/* useSearchParams necesita un limite de Suspense para no forzar el
            renderizado dinamico de toda la pagina. */}
        <Suspense fallback={null}>
          <ClienteLoginForm />
        </Suspense>
      </div>
    </div>
  )
}
