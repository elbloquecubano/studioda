import { redirect } from "next/navigation"
import { getCurrentUser } from "@/lib/auth"
import ClienteRegistroForm from "@/components/cuenta/ClienteRegistroForm"

export const dynamic = "force-dynamic"

export const metadata = {
  title: "Crear cuenta - Studios D-A",
}

export default async function ClienteRegistroPage() {
  const user = await getCurrentUser()
  if (user) {
    redirect(user.role === "ADMIN" ? "/admin" : "/mi-cuenta")
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4 py-12 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 blur-[120px] rounded-full" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent-blue/5 blur-[120px] rounded-full" />

      <div className="relative z-10 w-full flex justify-center">
        <ClienteRegistroForm />
      </div>
    </div>
  )
}
