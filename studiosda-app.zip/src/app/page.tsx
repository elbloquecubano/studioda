import Hero from "@/components/Hero";
import MovieCard from "@/components/MovieCard";
import Carousel from "@/components/Carousel";
import Pagination from "@/components/Pagination";
import CategoryHero from "@/components/CategoryHero";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { getMediaTypePlural } from "@/lib/types";

export const revalidate = 300;

const PER_PAGE = 50;

function buildBasePath(type?: string, genre?: string, search?: string, transmision?: string) {
  const params = new URLSearchParams();
  if (type) params.set("type", type);
  if (genre) params.set("genre", genre);
  if (search) params.set("search", search);
  if (transmision) params.set("transmision", transmision);
  return `/?${params.toString()}`;
}

export default async function Home({
  searchParams,
}: {
  searchParams: Promise<{ type?: string; genre?: string; search?: string; page?: string; transmision?: string }>;
}) {
  const { type, genre, search, page, transmision } = await searchParams;
  const currentPage = Math.max(1, parseInt(page || "1", 10) || 1);
  const isTransmision = transmision === "true";
  const isCatalogView = !!type || !!genre || !!search || isTransmision;

  const where = {
    AND: [
      type ? (type === "Novela" ? { type: { startsWith: "Novela" } } : { type }) : {},
      genre ? { genre: { contains: genre } } : {},
      search ? { title: { contains: search } } : {},
      isTransmision ? { isAiring: true } : {},
    ],
  };

  const allMediaForGenres = await prisma.media.findMany({
    select: { genre: true, type: true },
    where: isTransmision ? { isAiring: true } : type ? (type === "Novela" ? { type: { startsWith: "Novela" } } : { type }) : {},
  });

  const allGenres = Array.from(
    new Set(
      allMediaForGenres
        .flatMap((m) => m.genre.split(","))
        .map((g) => g.trim())
        .filter(Boolean)
    )
  ).sort();

  if (allMediaForGenres.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-muted">
        <p className="text-xl">El catálogo está vacío.</p>
        <p className="text-sm mt-2">Ingresa al panel de administración para añadir contenido.</p>
      </div>
    );
  }

  if (!isCatalogView) {
    const allMedia = await prisma.media.findMany({
      where: {},
      orderBy: { createdAt: "desc" },
    });
    const featured = allMedia.find((m) => m.isFeatured) || allMedia[0];

    return (
      <div className="flex flex-col w-full">
        {featured && (
          <Hero
            movie={{
              ...featured,
              year: featured.year,
              genre: featured.genre,
            }}
          />
        )}

        <div className="px-4 sm:px-6 md:px-12 py-8 sm:py-12 max-w-7xl mx-auto w-full">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl sm:text-2xl font-bold border-l-4 border-accent pl-4">
              Agregados Recientemente
            </h2>
          </div>

          <Carousel>
            {allMedia.map((movie) => (
              <MovieCard
                key={movie.id}
                movie={{
                  id: movie.id,
                  title: movie.title,
                  posterPath: movie.posterPath,
                  year: movie.year,
                }}
              />
            ))}
          </Carousel>
        </div>
      </div>
    );
  }

  const [mediaPage, totalCount, heroMovie] = await Promise.all([
    prisma.media.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (currentPage - 1) * PER_PAGE,
      take: PER_PAGE,
    }),
    prisma.media.count({ where }),
    prisma.media.findFirst({
      where,
      orderBy: { createdAt: "desc" },
    }),
  ]);

  const totalPages = Math.ceil(totalCount / PER_PAGE);
  const basePath = buildBasePath(type, genre, search, transmision);

  if (totalCount === 0) {
    return (
      <div className="flex flex-col w-full">
        <div className="px-4 sm:px-6 md:px-12 py-8 sm:py-12 max-w-7xl mx-auto w-full">
          {allGenres.length > 0 && (
            <div className="mb-6 sm:mb-10 overflow-x-auto pb-2 sm:pb-4 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
              <div className="flex gap-3 min-w-max">
                <Link
                  href={isTransmision ? "/?transmision=true" : type ? `/?type=${type}` : "/"}
                  className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-300 ${
                    !genre
                      ? "bg-accent text-white shadow-[0_0_15px_rgba(229,9,20,0.4)]"
                      : "bg-white/5 text-foreground/70 hover:text-foreground hover:bg-white/10 border border-white/5"
                  }`}
                >
                  Todos
                </Link>
                {allGenres.map((g) => {
                  const isActive = genre === g;
                  const linkHref = isTransmision
                    ? `/?transmision=true&genre=${encodeURIComponent(g)}`
                    : type
                    ? `/?type=${type}&genre=${encodeURIComponent(g)}`
                    : `/?genre=${encodeURIComponent(g)}`;
                  return (
                    <Link
                      key={g}
                      href={linkHref}
                      className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-300 ${
                        isActive
                          ? "bg-accent text-white shadow-[0_0_15px_rgba(229,9,20,0.4)]"
                          : "bg-white/5 text-foreground/70 hover:text-foreground hover:bg-white/10 border border-white/5"
                      }`}
                    >
                      {g}
                    </Link>
                  );
                })}
              </div>
            </div>
          )}

          <div className="flex flex-col items-center justify-center min-h-[40vh] text-muted-foreground text-center">
            <p className="text-xl font-bold">No se encontraron resultados.</p>
            <p className="text-sm mt-2">Intenta seleccionar otra categoría o restablece el filtro.</p>
            <Link
              href={isTransmision ? "/?transmision=true" : type ? `/?type=${type}` : "/"}
              className="mt-6 px-6 py-2.5 bg-accent text-white font-bold rounded-xl hover:scale-[1.02] active:scale-[0.98] transition-all text-sm uppercase tracking-wider"
            >
              Restablecer Filtro
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col w-full">
      {heroMovie && currentPage === 1 && !search && (
        <CategoryHero movie={heroMovie} />
      )}

      <div className="px-4 sm:px-6 md:px-12 py-8 sm:py-12 max-w-7xl mx-auto w-full">
        {allGenres.length > 0 && (
          <div className="mb-6 sm:mb-10 overflow-x-auto pb-2 sm:pb-4 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
            <div className="flex gap-3 min-w-max">
              <Link
                href={isTransmision ? "/?transmision=true" : type ? `/?type=${type}` : "/"}
                className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-300 ${
                  !genre
                    ? "bg-accent text-white shadow-[0_0_15px_rgba(229,9,20,0.4)]"
                    : "bg-white/5 text-foreground/70 hover:text-foreground hover:bg-white/10 border border-white/5"
                }`}
              >
                Todos
              </Link>
              {allGenres.map((g) => {
                const isActive = genre === g;
                const linkHref = isTransmision
                  ? `/?transmision=true&genre=${encodeURIComponent(g)}`
                  : type
                  ? `/?type=${type}&genre=${encodeURIComponent(g)}`
                  : `/?genre=${encodeURIComponent(g)}`;
                return (
                  <Link
                    key={g}
                    href={linkHref}
                    className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-300 ${
                      isActive
                        ? "bg-accent text-white shadow-[0_0_15px_rgba(229,9,20,0.4)]"
                        : "bg-white/5 text-foreground/70 hover:text-foreground hover:bg-white/10 border border-white/5"
                    }`}
                  >
                    {g}
                  </Link>
                );
              })}
            </div>
          </div>
        )}

        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl sm:text-2xl font-bold border-l-4 border-accent pl-4 flex items-center gap-2">
            <span>{search ? `Resultados: "${search}"` : isTransmision ? "En Transmisión" : getMediaTypePlural(type!)}</span>
            {genre && <span className="text-accent font-medium text-base sm:text-lg">› {genre}</span>}
          </h2>
          <span className="text-sm text-muted">
            {totalCount} {totalCount === 1 ? "resultado" : "resultados"}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
          {mediaPage.map((movie) => (
            <MovieCard
              key={movie.id}
              movie={{
                id: movie.id,
                title: movie.title,
                posterPath: movie.posterPath,
                year: movie.year,
              }}
            />
          ))}
        </div>

        {totalPages > 1 && (
          <div className="mt-8">
            <Pagination currentPage={currentPage} totalPages={totalPages} basePath={basePath} />
          </div>
        )}
      </div>
    </div>
  );
}
