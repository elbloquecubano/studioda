import { Skeleton } from "@/components/ui/Skeleton"

export default function Loading() {
  return (
    <div className="flex flex-col w-full min-h-screen">
      {/* Hero Skeleton */}
      <Skeleton className="h-[85vh] w-full" />
      
      <div className="px-6 md:px-12 py-12 max-w-7xl mx-auto w-full">
        <div className="flex items-center justify-between mb-8">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-16" />
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
          {[...Array(6)].map((_, i) => (
            <Skeleton key={i} className="aspect-[2/3] rounded-xl" />
          ))}
        </div>
      </div>
    </div>
  )
}
