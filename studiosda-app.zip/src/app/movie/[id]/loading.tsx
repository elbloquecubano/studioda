import { Skeleton } from "@/components/ui/Skeleton"

export default function MovieDetailLoading() {
  return (
    <div className="relative min-h-screen pt-20">
      {/* Backdrop Skeleton */}
      <div className="absolute top-0 left-0 w-full h-[60vh]">
        <Skeleton className="w-full h-full" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 py-12">
        {/* Back link */}
        <Skeleton className="h-5 w-40 mb-8" />

        <div className="grid md:grid-cols-[300px_1fr] gap-12">
          {/* Poster Skeleton */}
          <Skeleton className="aspect-[2/3] rounded-2xl" />

          {/* Info Skeleton */}
          <div className="flex flex-col">
            <div className="flex items-center gap-3 mb-4">
              <Skeleton className="h-6 w-20 rounded-full" />
              <Skeleton className="h-5 w-12" />
            </div>

            <Skeleton className="h-12 md:h-16 w-3/4 mb-6" />

            <div className="flex items-center gap-6 mb-8">
              <Skeleton className="h-4 w-16" />
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-12" />
            </div>

            <div className="mb-12">
              <Skeleton className="h-4 w-20 mb-4" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-5/6" />
                <Skeleton className="h-4 w-4/6" />
              </div>
            </div>

            {/* Actions Skeleton */}
            <div className="glass rounded-3xl p-8 border border-white/5 mb-8">
              <Skeleton className="h-4 w-32 mb-6" />
              <div className="flex gap-4">
                <Skeleton className="h-10 w-24 rounded-xl" />
                <Skeleton className="h-10 w-24 rounded-xl" />
              </div>
            </div>
          </div>
        </div>

        {/* Recommendations Skeleton */}
        <div className="border-t border-white/10 mt-16 pt-12">
          <Skeleton className="h-7 w-56 mb-8" />
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {[...Array(6)].map((_, i) => (
              <Skeleton key={i} className="aspect-[2/3] rounded-xl" />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
