"use client"

import Link from "next/link"

export default function MovieDetailError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
      <h1 className="text-6xl font-black text-accent mb-4">Error</h1>
      <h2 className="text-xl font-bold mb-2">Error al cargar el contenido</h2>
      <p className="text-muted text-sm mb-8 max-w-md">
        No se pudo cargar la información de este título.
      </p>
      <div className="flex gap-4">
        <button
          onClick={reset}
          className="bg-accent text-black font-bold px-6 py-3 rounded-xl hover:scale-105 transition-transform"
        >
          Reintentar
        </button>
        <Link
          href="/"
          className="bg-white/10 font-bold px-6 py-3 rounded-xl hover:bg-white/20 transition-colors"
        >
          Volver al Catálogo
        </Link>
      </div>
    </div>
  )
}
