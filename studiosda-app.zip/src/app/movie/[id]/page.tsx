import Image from "next/image"
import { Star, Calendar, Film, ChevronLeft, DollarSign, HardDrive, Radio } from "lucide-react"
import Link from "next/link"
import { prisma } from "@/lib/prisma"
import { notFound } from "next/navigation"
import MovieCard from "@/components/MovieCard"
import MediaActions from "@/components/MediaActions"
import ApartarButton from "@/components/ApartarButton"
import { getMediaTypeLabel } from "@/lib/types"
import { findTier, resolvePrice } from "@/lib/pricing"

export const revalidate = 300;

export default async function MovieDetail({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const movie = await prisma.media.findUnique({
    where: { id }
  });

  if (!movie) {
    notFound();
  }

  const backdropSrc = movie.backdropPath.trim();
  const posterSrc = movie.posterPath.trim();

  const contentPrice = await prisma.contentPrice.findUnique({
    where: { type: movie.type },
  });

  let gameTier = null;
  if (movie.type.startsWith("Game_") && movie.fileSize) {
    const tiers = await prisma.gamePriceTier.findMany({
      orderBy: { sortOrder: "asc" },
    });
    gameTier = findTier(tiers, movie.fileSize);
  }

  // Las reglas viven en src/lib/pricing.ts para que el importe de los pedidos
  // que ve el admin salga exactamente de este mismo cálculo.
  const displayPrice = resolvePrice(movie, contentPrice, gameTier ? [gameTier] : []);

  const currentGenres = movie.genre.split(",").map(g => g.trim()).filter(Boolean);

  let recommendations = [];
  if (currentGenres.length > 0) {
    recommendations = await prisma.media.findMany({
      where: {
        id: { not: movie.id },
        type: movie.type,
        OR: currentGenres.map(g => ({
          genre: { contains: g }
        }))
      },
      take: 50,
      orderBy: { createdAt: 'desc' }
    });
  } else {
    recommendations = await prisma.media.findMany({
      where: {
        id: { not: movie.id },
        type: movie.type,
      },
      take: 50,
      orderBy: { createdAt: 'desc' }
    });
  }

  return (
    <div className="relative min-h-screen pt-20">
      <div className="absolute top-0 left-0 w-full h-[60vh]">
        {backdropSrc ? (
          <Image
            src={backdropSrc}
            alt={movie.title}
            fill
            sizes="100vw"
            className="object-cover opacity-30"
          />
        ) : (
          <div className="absolute inset-0 bg-white/5" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 py-12">
        <Link href="/" className="inline-flex items-center gap-2 text-muted hover:text-accent transition-colors mb-8 group">
          <ChevronLeft className="w-5 h-5 transition-transform group-hover:-translate-x-1" />
          Volver al catálogo
        </Link>

        <div className="grid md:grid-cols-[300px_1fr] gap-12">
          <div className="relative aspect-[2/3] rounded-2xl overflow-hidden shadow-2xl border border-white/10">
            {posterSrc ? (
              <Image
                src={posterSrc}
                alt={movie.title}
                fill
                sizes="(min-width: 768px) 300px, 100vw"
                className="object-cover"
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center bg-white/5 p-6 text-center text-sm font-bold uppercase tracking-widest text-muted">
                Sin poster
              </div>
            )}
          </div>

          <div className="flex flex-col">
            <div className="flex items-center gap-3 mb-4">
              <span className="bg-accent/20 text-accent border border-accent/30 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest">{getMediaTypeLabel(movie.type)}</span>
              {movie.isAiring && (
                <span className="bg-green-500/20 text-green-400 border border-green-500/30 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest flex items-center gap-1">
                  <Radio className="w-3 h-3" />
                  En Transmisión
                </span>
              )}
            </div>

            <h1 className="text-4xl md:text-6xl font-black mb-6 tracking-tighter uppercase">{movie.title}</h1>

            <div className="flex flex-wrap items-center gap-6 text-muted mb-8 font-medium">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>{movie.year}</span>
              </div>
              <div className="flex items-center gap-2">
                <Film className="w-4 h-4" />
                <span>{movie.genre}</span>
              </div>
              {gameTier && movie.fileSize && (
                <div className="flex items-center gap-2 text-accent font-bold">
                  <HardDrive className="w-4 h-4" />
                  <span>{movie.fileSize} GB — {gameTier.label}: {gameTier.price.toFixed(2)}</span>
                </div>
              )}
              {!gameTier && displayPrice !== null && (
                <div className="flex items-center gap-2 text-accent font-bold">
                  <DollarSign className="w-4 h-4" />
                  <span>{displayPrice.toFixed(2)}</span>
                </div>
              )}
            </div>

            <div className="mb-10">
              <ApartarButton mediaId={movie.id} />
            </div>

            <div className="mb-12">
              <h2 className="text-sm font-bold uppercase tracking-widest text-accent mb-4">Sinopsis</h2>
              <p className="text-lg text-foreground/80 leading-relaxed max-w-3xl">
                {movie.synopsis}
              </p>
            </div>

            <div className="glass rounded-3xl p-8 border border-white/5 relative overflow-hidden mb-8">
              <div className="absolute top-0 right-0 p-8 opacity-5">
                <Star className="w-32 h-32 text-accent" />
              </div>
              <h3 className="text-sm font-bold uppercase tracking-widest text-accent mb-6">¿Qué te pareció?</h3>
              <MediaActions
                mediaId={movie.id}
                initialLikes={movie.likes}
                initialDislikes={movie.dislikes}
              />
            </div>

            {movie.review.trim() && (
              <div className="glass rounded-3xl p-8 border border-white/5 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-5">
                  <Star className="w-32 h-32 text-accent" />
                </div>
                <h3 className="text-sm font-bold uppercase tracking-widest text-accent mb-4">Reseña del Especialista</h3>
                <div
                  className="prose prose-invert max-w-none"
                  dangerouslySetInnerHTML={{ __html: movie.review }}
                />
              </div>
            )}
          </div>
        </div>

        {recommendations.length > 0 && (
          <div className="border-t border-white/10 mt-16 pt-12">
            <h2 className="text-2xl font-bold border-l-4 border-accent pl-4 mb-8">
              Te Recomendamos También
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
              {recommendations.map((rec) => (
                <MovieCard key={rec.id} movie={{
                  id: rec.id,
                  title: rec.title,
                  posterPath: rec.posterPath,
                  year: rec.year
                }} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
