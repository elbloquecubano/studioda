import type { Metadata } from "next";
import { Outfit } from "next/font/google";
import "./globals.css";
import Providers from "@/components/Providers";

const outfit = Outfit({
  subsets: ["latin"],
  variable: "--font-outfit",
});

export const metadata: Metadata = {
  title: "Studios D-A - Catálogo Audiovisual",
  description: "Plataforma de catálogo audiovisual profesional para Cuba",
};

import Navbar from "@/components/Navbar";
import MobileNav from "@/components/MobileNav";
import Footer from "@/components/Footer";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" className="h-full antialiased" suppressHydrationWarning>
      {/* El relleno inferior reserva el sitio de la barra de pestañas móvil,
          que es fija: sin él tapaba el pie de página y la última fila del
          catálogo. `env(safe-area-inset-bottom)` deja libre además la franja
          del indicador de inicio en los iPhone sin botón. */}
      <body
        className={`${outfit.variable} min-h-full flex flex-col bg-background text-foreground selection:bg-accent/30 font-sans pb-[calc(4rem+env(safe-area-inset-bottom))] lg:pb-0`}
      >
        <Providers>
          <a
            href="#main-content"
            className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[9999] focus:bg-accent focus:text-black focus:px-4 focus:py-2 focus:rounded-xl focus:font-bold focus:outline-none"
          >
            Saltar al contenido principal
          </a>
          <Navbar />
          <main id="main-content" className="flex-grow" role="main">
            {children}
          </main>
          <Footer />
          <MobileNav />
        </Providers>
      </body>
    </html>
  );
}
