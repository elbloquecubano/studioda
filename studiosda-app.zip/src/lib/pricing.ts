import { prisma } from "./prisma";

/**
 * Cálculo del precio de un contenido.
 *
 * Vivía dentro de `src/app/movie/[id]/page.tsx`. Se extrajo al crear los
 * pedidos: el importe que ve el admin tiene que salir de las mismas reglas que
 * el precio que vio el cliente en la ficha, y con la lógica duplicada las dos
 * cifras acabarían divergiendo.
 *
 * Dos tarifas distintas conviven:
 *   - Los videojuegos se cobran por tamaño, según los tramos de GamePriceTier.
 *   - El resto se cobra por tipo, con un precio aparte si está en emisión.
 */

export interface PriceableMedia {
  type: string;
  isAiring: boolean;
  fileSize: number | null;
}

export interface PriceTier {
  minSize: number | null;
  maxSize: number | null;
  price: number;
  label: string;
}

export interface ContentPriceRow {
  price: number;
  airingPrice: number | null;
}

function isGame(type: string): boolean {
  return type.startsWith("Game_");
}

/** Primer tramo cuyo rango contiene el tamaño. Los tramos vienen ya ordenados. */
export function findTier(tiers: PriceTier[], fileSize: number): PriceTier | null {
  return (
    tiers.find((tier) => {
      if (tier.minSize !== null && fileSize < tier.minSize) return false;
      if (tier.maxSize !== null && fileSize > tier.maxSize) return false;
      return true;
    }) ?? null
  );
}

/**
 * Resuelve el precio con los datos ya cargados. Devuelve null cuando no hay
 * tarifa aplicable, que no es lo mismo que un precio de 0: el admin todavía no
 * la ha definido, y quien llame debe distinguir los dos casos.
 */
export function resolvePrice(
  media: PriceableMedia,
  contentPrice: ContentPriceRow | null,
  tiers: PriceTier[]
): number | null {
  if (isGame(media.type) && media.fileSize) {
    return findTier(tiers, media.fileSize)?.price ?? null;
  }

  if (!contentPrice) return null;

  // El precio de emisión sólo se aplica si además existe: un contenido en
  // emisión sin tarifa propia se cobra a la normal.
  if (media.isAiring && contentPrice.airingPrice !== null) {
    return contentPrice.airingPrice;
  }

  return contentPrice.price;
}

/** Versión que consulta la base. Para un solo contenido (ficha, alta de pedido). */
export async function getPriceForMedia(media: PriceableMedia): Promise<number | null> {
  if (isGame(media.type) && media.fileSize) {
    const tiers = await prisma.gamePriceTier.findMany({ orderBy: { sortOrder: "asc" } });
    return resolvePrice(media, null, tiers);
  }

  const contentPrice = await prisma.contentPrice.findUnique({ where: { type: media.type } });
  return resolvePrice(media, contentPrice, []);
}

export function formatPrice(value: number): string {
  return value.toFixed(2);
}
