import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { prisma } from "./prisma";
import {
  LEGACY_SESSION_COOKIE,
  SESSION_COOKIE,
  createSessionPayload,
  sessionCookieOptions,
  signSession,
  verifySession,
  type SessionPayload,
  type UserRole,
} from "./session";

/**
 * Helpers de sesión para route handlers y componentes de servidor.
 *
 * Depende de `next/headers`, que NO existe en el contexto del proxy. La lógica
 * de firma vive aparte en `src/lib/session.ts` para que el proxy pueda usarla.
 */

/** Lee y verifica la cookie. No consulta la base de datos. */
export async function getSession(): Promise<SessionPayload | null> {
  const store = await cookies();
  return verifySession(store.get(SESSION_COOKIE)?.value);
}

export interface AuthenticatedUser {
  id: string;
  username: string;
  displayName: string | null;
  phone: string | null;
  address: string | null;
  role: UserRole;
  mustChangePassword: boolean;
}

/**
 * Verifica la cookie y además contrasta contra la base de datos.
 *
 * El proxy sólo puede comprobar la firma; el `tokenVersion` y el estado de la
 * cuenta se comprueban aquí, que es donde hay acceso a Prisma. Por eso todas
 * las rutas sensibles deben pasar por esta función y no confiar sólo en el
 * proxy: así, cambiar la contraseña o desactivar una cuenta corta el acceso de
 * inmediato en vez de esperar a que caduque el token.
 */
export async function getCurrentUser(): Promise<AuthenticatedUser | null> {
  const session = await getSession();
  if (!session) return null;

  const user = await prisma.user.findUnique({
    where: { id: session.sub },
    select: {
      id: true,
      username: true,
      displayName: true,
      phone: true,
      address: true,
      role: true,
      isActive: true,
      tokenVersion: true,
      mustChangePassword: true,
    },
  });

  if (!user || !user.isActive || user.tokenVersion !== session.tv) {
    return null;
  }

  return {
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    phone: user.phone,
    address: user.address,
    role: user.role === "ADMIN" ? "ADMIN" : "CUSTOMER",
    mustChangePassword: user.mustChangePassword,
  };
}

function unauthorized() {
  return NextResponse.json({ error: "Debes iniciar sesión" }, { status: 401 });
}

function forbidden() {
  return NextResponse.json({ error: "No tienes permiso para hacer esto" }, { status: 403 });
}

/**
 * Uso en un route handler:
 *
 *   const auth = await requireUser();
 *   if (auth instanceof NextResponse) return auth;
 */
export async function requireUser(): Promise<AuthenticatedUser | NextResponse> {
  const user = await getCurrentUser();
  return user ?? unauthorized();
}

export async function requireAdmin(): Promise<AuthenticatedUser | NextResponse> {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "ADMIN") return forbidden();
  return user;
}

export async function setSessionCookie(user: {
  id: string;
  username: string;
  role: string;
  tokenVersion: number;
}): Promise<void> {
  const payload = createSessionPayload(user);
  const store = await cookies();
  store.set(SESSION_COOKIE, signSession(payload), sessionCookieOptions(payload.role));
}

export async function clearSessionCookie(): Promise<void> {
  const store = await cookies();
  store.set(SESSION_COOKIE, "", { ...sessionCookieOptions("CUSTOMER"), maxAge: 0 });
  // La cookie antigua quedó en los navegadores que ya habían entrado al panel.
  store.set(LEGACY_SESSION_COOKIE, "", {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 0,
  });
}
