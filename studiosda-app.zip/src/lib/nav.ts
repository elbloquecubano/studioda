"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import useSWR from "swr";
import { Film, Gamepad2, Radio, Tv, type LucideIcon } from "lucide-react";

/**
 * Estructura del menú del catálogo, compartida por la barra de escritorio
 * (`Navbar`) y la navegación móvil (`MobileNav`).
 *
 * Vivía duplicada dentro de Navbar: una vez para los desplegables del
 * escritorio y otra para el cajón móvil, ~600 líneas de JSX casi idéntico. Al
 * añadir una categoría había que tocar los dos sitios y era fácil olvidarse de
 * uno.
 */

export interface NavEntry {
  label: string;
  href: string;
}

export interface NavSection {
  /** Clave con la que el API devuelve los géneros de este tipo. */
  key: string;
  label: string;
  icon: LucideIcon;
  /** Enlace a "todo" dentro de la categoría. */
  allHref: string;
  allLabel: string;
  /**
   * Sub-elementos fijos. Las categorías que los traen (novelas, plataformas de
   * videojuegos, animados) no se filtran por género, así que no consultan al
   * API.
   */
  staticItems?: NavEntry[];
  /** Plantilla para los enlaces de género. */
  genreHref?: (genre: string) => string;
}

const NOVELA_TYPES: NavEntry[] = [
  { label: "Todas", href: "/?type=Novela" },
  { label: "Brasileñas", href: "/?type=Novela_Brasil" },
  { label: "Colombianas", href: "/?type=Novela_Colombia" },
  { label: "Turcas", href: "/?type=Novela_Turca" },
  { label: "Mexicanas", href: "/?type=Novela_Mexicana" },
  { label: "Cristianas", href: "/?type=Novela_Cristiana" },
  { label: "Otros Países", href: "/?type=Novela_Otros" },
];

const GAME_PLATFORMS: NavEntry[] = [
  { label: "PC", href: "/?type=Game_PC" },
  { label: "Móvil", href: "/?type=Game_Mobile" },
  { label: "PlayStation 1", href: "/?type=Game_PS1" },
  { label: "PlayStation 2", href: "/?type=Game_PS2" },
  { label: "PlayStation 3", href: "/?type=Game_PS3" },
  { label: "PlayStation 4", href: "/?type=Game_PS4" },
  { label: "Xbox 360", href: "/?type=Game_Xbox_360" },
  { label: "Nintendo Switch", href: "/?type=Game_Switch" },
  { label: "PSP", href: "/?type=Game_PSP" },
  { label: "Nintendo 3DS", href: "/?type=Game_3DS" },
  { label: "Wii", href: "/?type=Game_Wii" },
];

const ANIMATED_TYPES: NavEntry[] = [
  { label: "Series", href: "/?type=Animated_Series" },
  { label: "Filmes", href: "/?type=Animated_Movie" },
];

function byType(type: string) {
  return (genre: string) => `/?type=${type}&genre=${encodeURIComponent(genre)}`;
}

/**
 * Orden pensado para el móvil: primero lo que más se busca. En el escritorio
 * caben todas de un vistazo, pero en una hoja vertical el orden decide qué se
 * ve sin desplazarse.
 */
export const NAV_SECTIONS: NavSection[] = [
  {
    key: "Movie",
    label: "Películas",
    icon: Film,
    allHref: "/?type=Movie",
    allLabel: "Todas",
    genreHref: byType("Movie"),
  },
  {
    key: "Series",
    label: "Series",
    icon: Tv,
    allHref: "/?type=Series",
    allLabel: "Todas",
    genreHref: byType("Series"),
  },
  {
    key: "Novela",
    label: "Novelas",
    icon: Tv,
    allHref: "/?type=Novela",
    allLabel: "Todas",
    staticItems: NOVELA_TYPES,
  },
  {
    key: "Dorama",
    label: "Doramas",
    icon: Tv,
    allHref: "/?type=Dorama",
    allLabel: "Todas",
    genreHref: byType("Dorama"),
  },
  {
    key: "Anime",
    label: "Animes",
    icon: Tv,
    allHref: "/?type=Anime",
    allLabel: "Todos",
    genreHref: byType("Anime"),
  },
  {
    key: "Reality",
    label: "Realitys",
    icon: Tv,
    allHref: "/?type=Reality",
    allLabel: "Todos",
    genreHref: byType("Reality"),
  },
  {
    key: "transmision",
    label: "Transmisión",
    icon: Radio,
    allHref: "/?transmision=true",
    allLabel: "Todos",
    genreHref: (genre) => `/?transmision=true&genre=${encodeURIComponent(genre)}`,
  },
  {
    key: "Deportes",
    label: "Deportes",
    icon: Tv,
    allHref: "/?type=Deportes",
    allLabel: "Todos",
    genreHref: byType("Deportes"),
  },
  {
    key: "Dongchua",
    label: "Dongchua",
    icon: Tv,
    allHref: "/?type=Dongchua",
    allLabel: "Todos",
    genreHref: byType("Dongchua"),
  },
  {
    key: "Animated",
    label: "Animados",
    icon: Tv,
    allHref: "/?type=Animated_Series",
    allLabel: "Series",
    staticItems: ANIMATED_TYPES,
  },
  {
    key: "Game",
    label: "Videojuegos",
    icon: Gamepad2,
    allHref: "/?type=Game_PC",
    allLabel: "PC",
    staticItems: GAME_PLATFORMS,
  },
];

/** Secciones cuyos géneros hay que pedir al servidor. */
const DYNAMIC_KEYS = NAV_SECTIONS.filter((s) => s.genreHref).map((s) => s.key);

export type GenresByType = Record<string, string[]>;

async function fetchGenresByType(): Promise<GenresByType> {
  const entries = await Promise.all(
    DYNAMIC_KEYS.map(async (key) => {
      try {
        const res = await fetch(`/api/genres/by-type?type=${encodeURIComponent(key)}`);
        const data = await res.json();
        return [key, Array.isArray(data) ? data : []] as const;
      } catch {
        // Un tipo sin géneros simplemente muestra sólo "Todas".
        return [key, [] as string[]] as const;
      }
    })
  );

  return Object.fromEntries(entries);
}

/**
 * Géneros de cada categoría.
 *
 * Con SWR y una única clave, la barra de escritorio y la móvil comparten la
 * misma petición en vez de disparar dos tandas de ocho.
 */
export function useGenresByType(): GenresByType {
  const pathname = usePathname();
  const { data, mutate } = useSWR<GenresByType>("nav:genres-by-type", fetchGenresByType, {
    // El panel de administración puede añadir géneros mientras el catálogo está
    // abierto en otra pestaña.
    revalidateOnFocus: true,
    keepPreviousData: true,
  });

  useEffect(() => {
    mutate();
  }, [pathname, mutate]);

  return data ?? {};
}
