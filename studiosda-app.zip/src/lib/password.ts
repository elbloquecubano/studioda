import { randomBytes, scrypt, timingSafeEqual, type ScryptOptions } from "node:crypto";
import { promisify } from "node:util";

// promisify sólo conserva una de las sobrecargas de scrypt y pierde la que
// acepta opciones, así que se declara la firma completa a mano.
const scryptAsync = promisify(scrypt) as (
  password: string | Buffer,
  salt: string | Buffer,
  keylen: number,
  options: ScryptOptions
) => Promise<Buffer>;

/**
 * Hash de contraseñas con scrypt de node:crypto.
 *
 * scrypt en vez de PBKDF2 por su coste en memoria, que encarece los ataques
 * con GPU. Sin dependencias externas a propósito: esta máquina ya usa SWC en
 * WASM porque el binario nativo le falla, y añadir paquetes con binarios
 * (bcrypt, argon2) reintroduciría ese problema en cada instalación.
 */

const N = 16384; // coste de CPU/memoria: ~16 MB por hash
const R = 8;
const P = 1;
const KEY_LENGTH = 32;
const SALT_LENGTH = 16;

// El límite por defecto de Node son 32 MB y N=16384 consume ~16 MB; se declara
// explícitamente para que subir N en el futuro no falle de forma silenciosa.
const MAX_MEM = 64 * 1024 * 1024;

/** Formato: scrypt$N$r$p$saltBase64$hashBase64 */
export async function hashPassword(plain: string): Promise<string> {
  const salt = randomBytes(SALT_LENGTH);
  const derived = (await scryptAsync(plain, salt, KEY_LENGTH, {
    N,
    r: R,
    p: P,
    maxmem: MAX_MEM,
  })) as Buffer;

  return [
    "scrypt",
    N,
    R,
    P,
    salt.toString("base64"),
    derived.toString("base64"),
  ].join("$");
}

/**
 * Compara en tiempo constante. Los parámetros se leen del propio hash para que
 * las contraseñas guardadas sigan validando aunque se suba el coste después.
 */
export async function verifyPassword(plain: string, stored: string): Promise<boolean> {
  const parts = stored.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;

  const [, nRaw, rRaw, pRaw, saltB64, hashB64] = parts;
  const n = Number(nRaw);
  const r = Number(rRaw);
  const p = Number(pRaw);
  if (!Number.isInteger(n) || !Number.isInteger(r) || !Number.isInteger(p)) return false;

  const expected = Buffer.from(hashB64, "base64");

  try {
    const derived = (await scryptAsync(plain, Buffer.from(saltB64, "base64"), expected.length, {
      N: n,
      r,
      p,
      maxmem: MAX_MEM,
    })) as Buffer;

    return derived.length === expected.length && timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

/**
 * Hash de descarte con el que comparar cuando el usuario no existe.
 *
 * Sin esto, un login contra un usuario inexistente responde mucho más rápido
 * que uno con contraseña incorrecta, y ese margen permite enumerar qué
 * usuarios están registrados.
 */
const DUMMY_HASH = hashPassword("contrasena-que-nunca-coincide");

export async function wastePasswordTime(plain: string): Promise<void> {
  await verifyPassword(plain, await DUMMY_HASH);
}

export interface PasswordProblem {
  message: string;
}

/** Reglas mínimas. Se comparten entre registro, cambio de contraseña y el script de admin. */
export function validatePassword(plain: unknown): PasswordProblem | null {
  if (typeof plain !== "string" || plain.length < 8) {
    return { message: "La contraseña debe tener al menos 8 caracteres" };
  }
  if (plain.length > 200) {
    return { message: "La contraseña es demasiado larga" };
  }
  if (/^\d+$/.test(plain)) {
    return { message: "La contraseña no puede ser sólo números" };
  }
  return null;
}

const USERNAME_PATTERN = /^[a-z0-9._-]{3,20}$/;

/**
 * Normaliza a minúsculas. SQLite compara distinguiendo mayúsculas, así que sin
 * esto "Pedro" y "pedro" serían dos cuentas distintas y el usuario no
 * entendería por qué no puede entrar.
 */
export function normalizeUsername(raw: unknown): string {
  return typeof raw === "string" ? raw.trim().toLowerCase() : "";
}

export function validateUsername(normalized: string): PasswordProblem | null {
  if (!USERNAME_PATTERN.test(normalized)) {
    return {
      message: "El usuario debe tener entre 3 y 20 caracteres: letras, números, punto, guion o guion bajo",
    };
  }
  return null;
}
