export const MEDIA_TYPES = {
  Movie: { label: "Película", plural: "Películas" },
  Series: { label: "Serie", plural: "Series" },
  Dorama: { label: "Dorama", plural: "Doramas" },
  Novela: { label: "Novela", plural: "Novelas" },
  Novela_Brasil: { label: "Novela Brasileña", plural: "Novelas Brasileñas" },
  Novela_Colombia: { label: "Novela Colombiana", plural: "Novelas Colombianas" },
  Novela_Turca: { label: "Novela Turca", plural: "Novelas Turcas" },
  Novela_Mexicana: { label: "Novela Mexicana", plural: "Novelas Mexicanas" },
  Novela_Cristiana: { label: "Novela Cristiana", plural: "Novelas Cristianas" },
  Novela_Otros: { label: "Otra Novela", plural: "Otras Novelas" },
  Reality: { label: "Reality", plural: "Realitys" },
  Anime: { label: "Anime", plural: "Animes" },
  Dongchua: { label: "Dongchua", plural: "Dongchua" },
  Animated_Series: { label: "Animados (Serie)", plural: "Animados (Series)" },
  Animated_Movie: { label: "Animados (Filme)", plural: "Animados (Filmes)" },
  Deportes: { label: "Deportes", plural: "Deportes" },
  Game_PC: { label: "Juegos para PC", plural: "Juegos para PC" },
  Game_Mobile: { label: "Juegos para Móvil", plural: "Juegos para Móvil" },
  Game_PS1: { label: "Juegos de PS1", plural: "Juegos de PS1" },
  Game_PS2: { label: "Juegos de PS2", plural: "Juegos de PS2" },
  Game_PS3: { label: "Juegos de PS3", plural: "Juegos de PS3" },
  Game_PS4: { label: "Juegos de PS4", plural: "Juegos de PS4" },
  Game_Xbox_360: { label: "Juegos de Xbox 360", plural: "Juegos de Xbox 360" },
  Game_Switch: { label: "Juegos de Switch", plural: "Juegos de Switch" },
  Game_PSP: { label: "Juegos de PSP", plural: "Juegos de PSP" },
  Game_3DS: { label: "Juegos de 3DS", plural: "Juegos de 3DS" },
  Game_Wii: { label: "Juegos de Wii", plural: "Juegos de Wii" },
} as const;

export type MediaType = keyof typeof MEDIA_TYPES;

export function getMediaTypeLabel(type: string): string {
  return MEDIA_TYPES[type as MediaType]?.label || type;
}

export function getMediaTypePlural(type: string): string {
  return MEDIA_TYPES[type as MediaType]?.plural || type;
}

// === Database Model Types ===

export interface Media {
  id: string;
  title: string;
  type: string;
  year: number;
  genre: string;
  synopsis: string;
  review: string;
  posterPath: string;
  backdropPath: string;
  isFeatured: boolean;
  isAiring: boolean;
  likes: number;
  dislikes: number;
  createdAt: string;
  updatedAt: string;
  fileSize: number | null;
}

export interface MediaListItem {
  id: string;
  title: string;
  type: string;
  year: number;
  genre: string;
  posterPath: string;
  backdropPath: string;
  isFeatured: boolean;
  isAiring: boolean;
}

export interface Genre {
  id: string;
  name: string;
  slug: string;
  createdAt: string;
  updatedAt: string;
}

export interface ContentPrice {
  id: string;
  type: string;
  price: number;
  airingPrice: number | null;
}

export interface StoreConfig {
  id: string;
  location: string;
  address: string;
  openTime: string;
  closeTime: string;
}

export interface GamePriceTier {
  id: string;
  label: string;
  minSize: number | null;
  maxSize: number | null;
  price: number;
  sortOrder: number;
}

// === API Response Types ===

export interface ApiResponse<T> {
  success?: boolean;
  data?: T;
  error?: string;
}

export interface InteractResponse {
  likes: number;
  dislikes: number;
}
