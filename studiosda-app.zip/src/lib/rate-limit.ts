import { NextResponse } from "next/server";

// Almacén en memoria: { clave: { count, resetTime } }
const hits = new Map<string, { count: number; resetTime: number }>();

// Limpiar entradas expiradas cada 5 minutos
const CLEANUP_INTERVAL = 5 * 60 * 1000;
// Tope duro de claves. La IP puede venir de una cabecera que el cliente
// controla, así que sin límite un atacante haría crecer el Map hasta agotar la
// memoria del proceso.
const MAX_ENTRIES = 10_000;
let lastCleanup = Date.now();

function cleanup(force = false) {
  const now = Date.now();
  if (!force && now - lastCleanup < CLEANUP_INTERVAL) return;

  for (const [key, value] of hits.entries()) {
    if (now > value.resetTime) {
      hits.delete(key);
    }
  }
  lastCleanup = now;

  // Si tras purgar lo caducado sigue desbordado, se vacía entero: preferible a
  // quedarse sin memoria, y el efecto es sólo perdonar límites en curso.
  if (hits.size > MAX_ENTRIES) {
    hits.clear();
  }
}

export interface LimitResult {
  ok: boolean;
  retryAfter: number;
  remaining: number;
}

/**
 * Cuenta un intento contra la clave dada.
 * @param identifier - Clave única (IP, usuario, o global por endpoint)
 * @param maxRequests - Máximo de intentos permitidos en la ventana
 * @param windowMs - Ventana de tiempo en milisegundos
 */
export function checkLimit(
  identifier: string,
  maxRequests: number,
  windowMs: number
): LimitResult {
  cleanup(hits.size > MAX_ENTRIES);

  const now = Date.now();
  const record = hits.get(identifier);

  if (!record || now > record.resetTime) {
    hits.set(identifier, { count: 1, resetTime: now + windowMs });
    return { ok: true, retryAfter: 0, remaining: maxRequests - 1 };
  }

  record.count++;

  if (record.count > maxRequests) {
    return {
      ok: false,
      retryAfter: Math.ceil((record.resetTime - now) / 1000),
      remaining: 0,
    };
  }

  return { ok: true, retryAfter: 0, remaining: maxRequests - record.count };
}

/** Olvida los intentos de una clave. Se usa tras un login correcto. */
export function resetLimit(identifier: string): void {
  hits.delete(identifier);
}

export function tooManyRequests(retryAfter: number): NextResponse {
  return NextResponse.json(
    {
      error: "Demasiados intentos. Espera un momento antes de volver a intentarlo.",
      retryAfter,
    },
    {
      status: 429,
      headers: { "Retry-After": String(retryAfter) },
    }
  );
}

/**
 * Rate limiter simple en memoria.
 * @returns null si permitido, o NextResponse con 429 si excedido
 */
export function rateLimit(
  identifier: string,
  maxRequests: number = 30,
  windowMs: number = 60_000
): NextResponse | null {
  const result = checkLimit(identifier, maxRequests, windowMs);
  if (result.ok) return null;

  return NextResponse.json(
    {
      error: "Demasiadas peticiones. Intenta de nuevo más tarde.",
      retryAfter: result.retryAfter,
    },
    {
      status: 429,
      headers: {
        "Retry-After": String(result.retryAfter),
        "X-RateLimit-Limit": String(maxRequests),
        "X-RateLimit-Remaining": "0",
      },
    }
  );
}

/**
 * IP del cliente.
 *
 * Next rellena `x-forwarded-for` con la dirección del socket cuando el cliente
 * no la envía, pero si el cliente SÍ la envía, la suya gana. Es decir: este
 * valor es orientativo y falsificable rotando la cabecera. Por eso los límites
 * por IP son sólo una capa; contra la fuerza bruta lo que de verdad protege es
 * el bloqueo por cuenta en base de datos (ver `/api/auth/login`).
 *
 * El fallback es una constante y no un valor aleatorio: una clave distinta por
 * petición daría a cada una su propio contador, anulando el límite justo en el
 * caso en que no se puede identificar al cliente.
 */
export function getClientIP(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) {
    const first = forwarded.split(",")[0].trim();
    if (first) return normalizeIP(first);
  }

  const realIP = request.headers.get("x-real-ip");
  if (realIP) return normalizeIP(realIP.trim());

  return "unknown";
}

function normalizeIP(ip: string): string {
  // IPv4 mapeada en IPv6 (::ffff:192.168.1.5) y puerto final, para que la
  // misma máquina no ocupe varios contadores.
  const unmapped = ip.replace(/^::ffff:/i, "");
  const withoutPort = unmapped.replace(/:\d+$/, "");
  return withoutPort.toLowerCase();
}
