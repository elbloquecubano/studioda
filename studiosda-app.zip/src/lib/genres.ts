export interface Genre {
  id: string;
  name: string;
  slug: string;
}

export function normalizeGenreName(name: string): string {
  return name.trim().replace(/\s+/g, " ");
}

export function createGenreSlug(name: string): string {
  return normalizeGenreName(name)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

export function parseGenreList(value: string): string[] {
  return value
    .split(",")
    .map((genre) => normalizeGenreName(genre))
    .filter(Boolean);
}

export function formatGenreList(genres: string[]): string {
  return genres.map(normalizeGenreName).filter(Boolean).join(", ");
}
