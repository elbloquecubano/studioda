import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Firma y verificación del token de sesión.
 *
 * Este módulo lo importa también `src/proxy.ts`. En Next 16 el proxy corre
 * siempre en runtime Node (declarar `export const runtime` allí rompe el
 * build), así que `node:crypto` está disponible y no hace falta Web Crypto.
 *
 * No importar `next/headers` aquí: no existe en el contexto del proxy. Lo que
 * dependa de cookies va en `src/lib/auth.ts`.
 */

export type UserRole = "ADMIN" | "CUSTOMER";

export interface SessionPayload {
  sub: string; // id del usuario
  username: string;
  role: UserRole;
  tv: number; // tokenVersion, para invalidar sesiones abiertas
  // Contraseña pendiente de cambiar. Viaja en el token para que el proxy pueda
  // forzar el cambio con una redirección HTTP real: el proxy no tiene acceso a
  // la base de datos, y hacerlo sólo desde el layout produce una redirección
  // de cliente (respuesta 200) mucho más fácil de saltarse.
  // Se mantiene al día porque la cookie se reemite al cambiar la contraseña.
  mcp: boolean;
  iat: number; // segundos
  exp: number; // segundos
}

export const SESSION_COOKIE = "sda_session";

/** Cookie de la versión anterior. Sólo se usa para borrarla. */
export const LEGACY_SESSION_COOKIE = "auth_session";

const ADMIN_TTL_SECONDS = 4 * 60 * 60; // 4 h: en LAN sobre HTTP la cookie viaja en claro
const CUSTOMER_TTL_SECONDS = 7 * 24 * 60 * 60;

export function sessionTtlSeconds(role: UserRole): number {
  return role === "ADMIN" ? ADMIN_TTL_SECONDS : CUSTOMER_TTL_SECONDS;
}

/**
 * Lanza si falta el secreto en vez de recurrir a un valor por defecto: un
 * secreto conocido permitiría fabricar sesiones de admin, que es exactamente
 * la vulnerabilidad que este módulo viene a cerrar. Normalmente lo resuelve
 * `scripts/env-setup.mjs` al arrancar.
 */
function getSecret(): string {
  const secret = process.env.AUTH_SECRET;
  if (!secret || secret.length < 32) {
    throw new Error(
      "AUTH_SECRET no está definido o es demasiado corto. Arranca la aplicación con los scripts del proyecto (npm run dev / iniciar.bat)."
    );
  }
  return secret;
}

function sign(data: string): string {
  return createHmac("sha256", getSecret()).update(data).digest("base64url");
}

export function createSessionPayload(user: {
  id: string;
  username: string;
  role: string;
  tokenVersion: number;
  mustChangePassword?: boolean;
}): SessionPayload {
  const role: UserRole = user.role === "ADMIN" ? "ADMIN" : "CUSTOMER";
  const now = Math.floor(Date.now() / 1000);

  return {
    sub: user.id,
    username: user.username,
    role,
    tv: user.tokenVersion,
    mcp: user.mustChangePassword === true,
    iat: now,
    exp: now + sessionTtlSeconds(role),
  };
}

export function signSession(payload: SessionPayload): string {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${body}.${sign(body)}`;
}

/**
 * Devuelve el payload si la firma es válida y no ha caducado, o null.
 * Nunca lanza: un token corrupto es simplemente "sin sesión".
 */
export function verifySession(token: string | undefined | null): SessionPayload | null {
  if (!token) return null;

  const separator = token.lastIndexOf(".");
  if (separator <= 0) return null;

  const body = token.slice(0, separator);
  const signature = token.slice(separator + 1);

  let expected: string;
  try {
    expected = sign(body);
  } catch {
    // Falta AUTH_SECRET: no se puede verificar nada, así que no hay sesión.
    return null;
  }

  const given = Buffer.from(signature);
  const want = Buffer.from(expected);
  // timingSafeEqual exige longitudes iguales, y comparar longitudes antes no
  // filtra nada útil porque la firma tiene tamaño fijo.
  if (given.length !== want.length || !timingSafeEqual(given, want)) {
    return null;
  }

  let payload: SessionPayload;
  try {
    payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
  } catch {
    return null;
  }

  if (typeof payload?.sub !== "string" || typeof payload?.exp !== "number") {
    return null;
  }

  if (payload.exp <= Math.floor(Date.now() / 1000)) {
    return null;
  }

  return payload;
}

/** Opciones de la cookie, compartidas por todos los sitios que la escriben. */
export function sessionCookieOptions(role: UserRole) {
  return {
    httpOnly: true,
    // Sólo con HTTPS: en HTTP el navegador descartaría la cookie y nadie
    // podría iniciar sesión. Se activa por variable de entorno al salir a
    // internet, sin tocar código.
    secure: process.env.AUTH_COOKIE_SECURE === "true",
    sameSite: "lax" as const,
    path: "/",
    maxAge: sessionTtlSeconds(role),
  };
}
