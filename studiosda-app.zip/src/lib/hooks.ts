import useSWR from "swr";
import type { Media, Genre, ContentPrice, StoreConfig, GamePriceTier } from "./types";

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export function useMedia(type?: string, genre?: string, search?: string) {
  const params = new URLSearchParams();
  if (type) params.set("type", type);
  if (genre) params.set("genre", genre);
  if (search) params.set("search", search);

  const url = `/api/media${params.toString() ? `?${params}` : ""}`;

  const { data, error, isLoading, mutate } = useSWR<Media[]>(url, fetcher, {
    revalidateOnFocus: false,
    dedupingInterval: 60000,
  });

  return {
    media: data,
    isLoading,
    isError: error,
    mutate,
  };
}

export function useGenres() {
  const { data, error, isLoading, mutate } = useSWR<Genre[]>(
    "/api/genres",
    fetcher,
    {
      revalidateOnFocus: false,
      dedupingInterval: 120000,
    }
  );

  return {
    genres: data,
    isLoading,
    isError: error,
    mutate,
  };
}

export function useContentPrices() {
  const { data, error, isLoading, mutate } = useSWR<ContentPrice[]>(
    "/api/admin/prices",
    fetcher,
    {
      revalidateOnFocus: false,
    }
  );

  return {
    prices: data,
    isLoading,
    isError: error,
    mutate,
  };
}

export function useStoreConfig() {
  const { data, error, isLoading, mutate } = useSWR<StoreConfig[]>(
    "/api/admin/store-config",
    fetcher,
    {
      revalidateOnFocus: false,
    }
  );

  return {
    config: data,
    isLoading,
    isError: error,
    mutate,
  };
}

export function useGamePriceTiers() {
  const { data, error, isLoading, mutate } = useSWR<GamePriceTier[]>(
    "/api/admin/game-price-tiers",
    fetcher,
    {
      revalidateOnFocus: false,
    }
  );

  return {
    tiers: data,
    isLoading,
    isError: error,
    mutate,
  };
}
