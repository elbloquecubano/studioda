import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { SESSION_COOKIE, verifySession, type SessionPayload } from "@/lib/session";

/**
 * Primera capa de autorización.
 *
 * Aquí sólo se comprueba la firma del token: el proxy no tiene acceso a Prisma,
 * así que no puede validar `tokenVersion` ni si la cuenta sigue activa. Esa
 * segunda comprobación la hacen `requireUser()` / `requireAdmin()` dentro de
 * cada route handler (`src/lib/auth.ts`). Las dos capas son necesarias: confiar
 * sólo en el matcher fue lo que dejó `/api/admin/*` abierto de par en par.
 *
 * No añadir `export const runtime` a este archivo: en Next 16 el proxy corre
 * siempre en Node y declararlo rompe el build (error E1031).
 */

/** Rutas de escritura que quedan fuera de /api/admin pero modifican el catálogo. */
const ADMIN_WRITE_PREFIXES = ["/api/media", "/api/genres", "/api/upload", "/api/scrape"];

const SAFE_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);

function isApiPath(pathname: string): boolean {
  return pathname.startsWith("/api/");
}

/**
 * Compara por segmentos completos, no por prefijo de texto.
 *
 * Con startsWith, "/api/media" cae dentro de "/api/me" y el catálogo público
 * quedaría exigiendo sesión.
 */
function isUnder(pathname: string, base: string): boolean {
  return pathname === base || pathname.startsWith(`${base}/`);
}

function deny(request: NextRequest, status: 401 | 403, loginPath: string) {
  const { pathname, search } = request.nextUrl;

  // Las APIs responden en JSON: redirigir una llamada fetch a una página de
  // login devolvería un 200 con HTML y el cliente lo interpretaría como éxito.
  if (isApiPath(pathname)) {
    return NextResponse.json(
      { error: status === 401 ? "Debes iniciar sesión" : "No tienes permiso para hacer esto" },
      { status }
    );
  }

  const loginUrl = new URL(loginPath, request.url);
  loginUrl.searchParams.set("next", `${pathname}${search}`);
  return NextResponse.redirect(loginUrl);
}

/**
 * Deja pasar la petición añadiendo la ruta como cabecera.
 *
 * Los layouts de servidor no reciben el pathname y `src/app/admin/layout.tsx`
 * lo necesita para distinguir /admin/login (que debe ser accesible sin sesión)
 * del resto del panel; sin esto entraría en un bucle de redirecciones.
 */
function passThrough(request: NextRequest) {
  const headers = new Headers(request.headers);
  headers.set("x-pathname", request.nextUrl.pathname);
  return NextResponse.next({ request: { headers } });
}

export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const method = request.method.toUpperCase();

  const session: SessionPayload | null = verifySession(
    request.cookies.get(SESSION_COOKIE)?.value
  );

  const needsAdmin =
    isUnder(pathname, "/api/admin") ||
    (isUnder(pathname, "/admin") && pathname !== "/admin/login") ||
    (!SAFE_METHODS.has(method) &&
      ADMIN_WRITE_PREFIXES.some((prefix) => isUnder(pathname, prefix)));

  if (needsAdmin) {
    if (!session) return deny(request, 401, "/admin/login");
    if (session.role !== "ADMIN") return deny(request, 403, "/admin/login");
    return passThrough(request);
  }

  const needsUser = isUnder(pathname, "/mi-cuenta") || isUnder(pathname, "/api/me");

  if (needsUser) {
    if (!session) return deny(request, 401, "/cuenta/login");
    return passThrough(request);
  }

  return passThrough(request);
}

export const proxyConfig = {
  matcher: [
    "/admin/:path*",
    "/mi-cuenta/:path*",
    "/api/admin/:path*",
    "/api/me/:path*",
    "/api/media",
    "/api/media/:path*",
    "/api/genres",
    "/api/genres/:path*",
    "/api/upload",
    "/api/upload/:path*",
    "/api/scrape",
    "/api/scrape/:path*",
  ],
};
